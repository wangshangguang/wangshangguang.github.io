If you find this code useful, please cite the following papers:

@article{wang2019cloud,
  title={A cloud-guided feature extraction approach for image retrieval in mobile edge computing},
  author={Wang, Shangguang and Ding, Chuntao and Zhang, Ning and Liu, Xiulong and Zhou, Ao and Cao, Jiannong and Shen, Xuemin Sherman},
  journal={IEEE Transactions on Mobile Computing},
  year={2019},
  publisher={IEEE}
}

@ARTICLE{8632682,  
author={Ding, Chuntao and Wang, Shangguang}, 
 journal={The Journal of Supercomputing},  
title={Appropriate points choosing for subspace learning over image classification},   
year={2019},  
volume={75},  
number={2},  
pages={688-703},
}

