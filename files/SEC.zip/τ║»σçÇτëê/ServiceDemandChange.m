%----Main------%
%-----dynamic service placement-------%
%-------2020-12-21---------------%
% 此版本用来验证性能随服务需求变化的情况
clc,clear all;
%全局参数
global M; % 地面区域个数
global N; % 卫星个数N
global T; % 时隙总数
global K; % 服务个数总数
%%
M=354;% 根据卫星数据定
N= 144;% 根据卫星数据定
T=200; % 根据决策周期长度定， 每秒决策最多为24*60*60， 每两分钟决策一次
K=5;

%[SPbudget,ADbudget,Pcapacity,Pservice, DemService,WeightRobust,ComCover,ComRobust,FeasiblePolicy,MaxIter,V,tau]=DefaultSetting();
load('Default.mat');
ComRobust=zeros(N,N,M,T); %通信重复覆盖情况
%预先根据覆盖计算重复覆盖的情况
for t=1:T
   
    for ii=1:N
        for i2=1:N
            for j= 1:M
            ComRobust(ii,i2,j,t)=ComCover(ii,j,t)*ComCover(i2,j,t);
            if ii==i2
                ComRobust(ii,i2,j,t)=0;
            end
            end
        end
        
    end
end

%%%------------------在验证不同参数的影响时，更改相应的参数值---------------
%T=?%验证Giibs 收敛时 T=2, tau 分别取 100 30t, t^2， 10000，

% V=?; 验证V的影响时 V=0.1 1 10 100 1000 10000， 100个时隙的平均值

%DemService=？ 验证demand的影响时 10 20 30 40 50 50 70 80 90 100 ， 100个时隙的平均值

% SPbudget=：,ADbudget=？, 验证预算的影响时 V=?, 取值范围

% WeightRobust=？ 验证 对鲁棒性偏好的影响， 10 20 30 40 50 60 70 80 90 100， 100个时隙的平均值

T=50;
MaxServ=5;
SerDemandRC=zeros(1,MaxServ);



for ii=1:MaxServ

DemService=random('Poisson',ii*10*rand(),K, M,T ); %服务请求数, 这里没有考虑 服务和 地域的非均匀性

Ourx=zeros(N,K,T); %决策变量，服务放置矩阵

%%
%---------------------Our Algorithm-------------------------
%MaxIter=30;
 %V=1000;
%tau=100;


QueueSP=zeros(T,K); %队列长度
QueueAD=zeros(T,K); %队列长度

SerCoverage=zeros(1,T); %服务覆盖
Robustness=zeros(1,T);%服务鲁棒性
RC=zeros(1,T); %鲁棒性感知的覆盖

SPCost=zeros(T,K); %放置成本
ADCost=zeros(T,K); %调整成本

for t=1:T
     
    if t==1
        Ourx(:,:,t)=shiftdim(FeasiblePolicy(1,:,:))';
        
        for k=1:K
        QueueSP(t+1,k)=max(0, sum(Ourx(:,k,t))-SPbudget(k));
        QueueAD(t+1,k)=max(0, sum(Ourx(:,k,t))-ADbudget(k));
%         
         QueueSP(t+1,k)=0;
        QueueAD(t+1,k)=0;
        end
    else
        [Ourx(:,:,t),SerCoverage(t), Robustness(t), RC(t), SPCost(t,:), ADCost(t,:)] =ParaGibbsSample(tau, MaxIter, FeasiblePolicy, QueueSP(t,:),QueueAD(t,:), Ourx(:,:,t-1),V,ComRobust(:,:,:,t),ComCover(:,:,t),DemService(:,:,t),WeightRobust(t)) ;
      
        %-------------Queue Update-----------------
        for k=1:K
        QueueSP(t+1,k)=QueueSP(t,k)+max(0, sum(Ourx(:,k,t))-SPbudget(k));
        QueueAD(t+1,k)=QueueAD(t,k)+max(0, sum(xor(Ourx(:,k,t), Ourx(:,k,t-1)))-ADbudget(k));
        end    
        
    end
end
SerDemandRC(ii)=sum(RC)/T;





%----------Random Service Placement Algorithm---------------------%
Randomx=zeros(N,K,T);
SerCoverRandom=zeros(1,T);
RobustnessRandom=zeros(1,T);
RCRandom=zeros(1,T);
for t=1:T
           tempSP=SPbudget*40;
           tempAD=ADbudget;
       
            for i=1:N
                FeasibleX=FeasiblePolicy(:,:,i);
                FeasibleX(all(FeasibleX == 0, 2),:) = []; %删除全零行
                ind1=find(tempSP<=0);
                for f1=1:size(FeasibleX,1)
                    
                        FeasibleX(f1,ind1)=0;
                   
                end
                FeasibleX(all(FeasibleX == 0, 2),:) = []; %删除全零行
                if ~isempty(FeasibleX)
                    
                Randomx(i,:,t)=FeasibleX(randperm(size(FeasibleX,1),1),:);% 随机生成一个策略的下标
                tempSP=tempSP-sum(Randomx(:,:,t),1);
               % tempAD=tempAD-sum(xor(Randomx(:,:,t), Randomx(:,:,t-1)),1);
                end
            end
            if t>=2
           [RCRandom(t),SerCoverageRandom(t),RobustnessRandom(t),SPCostRandom(t,:),ADCostRandom(t,:)]=RCcompute(Randomx(:,:,t),Randomx(:,:,t-1), DemService(:,:,t),WeightRobust(t),ComCover(:,:,t),ComRobust(:,:,:,t));
            end
           %       ComRobusttemp=shiftdim(ComRobust(:,:,:,t));
%       Randomxtemp=shiftdim(Randomx(:,:,t));
%       ComCovertemp=shiftdim(ComCover(:,:,t));
%     SerCoverRandom(t)=sum(sum(Randomxtemp'*ComCovertemp));
%     for i=1:N
%            tempComRobust=shiftdim(ComRobust(i,:,:,t));
%         
%        RobustnessRandom(t)=  RobustnessRandom(t)+0.5*sum(sum(WeightRobust(t).*Randomx(:,:,t)*diag(Randomx(i,:,t))*DemService(:,:,t).*tempComRobust));%根据论文里的公式
%         
%     end
%     RCRandom(t)=RobustnessRandom(t)+SerCoverRandom(t);
 end
% 
SerDemandRandom(ii)=sum(RCRandom)/T;

end
save('ParameterDemand6.mat','SerDemandRC','SerDemandRandom');
%画图
t=10:10:50;
figure(1)
plot(t,SerDemandRC);
hold on;
plot(t,SerDemandRandom);
xlabel('Serive demand density');
ylabel('Robustness aware service coverage');
legend('Proposed','Random');

