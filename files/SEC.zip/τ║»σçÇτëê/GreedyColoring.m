function [colorTbl, MarkovBlanket]=GreedyColoring(graph)
% --- 贪婪算法实现顶点着色问题 ---
global M; % 地面区域个数
global N; % 卫星个数N
global T; % 时隙总数
global K; % 服务个数总数
vnum = max(size(graph));
colorTbl = zeros(1, vnum);    % 着色方案表,0代表未着色 

cInd = 1;
% while sum(colorTbl==0) > 0                              % 全部着色完成
%     for vInd = 1 : vnum
%         if 0 == colorTbl(vInd)                          % 当前顶点vInd尚未着色
%             tmpTbl = colorTbl(graph(:, vInd)~=0);       % 当前顶点vInd的邻接点的着色表
%             if 0 == sum(tmpTbl==cInd)                   % vInd的邻接点都尚未着当前色cInd
%                 colorTbl(vInd) = cInd;                  % 顶点vInd着色cInd
%             end
%         end
%     end
%     cInd = cInd + 1;
% end

MarkovBlanket=zeros(N,N);
while sum(colorTbl==0) > 0                              % 全部着色完成
    for vInd = 1 : vnum
        if 0 == colorTbl(vInd)                          % 当前顶点vInd尚未着色
            tmpTbl = colorTbl(graph(:, vInd)~=0);       % 当前顶点vInd的邻接点的着色表
            
            onehop=find(graph(:, vInd)~=0);
            twohop=[];
            twotemp=[];
            for i1=1:length(onehop)
                twotemp=find(graph(:, onehop(i1))~=0);
                twohop=[twohop;twotemp];
            end
            twohop=unique(twohop);
            twohop(twohop==vInd)=[];
            
%              if isempty(twohop) %检测两跳邻居是否为空
%                  tmpTbl2 =0;
%                 tempM =onehop;  
%                 MarkovBlanket(vInd,unique(tempM))=1;
%              else %不为空
                tmpTbl2 = colorTbl(twohop);       % 当前顶点vInd的两跳邻接点的着色表
            
                tempM =[onehop;twohop];     %当前顶点的 马尔科夫毯 
                 MarkovBlanket(vInd,unique(tempM))=1;
           % end
            if 0 == sum(tmpTbl==cInd)&& sum(tmpTbl2==cInd)==0                % vInd的邻接点都尚未着当前色cInd
                colorTbl(vInd) = cInd;                  % 顶点vInd着色cInd
            end
        end
    end
    cInd = cInd + 1;
end