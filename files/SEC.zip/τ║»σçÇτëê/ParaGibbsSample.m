function    [Ourx,SerCoverage, Robustness, RC,SPCost, ADCost]=ParaGibbsSample(tau, MaxIter, FeasiblePolicy, QueueSP,QueueAD, OurxPre,V,ComRobust,ComCover,DemService,WeightRobust)

%PhysicalG： N*N matrix
% MaxIter:最大循环次数
%FeasiblePolicy，所有卫星的所有可行策略集合 2^K,K,N
%QueueSP ，放置成本队列 1,K
%QueueAD, 调整成本 1,K
%OurxPre ，上个时隙的放置策略 N K
%,V, lyapunov 参数
%ComRobust,当前时隙的鲁棒性 N N K 
%ComCover, 当前时隙覆盖 N M
%DemService， 当前时刻的各地区的请求 K，M
global M; % 地面区域个数
global N; % 卫星个数N
global T; % 时隙总数
global K; % 服务个数总数

RC_iter=zeros(1,MaxIter);

SerCoverage_iter=zeros(1,MaxIter);
Robustness_iter=zeros(1,MaxIter);
SPCost_iter=zeros(MaxIter,K);
ADCost_iter=zeros(MaxIter,K);

Ourx=zeros(N,K);

%给定初始策略
for i=1:N
%Ourx(i,:)=FeasiblePolicy(1,:,i);
Ourx(i,:)=zeros(1,K);
end

%-------------parallel Gibbs sampling-----------------
        PhysicalG(:,:)= sum(ComRobust,3); % 计算物理网络连接
        PhysicalG(PhysicalG~=0) = 1; 
        
        %---------------Graph Coloring-----------------------
        %确定马尔科夫毯,和分组情况
         [ColoringRecord, MarkovBlanket]=GreedyColoring(PhysicalG);%着色标记
         L=max(ColoringRecord); % 着色分组数
         %-----------------------------------------
         
        for i1=1:MaxIter
           %tau=i1^2;
             tau=30*i1;
            for i2=1:L  %对于每个着色组
                
                for i3= 1:N %对于每个着色组里的成员
                    if  ColoringRecord(i3)==i2 %在当前的着色组
                        
                        FeasibleX=FeasiblePolicy(:,:,i3);
                        FeasibleX(all(FeasibleX == 0, 2),:) = []; %删除全零行
                        
                       % FeasibleX(size(FeasibleX,1)+1,:)=zeros(1,K);%增加全零策略
                        if ~isempty(FeasibleX)  
                             Utility=zeros(size(FeasibleX,1),N);
                             for f=1:size(FeasibleX,1) %计算效用，计算概率
                  
                                 tempComRobust=shiftdim(ComRobust(i3,:,:));
                
                                  Utility(f,i3)=sum(sum(FeasibleX(f,:)).*QueueSP(:)+QueueAD(:).*sum(xor(FeasibleX(f,:), OurxPre(i3,:))))-0.5*V.*sum(sum(WeightRobust.*Ourx*diag(FeasibleX(f,:))*DemService.*tempComRobust))...
                                             -V.*sum(sum(diag(FeasibleX(f,:))*DemService*diag(ComCover(i3,:))));
%                                       %  QueueSP;
%                                         QueueAD;
                                 Ourxtemp=Ourx;
                                 Ourxtemp(i3,:)=FeasibleX(f,:);
                                 for i4=1:N
                                      if PhysicalG(i3,i4)==1 %只需要一跳邻居的效用函数
                                         tempComRobust=shiftdim(ComRobust(i4,:,:));
                                                      
                                         Utility(f,i4)=sum(QueueSP(:).*sum(Ourx(i4,:))+QueueAD(:).*sum(xor(Ourx(i4,:), OurxPre(i4,:))))-0.5*V.*sum(sum(WeightRobust.*Ourxtemp*diag(Ourx(i4,:))*DemService.*tempComRobust))...
                                                     -V.*sum(sum(diag(Ourx(i4,:))*DemService*diag(ComCover(i4,:))));
                                      end
                                 end
                           
                             end
                          %计算概率
                            Prob=zeros(1,size(FeasibleX,1));
                            MaxU=sum(sum(abs(Utility)))/1;
                           % if MaxU==0
                           %     Prob(f)=exp(-tau.*sum(Utility(f,:)))./ sum(exp(-tau.*sum(Utility(:,:),2)));
                           %     Ourx(i3,:)=zeros(1,K);
                           % else
                                  for f=1:size(FeasibleX,1)
                                       Prob(f)=exp(-tau.*sum(Utility(f,:)./MaxU))./ sum(exp(-tau.*sum(Utility(:,:)./MaxU,2)));
                                
%                                        dis1=exp(-tau.*sum(Utility(f,:)./MaxU));
%                                         dis2=sum(exp(-tau.*sum(Utility(:,:)./MaxU,2)));
                                  end
                           % end
                            if sum(isnan(Prob))>=1 %检查异常值
                                Prob=1/size(FeasibleX,1)*ones(1,size(FeasibleX,1));
                            end
                        
%                                 MaxU;
%                                 disp3=exp(-tau.*sum(Utility(:,:)./MaxU,2));
%                                 Prob;
%                                disp4=sum(Prob);
%                            
                             indexf=randsrc(1,1,[1:size(FeasibleX,1); Prob]); %根据概率确定一个决策
                             Ourx(i3,:)=FeasibleX(indexf,:);
                        end
                    else %不属于当前着色组
                      
                        
                    end
                end
            end
          [RC_iter(i1),SerCoverage_iter(i1),Robustness_iter(i1),SPCost_iter(i1,:),ADCost_iter(i1,:)]=RCcompute(Ourx,OurxPre, DemService,WeightRobust,ComCover,ComRobust);  
      end
        
        %计算最优策略的服务覆盖
 [RC,SerCoverage,Robustness,SPCost,ADCost]=RCcompute(Ourx,OurxPre, DemService,WeightRobust,ComCover,ComRobust);
 
% RC_iter,SerCoverage_iter,Robustness_iter;SPCost_iter;ADCost_iter;
%  for i1=1:MaxIter
%  ave_RC(i1)=sum(RC_iter(1:i1))/i1;
%  end
% save('tau5002.mat','ave_RC')
 
%figure()
%plot(ave_RC)
       
       
                                         