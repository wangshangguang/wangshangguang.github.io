function [RC,SerCoverage,Robustness,SPCost,ADCost]=RCcompute(Ourx,OurxPre, DemService,WeightRobust,ComCover,ComRobust)
global M; % 地面区域个数
 global N; % 卫星个数N
 global T; % 时隙总数
 global K; % 服务个数总数
  %计算策略的服务覆盖
    SerCoverage=0;
    Robustness=0;
    RC=0;
    SPCost=zeros(1,K);
     ADCost=zeros(1,K);
        for i1=1:N
         tempComRobust=shiftdim(ComRobust(i1,:,:));
        SerCoverage=SerCoverage+sum(sum(diag(Ourx(i1,:))*DemService*diag(ComCover(i1,:))));%根据论文里的公式
       Robustness= Robustness+0.5*sum(sum(WeightRobust.*Ourx*diag(Ourx(i1,:))*DemService.*tempComRobust));%根据论文里的公式
        
        end
      RC=SerCoverage+Robustness;%按RC的公式计算
       %计算 成本
       SPCost=sum(Ourx);
       ADCost=sum(xor(Ourx, OurxPre));