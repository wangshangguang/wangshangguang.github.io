package org.cloudbus.cloudsim.CKP.datacenter;

/*
 * @author za
 * a virtual link between two VM 
 * 
 */
public class VMLink {

	private int srcVM;	
	
	private int destVM;2
	
	private int srcHost;	
	
	private int destHost;
	
	private float minDelay = 0;

	private float minBw = 0;
	
	public VMLink(int srcVM, int destVM, int srcHost, int destHost,float minDelay,float minBw){
		this.srcVM = srcVM;
		this.destVM = destVM;
		this.srcHost = srcHost;
		this.destHost = destHost;
		this.minDelay = minDelay;
		this.minBw = minBw;
	}



	public int getSrcVM() {
		return srcVM;
	}



	public void setSrcVM(int srcVM) {
		this.srcVM = srcVM;
	}



	public int getDestVM() {
		return destVM;
	}



	public void setDestVM(int destVM) {
		this.destVM = destVM;
	}



	public int getSrcHost() {
		return srcHost;
	}



	public void setSrcHost(int srcHost) {
		this.srcHost = srcHost;
	}



	public int getDestHost() {
		return destHost;
	}



	public void setDestHost(int destHost) {
		this.destHost = destHost;
	}



	public float getMinDelay() {
		return minDelay;
	}

	public void setMinDelay(float minDelay) {
		this.minDelay = minDelay;
	}

	public float getMinBw() {
		return minBw;
	}

	public void setMinBw(float minBw) {
		this.minBw = minBw;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VMLink other = (VMLink) obj;
		
		if(this.srcHost == other.srcHost 
				&& this.destVM == other.destHost
				&& this.srcVM == other.srcVM
				&& this.destVM == other.destVM)
			return true;
		return false;
		
		
	}
	
	

}
