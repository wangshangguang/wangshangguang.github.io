package org.cloudbus.cloudsim.CKP.datacenter.service;

import java.util.ArrayList;
import java.util.List;

public class AppNetCloudlet {
	public int appId;
	public int userID;
	public double baseSystemSize;
	public double diskSize;
	public List<NetworkCloudlet> cloudletList;
	

	public AppNetCloudlet(int appId , int userID, double baseSystemSize,double diskSize) {
		this.appId = appId;
		this.userID = userID;
		this.baseSystemSize = baseSystemSize;
		this.diskSize = diskSize;
		cloudletList = new ArrayList<NetworkCloudlet>();
	}

	public List<NetworkCloudlet> getCloudletList() {
		return cloudletList;
	}

	public void setCloudletList(List<NetworkCloudlet> cloudletList) {
		this.cloudletList = cloudletList;
	}
	
	public void addCloudlet( NetworkCloudlet cloudlet) {
		this.cloudletList.add(cloudlet);
	}
	

}
