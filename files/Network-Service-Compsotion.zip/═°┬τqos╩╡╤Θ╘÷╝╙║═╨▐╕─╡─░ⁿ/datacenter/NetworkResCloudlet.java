package org.cloudbus.cloudsim.CKP.datacenter;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.ResCloudlet;

public class NetworkResCloudlet extends ResCloudlet {
	private NetworkVm vm;
	
	private CloudletState cloudletState;
	
	private double previousTime;
	
//	private boolean waiting;

	
	public NetworkResCloudlet(Cloudlet cloudlet, NetworkVm vm) {
		super(cloudlet);
		this.vm = vm;
		this.cloudletState = new CloudletState();
		previousTime = 0.0;
	}

//	public boolean isWaiting() {
//		return waiting;
//	}
//
//	public void setWaiting(boolean waiting) {
//		this.waiting = waiting;
//	}

	public CloudletState getCloudletState() {
		return cloudletState;
	}

	public void setCloudletState(CloudletState cloudletState) {
		this.cloudletState = cloudletState;
	}

	public NetworkVm getVm() {
		return vm;
	}

	public void setVm(NetworkVm vm) {
		this.vm = vm;
	}
	
	public double getPreviousTime() {
		return previousTime;
	}

	public void setPreviousTime(double previousTime) {
		this.previousTime = previousTime;
	}


}
