package org.cloudbus.cloudsim.CKP.datacenter;


public class CloudletState {
	private State state;
	
	public CloudletState(){
		state = new RunningState();
	}
	
	public void Handle(String context, boolean hasSystemImage){
		state.Handle(context, hasSystemImage);
	}
	

	public abstract class State
	 {
		 public abstract void Handle(Stri ng context,  boolean hasSystemImage);
	 }
	 
	 public class StartState extends State{

		@Override
		public void Handle(String context,  boolean hasSystemImage) {
			if(Config.CheckpointStyle == 0 || Config.CheckpointStyle == 1|| Config.CheckpointStyle == 2){
				if(context.equals("CloudletImageArrive") || context.equals("AppImageArrive"))
					state = new RunningState();
			}
			else{
				if(context.equals("CloudletImageArrive"))
					state = new WaitingForAppImageState();
				else if(context.equals("AppImageArrive")){
					if(hasSystemImage)
						state = new WaitingForCloudletImageState();	
					else
						state = new RunningState();
				}
		    }
		}
		 
	 }
	 
	 public class WaitingForAppImageState extends State{

			@Override
			public void Handle(String context,  boolean hasSystemImage) {
				if(context.equals("AppImageArrive"))
					state = new RunningState();
				
			}
			 
		 }
	 
	 public class WaitingForCloudletImageState extends State{

			@Override
			public void Handle(String context,  boolean hasSystemImage) {
				if(context.equals("CloudletImageArrive"))
					state = new RunningState();
				
			}
			 
		 }
	 
	 public class RunningState extends State{

			@Override
			 public void Handle(String context,  boolean hasSystemImage) {
				
			}
			 
	}
	 
	 public void restart(){
		 state = new StartState();
	 }
	 

	 public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}


}
