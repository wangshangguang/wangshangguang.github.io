package org.cloudbus.cloudsim.CKP.datacenter;

public abstract class Data {
	private double size = 0;
	
	public Data(double size){
		this.size = size;
	}

	public double getSize() {
		return size;
	 }

	public void setSize(double size) {
		this.size = size;
	}

}
