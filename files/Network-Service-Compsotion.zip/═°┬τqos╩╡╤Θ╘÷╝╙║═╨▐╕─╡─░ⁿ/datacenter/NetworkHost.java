/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package org.cloudbus.cloudsim.CKP.datacenter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.cloudbus.cloudsim.Consts;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.ResCloudlet;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmScheduler;
import org.cloudbus.cloudsim.CKP.datacenter.service.AppNetCloudlet;
import org.cloudbus.cloudsim.CKP.datacenter.service.NetworkCloudlet;
import org.cloudbus.cloudsim.checkpoint.AppCheckpoint;
import org.cloudbus.cloudsim.checkpoint.CloudletCheckpoint;
import org.cloudbus.cloudsim.checkpoint.DCNetworkVisitor;
import org.cloudbus.cloudsim.checkpoint.FailureDistr;
import org.cloudbus.cloudsim.checkpoint.NonFailureDistr;
import org.cloudbus.cloudsim.checkpoint.RecordToLogger;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEvent;
import org.cloudbus.cloudsim.core.predicates.PredicateType;
import org.cloudbus.cloudsim.distributions.ContinuousDistribution;
import org.cloudbus.cloudsim.lists.PeList;
import org.cloudbus.cloudsim.lists.VmList;
import org.cloudbus.cloudsim.provisioners.BwProvisioner;
import org.cloudbus.cloudsim.provisioners.RamProvisioner;

/**
 * NetworkHost class extends Host to support simulation of networked datacenters. It executes
 * actions related to management of packets (send and receive)other than that of virtual machines
 * (e.g., creation and destruction). A host has a defined policy for provisioning memory and bw, as
 * well as an allocation policy for Pe's to virtual machines.
 * 
 * Please refer to following publication for more details:
 * 
 * Saurabh Kumar Garg and Rajkumar Buyya, NetworkCloudSim: Modelling Parallel Applications in Cloud
 * Simulations, Proceedings of the 4th IEEE/ACM International Conference on Utility and Cloud
 * Computing (UCC 2011, IEEE CS Press, USA), Melbourne, Australia, December 5-7, 2011.
 * 
 * @author Saurabh Kumar Garg
 * @since CloudSim Toolkit 3.0
 */
public class NetworkHost extends Host{
	
	public DataCenterLink inlink;

	public List<NetworkPacket> packetTosendLocal;

	public List<NetworkPacket> packetTosendGlobal;

	public List<NetworkPacket> packetrecieved;
	
	public List<HostPacket> packetToSend;

	public double memory;
	
	public double allocatedCKPStorage;

	public EdgeSwitch sw; // Edge switch in general

	public double bandwidth;// latency
	
	public Map<NetworkResCloudlet, CloudletCheckpoint> cloudletCheckpointCenter = new HashMap<NetworkResCloudlet, CloudletCheckpoint>();
	
	public Map<AppNetCloudlet, AppCheckpoint> appCheckpointCenter = new HashMap<AppNetCloudlet, AppCheckpoint>();
	

	/** time when last job will finish on CPU1 **/
	public List<Double> CPUfinTimeCPU = new ArrayList<Double>();

	public double fintime = 0;
	
	public int belongToPad;
	
	public double failureFrequency = 0;
	
	public double lastFailureTime = Double.NEGATIVE_INFINITY;
	
	public FailureDistr failureDistri;
	
	public int hasAllocatedVM = 0;
	

	public NetworkHost(
			String name,
			RamProvisioner ramProvisioner,
			BwProvisioner bwProvisioner,
			long storage,
			List<? extends Pe> peList,
			VmScheduler vmScheduler,
			int worldX,
			int worldY,
			int belongToPad) {
		super(name, ramProvisioner, bwProvisioner, storage, peList, vmScheduler, worldX, worldY);

		packetrecieved = new ArrayList<NetworkPacket>();
		packetTosendGlobal = new ArrayList<NetworkPacket>();
		packetTosendLocal = new ArrayList<NetworkPacket>();
		packetToSend = new ArrayList<HostPacket>();
		bandwidth = NetworkConstants.BandWidthEdgeHost;
		failureDistri = new NonFailureDistr();
		allocatedCKPStorage = 0;
		this.belongToPad = belongToPad;

	}

	/**
	 * Requests updating of processing of cloudlets in the VMs running in this host.
	 * 
	 * @param currentTime the current time
	 * 
	 * @return expected time of completion of the next cloudlet in all VMs in this host.
	 *         Double.MAX_VALUE if there is no future events expected in th is host
	 * 
	 * @pre currentTime >= 0.0
	 * @post $none
	 */
	@Override
	public double updateVmsProcessing(double currentTime) {
		if(this.isFailed()){			
			return currentTime+NetworkConstants.EXECUTE_STEP;
		}
		
		double smallerTime = Double.MAX_VALUE;
		// insert in each vm packet recieved
		recvpackets();
		for (Vm vm : super.getVmList()) {
			double time = ((NetworkVm) vm).updateVmProcessing(currentTime, getVmScheduler()
					.getAllocatedMipsForVm(vm));
			if (time > 0.0 && time < smallerTime) {
				smallerTime = time;
			}
		}
		// send the packets to other hosts/VMs
		sendpackets();

		return smallerTime;

	}
	
	public void updateVmsProcessingBeforeFailure(double currentTime) {		
		for (Vm vm : super.getVmList()) {
			NetworkCloudletSpaceSharedScheduler scheduler = (NetworkCloudletSpaceSharedScheduler)vm.getCloudletScheduler();
			for (ResCloudlet rcl : scheduler.getCloudletExecList()){
				NetworkResCloudlet nrcl = (NetworkResCloudlet)rcl;
				nrcl.setPreviousTime(CloudSim.clock());
		}
	}

	}

	/**
	 * Receives packet and forward it to the corresponding VM for processing host.
	 * 
	 * 
	 */
	private void recvpackets() {

		for (NetworkPacket hs : packetrecieved) {
			hs.pkt.recievetime = CloudSim.clock();
			Vm vm = VmList.getById(getVmList(), hs.pkt.virtualrecvid);
			
			if(hs.pkt.type == NetworkConstants.RECOVERY_CLOUDLIT){
//				System.out.println(CloudSim.clock());
				if(hs.pkt.data instanceof CloudletCheckpoint){
					CloudletCheckpoint ckp = (CloudletCheckpoint)hs.pkt.data;
					NetworkCloudlet cl = (NetworkCloudlet)ckp.getResCloudlet().getCloudlet();
					
					if(ckp.getResCloudlet().getVm().getHost().equals(this)){
//						ckp.getResCloudlet().setCloudletFinishedSoFar(ckp.getFinishedSoFar());

						RecordToLogger.logger.debug(this.getName() + "|" + ckp.getResCloudlet().getCloudletId()+" started from host "+ this.getId()+" with beginning point "+ckp.getFinishedSoFar());

						ckp.getResCloudlet().getCloudletState().Handle("CloudletImageArrive", cl.hasCloudletSystemImage);
					}

					if(ckp.getResCloudlet().getCloudletState().getState() instanceof CloudletState.RunningState){
//						if((hs.pkt.recievetime-hs.pkt.sendtime) > 10){
//							System.err.println("cloudlet image take long"+ckp.getResCloudlet().getPreviousTime()+"|"+CloudSim.clock());
//						}

//						System.err.println("cloudlet:" + ckp.getResCloudlet().getCloudletId()+" recovery time used:" 
//						+(CloudSim.clock() - ckp.getResCloudlet().getPreviousTime())+"packet trasfer used :"+(hs.pkt.recievetime-hs.pkt.sendtime)
//						+"| with start point"+ckp.getResCloudlet().getCloudletFinishedSoFar());
//						ckp.getResCloudlet().setPreviousTime(CloudSim.clock());
					}
				}
				else {
					AppCheckpoint ckp = (AppCheckpoint)hs.pkt.data;
					NetworkCloudlet cl = (NetworkCloudlet)ckp.getActiveCloudlet().getCloudlet();
					
					RecordToLogger.logger.debug(this.getName() + "|" + ckp.getActiveCloudlet().getCloudletId()+" started from host "+ this.getId()+" with appcheckpoint ");					
					
					if(ckp.getActiveCloudlet().getVm().getHost().equals(this)){
						ckp.getActiveCloudlet().getCloudletState().Handle("AppImageArrive", cl.hasCloudletSystemImage);
						
					}
					if(ckp.getActiveCloudlet().getCloudletState().getState() instanceof CloudletState.RunningState){
//						if((hs.pkt.recievetime-hs.pkt.sendtime)>10){
//							System.err.println("app image take long"+ckp.getActiveCloudlet().getPreviousTime()+"|"+CloudSim.clock());
//							Iterator iter =hs.arriveTime.iterator();
//							while (iter.hasNext()) {
//								Switch sw = (Switch) iter.next();
//								
//								System.err.println(sw.getName());
//								
//							}
//						}
//						System.err.println("cloudlet:" + ckp.getActiveCloudlet().getCloudletId()+" recovery time used:" 
//								+(CloudSim.clock() - ckp.getActiveCloudlet().getPreviousTime())+"packet trasfer used :"+(hs.pkt.recievetime-hs.pkt.sendtime)
//								+"| with start point"+ckp.getActiveCloudlet().getCloudletFinishedSoFar());

//						System.err.println((hs.pkt.recievetime-hs.pkt.sendtime)+"|"+ckp.getActiveCloudlet().getCloudletFinishedSoFar());
						ckp.getActiveCloudlet().setPreviousTime(CloudSim.clock());
					}
				}					
				
			}
			else if(hs.pkt.type == NetworkConstants.STORE_CHECKPOINT){
				if(hs.pkt.data instanceof CloudletCheckpoint){
					CloudletCheckpoint ckp = (CloudletCheckpoint)hs.pkt.data;
					if(ckp.getType() == NetworkConstants.SYSTEM_CHECKPOINT){
						this.cloudletCheckpointCenter.put(ckp.getResCloudlet(), ckp);

						RecordToLogger.logger.debug("host"+ this.getId() + " receive system checkpoint of cloulet" + ckp.getResCloudlet().getCloudlet().getCloudletId()+ " with has finished " + ckp.getFinishedSoFar() +" "+CloudSim.clock());
						
					}
					else{
						if(	this.cloudletCheckpointCenter.containsKey(ckp.getResCloudlet())){
							double sizeAfterMerge = this.cloudletCheckpointCenter.get(ckp.getResCloudlet()).getSize();
							
							ckp.setSize(sizeAfterMerge);
							
							this.cloudletCheckpointCenter.put(ckp.getResCloudlet(), ckp);

							RecordToLogger.logger.debug("host"+ this.getId() +  " receive delta checkpoint of cloulet" + ckp.getResCloudlet().getCloudlet().getCloudletId()+ " with has finished " + ckp.getFinishedSoFar()+" "+CloudSim.clock());
						}
						else{
							NetworkCloudlet cloudlet = (NetworkCloudlet)ckp.getResCloudlet().getCloudlet();
							cloudlet.hasCloudletSystemImage = false;
						}
					}
//					System.out.println("checkpoint from: "+ckp.getResCloudlet().getCloudletId());
				}
				else if(hs.pkt.data instanceof AppCheckpoint){
					AppCheckpoint ckp = (AppCheckpoint)hs.pkt.data;
					this.appCheckpointCenter.put(ckp.getAppCloudlet(), ckp);
					RecordToLogger.logger.debug("host"+ this.getId() +  " receive a app checkpoint of" + ckp.getAppCloudlet().appId +" "+CloudSim.clock());
//					System.out.println("checkpoint from: "+ckp.getResCloudlet().getCloudletId());
				}
			}
			
			// insertthe packet in recievedlist of VM
			
			if(hs.pkt.virtualrecvid > 0){
				List<HostPacket> pktlist = ((NetworkCloudletSpaceSharedScheduler) vm.getCloudletScheduler()).pktrecv
						.get(hs.pkt.virtualrecvid);
	
				if (pktlist == null) {
					pktlist = new ArrayList<HostPacket>();
					((NetworkCloudletSpaceSharedScheduler) vm.getCloudletScheduler()).pktrecv.put(
							hs.pkt.virtualrecvid,
							pktlist);
	
				}
				pktlist.add(hs.pkt);
			}

		}
		packetrecieved.clear();
	}

	/**
	 * Send packet check whether a packet belongs to a local VM or to a VM hosted on other machine.
	 * 
	 * 
	 */
	private void sendpackets() {
		for(HostPacket pkt : packetToSend){
			NetworkPacket hpkt = new NetworkPacket(pkt);
			Vm vm2 = VmList.getById(this.getVmList(), hpkt.recievervmid);
			if (vm2 != null) {
				packetTosendLocal.add(hpkt);
			} else {
				packetTosendGlobal.add(hpkt);
			}
		}
		packetToSend.clear();

		for (Vm vm : super.getVmList()) {
			for (Entry<Integer, List<HostPacket>> es : ((NetworkCloudletSpaceSharedScheduler) vm
					.getCloudletScheduler()).pkttosend.entrySet()) {
				List<HostPacket> pktlist = es.getValue();
				for (HostPacket pkt : pktlist) {
					pkt.sender = this.getId();
					pkt.virtualsendid = vm.getId();
					NetworkPacket hpkt = new NetworkPacket(pkt);
					Vm vm2 = VmList.getById(this.getVmList(), hpkt.recievervmid);
					if (vm2 != null) {
						packetTosendLocal.add(hpkt);
					} else {
						packetTosendGlobal.add(hpkt);
					}
				}
				pktlist.clear();

			}

		}

		boolean flag = false;

		for (NetworkPacket hs : packetTosendLocal) {
			flag = true;
			hs.stime = hs.rtime;
			hs.pkt.recievetime = CloudSim.clock();
			if(hs.pkt.virtualrecvid < 0){
				this.packetrecieved.add(hs);
				continue;
			}
			// insertthe packet in recievedlist
			Vm vm = VmList.getById(getVmList(), hs.pkt.virtualrecvid);

			List<HostPacket> pktlist = ((NetworkCloudletSpaceSharedScheduler) vm.getCloudletScheduler()).pktrecv
					.get(hs.pkt.sender);
			if (pktlist == null) {
				pktlist = new ArrayList<HostPacket>();
				((NetworkCloudletSpaceSharedScheduler) vm.getCloudletScheduler()).pktrecv.put(
						hs.pkt.sender,
						pktlist);
			}
			pktlist.add(hs.pkt);

		}
		if (flag) {
			for (Vm vm : super.getVmList()) {
				vm.updateVmProcessing(CloudSim.clock(), getVmScheduler().getAllocatedMipsForVm(vm));
			}
		}

		// Sending packet to other VMs therefore packet is forwarded to a Edge switch
		packetTosendLocal.clear();
		double avband = bandwidth / packetTosendGlobal.size();
		for (NetworkPacket hs : packetTosendGlobal) {
			double delay = (hs.pkt.data.getSize()) / avband;
			NetworkConstants.totaldatatransfer += hs.pkt.data.getSize();
			CloudSim.send(getDatacenter().getId(), sw.getId(), delay, CloudSimTags.Network_Event_UP, hs);
//			System.out.println("$$$$$$$$$$$$$$$$$$$$$$$");
			// send to switch with delay
		}
		packetTosendGlobal.clear();
	}

	public double getMaxUtilizationAmongVmsPes(Vm vm) {
		return PeList.getMaxUtilizationAmongVmsPes(getPeList(), vm);
	}
	
	@Override
	public void processEvent(SimEvent ev) {
		if(isFailed())
			return;
		
		switch (ev.getTag()) {
		// Resource characteristics request
			case CloudSimTags.MAKE_CHECKPOINT:
				makeCloudletCheckpoint(ev);
				break;
			case CloudSimTags.MAKE_APP_CHECKPOINT:
				makeAppCheckpoint(ev);
				break;
			case CloudSimTags.MAKE_SYSTEM_CHECKPOINT:
				makeSystemCheckpoint(ev);
				break;
			case CloudSimTags.MAKE_DELTA_CHECKPOINT:
				makeDeltaCheckpoint(ev);
				break;
			case CloudSimTags.RECOVERY_CLOUDLET_POINT_SEDN:
				recoveryCloudletPointSend(ev);
				break;
			case CloudSimTags.RECOVERY_APP_POINT_SEDN:
				recoveryAppPointSend(ev);
				break;
			case CloudSimTags.FETCH_APP_CHECKPOINT:
				appPointFetchAck(ev);
				break;
			case CloudSimTags.FETCH_CLOUDLET_CHECKPOINT:
				clouletPointFetchAck(ev);
				break;
			case CloudSimTags.Network_Event_UP:
				sendpackets();
				break;
			case CloudSimTags.Network_Event_DOWN:
				recvpackets();
				break;

			// other unknown tags are processed by this method
			default:
				break;
		}

	}
	
	protected void clouletPointFetchAck(SimEvent ev){
		NetworkResCloudlet nrcl = (NetworkResCloudlet)ev.getData();
		
		long finishedSoFar = 0;
		if(!cloudletCheckpointCenter.containsKey(nrcl))
			return;
		
		CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.Network_Event_UP));
		schedule(getId(), 0, CloudSimTags.Network_Event_UP);
		
		finishedSoFar = cloudletCheckpointCenter.get(nrcl).getFinishedSoFar();
//			System.out.println(nrcl.getCloudletId()+" move to "+nrcl.getVm().getHost().getId()+" restart from "+finishedSoFar);
		
		
		CloudletCheckpoint ckp = new CloudletCheckpoint(nrcl,NetworkConstants.SYSTEM_CHECKPOINT, finishedSoFar, 1024);
		HostPacket pkt = new HostPacket(
				NetworkConstants.STORE_CHECKPOINT,
				this.getId(),
				ev.getSource(),
				-1, 
				-1,
				nrcl.getCloudletId(),
				CloudSim.clock(),
				-1,
				ckp);
		packetToSend.add(pkt);
	}
	
	protected void appPointFetchAck(SimEvent ev){
		AppNetCloudlet acl = (AppNetCloudlet)ev.getData();
		
		if(!appCheckpointCenter.containsKey(acl))
			return;
		
		CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.Network_Event_UP));
		schedule(getId(), 0, CloudSimTags.Network_Event_UP);
		
		long finishedSoFar = 0;
		finishedSoFar = appCheckpointCenter.get(acl).getFinishedSoFar();
//		System.out.println(nrcl.getCloudletId()+" move to "+nrcl.getVm().getHost().getId()+" restart from "+finishedSoFar);
	
		
		AppCheckpoint ckp = new AppCheckpoint(acl,finishedSoFar, 1024);
		HostPacket pkt = new HostPacket(
				NetworkConstants.STORE_CHECKPOINT,
				this.getId(),
				ev.getSource(),
				-1, 
				-1,
				acl.appId,
				CloudSim.clock(),
				-1,
				ckp);
		packetToSend.add(pkt);
		
	}
	
	protected void recoveryCloudletPointSend(SimEvent ev){
		NetworkResCloudlet nrcl = (NetworkResCloudlet)ev.getData();
		
		CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.Network_Event_UP));
		schedule(getId(), 0, CloudSimTags.Network_Event_UP);
		
		long finishedSoFar = 0;
		if(cloudletCheckpointCenter.containsKey(nrcl)){
			finishedSoFar = cloudletCheckpointCenter.get(nrcl).getFinishedSoFar();
//			System.out.println(nrcl.getCloudletId()+" move to "+nrcl.getVm().getHost().getId()+" restart from "+finishedSoFar);
		}
		
		CloudletCheckpoint ckp = new CloudletCheckpoint(nrcl,NetworkConstants.SYSTEM_CHECKPOINT, finishedSoFar, 1024);
		HostPacket pkt = new HostPacket(
				NetworkConstants.RECOVERY_CLOUDLIT,
				this.getId(),
				nrcl.getVm().getHost().getId(),
				-1, 
				-1,
				nrcl.getCloudletId(),
				CloudSim.clock(),
				-1,
				ckp);
		
		packetToSend.add(pkt);
	}
	
	protected void recoveryAppPointSend(SimEvent ev){
		NetworkResCloudlet nrcl = (NetworkResCloudlet)ev.getData();
		NetworkCloudlet nc = (NetworkCloudlet)nrcl.getCloudlet();
		
		CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.Network_Event_UP));
		schedule(getId(), 0, CloudSimTags.Network_Event_UP);
		
		long finishedSoFar = 0;
		if(appCheckpointCenter.containsKey(nc.belongToApp)){
			finishedSoFar = appCheckpointCenter.get(nc.belongToApp).getFinishedSoFar();
//			System.out.println(nrcl.getCloudletId()+" move to "+nrcl.getVm().getHost().getId()+" restart from "+finishedSoFar);
		}
		
		AppCheckpoint ckp = new AppCheckpoint(nc.belongToApp,finishedSoFar, 1024);
		ckp.setActiveCloudlet(nrcl);
		HostPacket pkt = new HostPacket(
				NetworkConstants.RECOVERY_CLOUDLIT,
				this.getId(),
				nrcl.getVm().getHost().getId(),
				-1, 
				-1,
				nrcl.getCloudletId(),
				CloudSim.clock(),
				-1,
				ckp);
		
		packetToSend.add(pkt);
	}

	
	public void makeAppCheckpoint(SimEvent ev){
		NetworkCloudlet cl = (NetworkCloudlet)ev.getData();
		
		CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.Network_Event_UP));
		schedule(getId(), 0, CloudSimTags.Network_Event_UP);
		
//		List<Integer> imageStoragehosts = ((NetworkDatacenter)vm.getHost().getDatacenter()).getCheckpointimageindex().getAPPCheckpointImageStorageNode(cl.belongToApp.appId);
		AppCheckpoint ckp = new AppCheckpoint(cl.belongToApp,0, cl.belongToApp.baseSystemSize+cl.belongToApp.diskSize);		
		
		HostPacket pkt = new HostPacket(
				NetworkConstants.STORE_CHECKPOINT,
				0,
				ev.getSource(),
				0, 
				-1,
				cl.getCloudletId(),
				CloudSim.clock(),
				-1,
				ckp);
				
		packetToSend.add(pkt);
	}
	
	
	public void makeCloudletCheckpoint(SimEvent ev){
		this.updateVmsProcessing(CloudSim.clock());
		NetworkResCloudlet rcl = (NetworkResCloudlet)ev.getData();
		NetworkCloudlet cl = (NetworkCloudlet)rcl.getCloudlet();
		
		if(cl.hasCloudletSystemImage && Config.CheckpointStyle > 1){
			makeDeltaCheckpoint(ev);
		}
		else
			makeSystemCheckpoint(ev);
	}
	
	public void makeSystemCheckpoint(SimEvent ev){
		
		NetworkResCloudlet rcl = (NetworkResCloudlet)ev.getData();
		NetworkCloudlet cl = (NetworkCloudlet)rcl.getCloudlet();
		NetworkVm vm = (NetworkVm)rcl.getVm();
		NetworkCloudletSpaceSharedScheduler scheduler = (NetworkCloudletSpaceSharedScheduler)vm.getCloudletScheduler();
		
		if(!(rcl.getCloudletState().getState() instanceof CloudletState.RunningState))
			return;
		
		CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.Network_Event_UP));
		schedule(getId(), 0, CloudSimTags.Network_Event_UP);
		
		cl.lastCheckpointMakingTime = CloudSim.clock();
		cl.hasCloudletSystemImage = true;
		
		List<Integer> imageStoragehosts = ((NetworkDatacenter)vm.getHost().getDatacenter()).getCheckpointimageindex().getCloudletCheckpointImageStorageNode(cl.getCloudletId());
		double size = 0;
		if( Config.CheckpointStyle == 3){
			size = 143*(Math.log(NetworkConstants.CHECKPOINT_INTERVAL)/Math.log(10))-254;
		}
		else{
			size = cl.belongToApp.baseSystemSize + cl.belongToApp.diskSize;
			cl.lastFinishedSoFar = rcl.getCloudletFinishedSoFar();
		}
		
		CloudletCheckpoint ckp = new CloudletCheckpoint(rcl,NetworkConstants.SYSTEM_CHECKPOINT,rcl.getCloudletFinishedSoFar(), size);
		String indent="   ";
		RecordToLogger.logger.debug("host"+this.getId()+"making a system checkpoint of cloudlet"+indent+ckp.getResCloudlet().getCloudletId()+indent +indent+ ckp.getFinishedSoFar()+indent+indent+ckp.getSize());
		
		List<HostPacket> pktlist = scheduler.pkttosend.get(vm.getId());
		if (pktlist == null) {
			pktlist = new ArrayList<HostPacket>();
		}
		
		for(int i = 0; i < imageStoragehosts.size(); i++){
			HostPacket pkt = new HostPacket(
					NetworkConstants.STORE_CHECKPOINT,
					0,
					imageStoragehosts.get(i),
					0, 
					-1,
					cl.getCloudletId(),
					CloudSim.clock(),
					-1,
					ckp);
			pktlist.add(pkt);
		}
		
		scheduler.pkttosend.put(vm.getId(), pktlist);
	}
	
	public void makeDeltaCheckpoint(SimEvent ev){	
		NetworkResCloudlet rcl = (NetworkResCloudlet)ev.getData();
		NetworkCloudlet cl = (NetworkCloudlet)rcl.getCloudlet();
		NetworkVm vm = (NetworkVm)rcl.getVm();
		NetworkHost host =  (NetworkHost)vm.getHost();
		NetworkCloudletSpaceSharedScheduler scheduler = (NetworkCloudletSpaceSharedScheduler)vm.getCloudletScheduler();
		
		if(!(rcl.getCloudletState().getState() instanceof CloudletState.RunningState))
			return;
		
		List<Integer> imageStoragehosts = ((NetworkDatacenter)vm.getHost().getDatacenter()).getCheckpointimageindex().getCloudletCheckpointImageStorageNode(cl.getCloudletId());		
		double size = 143*(Math.log(CloudSim.clock()- cl.lastCheckpointMakingTime)/Math.log(10))-254;
		if(size < 0)
			return;
		
		CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.Network_Event_UP));
		schedule(getId(), 0, CloudSimTags.Network_Event_UP);
		
		CloudletCheckpoint ckp = new CloudletCheckpoint(rcl,NetworkConstants.DELTA_CHECKPOINT,rcl.getCloudletFinishedSoFar(), size);
		cl.lastCheckpointMakingTime = CloudSim.clock();
		cl.lastFinishedSoFar = rcl.getCloudletFinishedSoFar();
				
		String indent="   ";
		RecordToLogger.logger.debug("host:" + this.getId()+"making a delta checkpoint of cloulet "+indent+ckp.getResCloudlet().getCloudletId()+indent +indent+ ckp.getFinishedSoFar()+indent+indent+ckp.getSize());
		
		List<HostPacket> pktlist = scheduler.pkttosend.get(vm.getId());
		if (pktlist == null) {
			pktlist = new ArrayList<HostPacket>();
		}
		
		for(int i = 0; i < imageStoragehosts.size(); i++){
			HostPacket pkt = new HostPacket(
					NetworkConstants.STORE_CHECKPOINT,
					0,
					imageStoragehosts.get(i),
					0, 
					-1,
					cl.getCloudletId(),
					CloudSim.clock(),
					-1,
					ckp);
			
			pktlist.add(pkt);
		}
		
		scheduler.pkttosend.put(vm.getId(), pktlist);
	}
	
	public void sendInfo(int entityId, int cloudSimTag, Object data) {
		send(entityId, 0, cloudSimTag, data);
	}
	
	public void clear(){
		packetrecieved.clear();
		for (Vm vm : super.getVmList()) {
			for (Entry<Integer, List<HostPacket>> es : ((NetworkCloudletSpaceSharedScheduler) vm
					.getCloudletScheduler()).pkttosend.entrySet()) {
				List<HostPacket> pktlist = es.getValue();
				pktlist.clear();
			}
		}
		packetTosendLocal.clear();
		packetTosendGlobal.clear();
	}
	


	public Map<NetworkResCloudlet, CloudletCheckpoint> getCloudletCheckpointCenter() {
		return cloudletCheckpointCenter;
	}

	public void setCloudletCheckpointCenter(
			Map<NetworkResCloudlet, CloudletCheckpoint> cloudletCheckpointCenter) {
		this.cloudletCheckpointCenter = cloudletCheckpointCenter;
	}

	public Map<AppNetCloudlet, AppCheckpoint> getAppCheckpointCenter() {
		return appCheckpointCenter;
	}

	public void setAppCheckpointCenter(
			Map<AppNetCloudlet, AppCheckpoint> appCheckpointCenter) {
		this.appCheckpointCenter = appCheckpointCenter;
	}
	
	public List<Integer> getFreeVms(){
		List<Integer> freeVms = new ArrayList<Integer>();
		for (Vm vm : super.getVmList()) {
			if(vm.getCloudletScheduler() instanceof NetworkCloudletSpaceSharedScheduler){
				NetworkCloudletSpaceSharedScheduler scheduler = (NetworkCloudletSpaceSharedScheduler)vm.getCloudletScheduler();
				if(scheduler.getCloudletExecList().size() == 0)
					freeVms.add(vm.getId());
			}
		}
		return freeVms;
	}
	
	@Override
	public void accept(DCNetworkVisitor visitor, Object data) {
		visitor.visit(this, data);
		
	}
}
