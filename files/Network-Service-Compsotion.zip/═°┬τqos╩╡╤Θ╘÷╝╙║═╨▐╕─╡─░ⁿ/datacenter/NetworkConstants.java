/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package org.cloudbus.cloudsim.CKP.datacenter;

public class NetworkConstants {

	public static int maxhostVM = 4;
	public static int HOST_PEs = 8;

	public static double maxMemperVM = 1024 * 1024;// kb

	public static int currentCloudletId = 0;
	public static int currentAppId = 0;

	// stage type
	public static final int EXECUTION = 0; 
	public static final int WAIT_SEND = 1;
	public static final int WAIT_RECV = 2;
	public static final int FINISH = -2;

	// number of switches at each level
	public static final int ROOT_LEVEL = 0;
	public static final int Agg_LEVEL = 1;
	public static final int EDGE_LEVEL = 2;

	public static final int PES_NUMBER = 4;
	public static final int FILE_SIZE = 300;
	public static final int OUTPUT_SIZE = 300;

	public static final int COMMUNICATION_LENGTH = 1;

	public static boolean BASE = true;

	public static long BandWidthEdgeHost = 1000;//M
	public static long BandWidthEdgeAgg = 10000;// 	
	public static long BandWidthAggRoot = 10000;// 
	public static long BandWidthRootStorageCenter = 10000;
	
//	public static double SwitchingDelayRoot = 0;
//	public static double SwitchingDelayAgg = 0;// .00245
//	public static double SwitchingDelayEdge = 0;// ms
	

	public static double SwitchingDelayRootToStorageCenter = 5;
	public static double SwitchingDelayRoot = 5;
	public static double SwitchingDelayAgg = 3;// 
	public static double SwitchingDelayEdge = 1;// s

	public static double EdgeSwitchPort = 4;// number of host

	public static double AggSwitchPort = 1;// number of Edge

	public static double RootSwitchPort = 1;// number of Agg

	public static double seed = 199;

	public static boolean logflag = false;

	public static int iteration = 10;
	public static int nexttime = 1000;

	public static int totaldatatransfer = 0;
	
	public static int EXECUTE_STEP = 200;//24000
	
	public static int CHECKPOINT_INTERVAL = 600;
	
	public static int WEAK_HOST_RATIO = 10;
	
	public static final int PACKET_TYPE_BASE = 0;
	
	public static final int STORE_CHECKPOINT = PACKET_TYPE_BASE + 55;
	
	public static final int RECOVERY_CLOUDLIT = PACKET_TYPE_BASE + 56;
	
	public static final int SYSTEM_CHECKPOINT = PACKET_TYPE_BASE + 57;
	
	public static final int DELTA_CHECKPOINT = PACKET_TYPE_BASE + 58;
}
