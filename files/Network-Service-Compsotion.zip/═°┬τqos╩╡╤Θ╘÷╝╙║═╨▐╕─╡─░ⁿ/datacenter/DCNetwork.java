/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package org.cloudbus.cloudsim.CKP.datacenter;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.CKP.datacenter.service.AppNetCloudlet;
import org.cloudbus.cloudsim.checkpoint.AppCheckpoint;
import org.cloudbus.cloudsim.checkpoint.CentralCheckpointStorageIndex;
import org.cloudbus.cloudsim.checkpoint.CloudletCheckpoint;
import org.cloudbus.cloudsim.checkpoint.RecordToLogger;
import org.cloudbus.cloudsim.checkpoint.centralexample.Carrier;
import org.cloudbus.cloudsim.core.CloudSim;

import java.sql.*;
/**
 * This class represents an graph containing nodes and edges, used for input with an network-layer
 * Graphical-Output Restricions! EdgeColors: GraphicalProperties.getColorEdge NodeColors:
 * GraphicalProperties.getColorNode
 * 
 * @author Thomas Hohnstein
 * @since CloudSim Toolkit 1.0
 */
public class DCNetwork {

	protected List<DataCenterLink> linkList = null;

	protected List<DataCenterNode> nodeList = null;
	
	protected List<RootSwitch> rootSwitchList = null;
	
	protected List<AggregateSwitch> aggregateSwitchList = null;
	
	protected List<EdgeSwitch> edgeSwitchList = null;
	
	protected List<? extends Host> hostList = null;
	
	protected NetworkStorageHost storageCenter = null;


	/**
	 * just the constructor to create an empty graph-object
	 */
	public DCNetwork(NetworkDatacenter datacenter) {
		linkList = new ArrayList<DataCenterLink>();
		nodeList = new ArrayList<DataCenterNode>();
		rootSwitchList = new ArrayList<RootSwitch>();
		aggregateSwitchList = new ArrayList<AggregateSwitch>();
		edgeSwitchList = new ArrayList<EdgeSwitch>();
		try {
			createDCNetwork(datacenter);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void createDCNetwork(NetworkDatacenter datacenter) throws IOException {		
		int portNum = Config.portNum;
		
		int rootSwitchNum = (portNum/2)*(portNum/2);
		
		int aggregateSwitchNum = portNum*(portNum/2);
		
		int edgeSwitchNum = portNum*(portNum/2);

		int x = 2;
		for(int y = 0; y < edgeSwitchNum; y++){
			EdgeSwitch edgeSwitch = new EdgeSwitch("edgeswitch_"+x+"_"+y,
					2,
					datacenter,
					x,y);
			this.getEdgeSwitchList().add(edgeSwitch);
			this.getNodeList().add(edgeSwitch);
//			System.out.println("edgeswitch_"+x+"_"+y);
			for(int k = 0; k< portNum/2;k++){
				NetworkHost  host = (NetworkHost)CloudSim.getEntity("host_"+3+"_"+(y*(portNum/2)+k));
				DataCenterLink link =new DataCenterLink(
						edgeSwitch.getId(),
						host.getId(),
								0,NetworkConstants.BandWidthEdgeHost);
				this.getLinkList().add(link);
				
				edgeSwitch.hostlist.put(host.getId(), host);
				edgeSwitch.getDownlinks().add(link);
				host.sw = edgeSwitch;
				host.inlink = link;
			}
		}

		x = 1;
		for(int y = 0; y < aggregateSwitchNum; y++){
			AggregateSwitch aggregateSwitch = new AggregateSwitch("aggregateswitch_"+x+"_"+y,
					2,
					datacenter,
					x,y
					);
			this.getAggregateSwitchList().add(aggregateSwitch);
			this.getNodeList().add(aggregateSwitch);
			for(int k = 0; k< portNum/2;k++){
				EdgeSwitch edgeSwitch = (EdgeSwitch)CloudSim.getEntity("edgeswitch_"+2+"_"+((y/(portNum/2))*(portNum/2)+k));
//				System.out.println((y/(portNum/2))*(portNum/2)+"edgeswitch_"+2+"_"+(((y)/(portNum/2))*(portNum/2)+k));
				
				DataCenterLink link = new DataCenterLink(
						aggregateSwitch.getId(),
						edgeSwitch.getId(),
								0,NetworkConstants.BandWidthEdgeAgg);
				this.getLinkList().add(link);
				
				aggregateSwitch.downlinkswitches.add(edgeSwitch);
				aggregateSwitch.getDownlinks().add(link);
				edgeSwitch.uplinkswitches.add(aggregateSwitch);
				edgeSwitch.getUplinks().add(link);
			}
		}
		

		String storageCenterName = "storagecenter_"+-1+"_"+0;
		NetworkStorageHost storageCenter = new NetworkStorageHost(storageCenterName,datacenter,-1,0);
		x = 0;
		for(int y = 0; y < rootSwitchNum; y++){
			RootSwitch rootSwitch = new RootSwitch("rootswitch_"+x+"_"+y,
					2,
					datacenter,
					x,y);
			this.getRootSwitchList().add(rootSwitch);
			this.getNodeList().add(rootSwitch);
			
			DataCenterLink linkToStorageCenter = new DataCenterLink(
					storageCenter.getId(),
					rootSwitch.getId(),
							0,NetworkConstants.BandWidthRootStorageCenter);
			storageCenter.downlinkswitches.add(rootSwitch);
			storageCenter.downlinks.add(linkToStorageCenter);
			rootSwitch.setStorageCenter(storageCenter);
			rootSwitch.getUplinks().add(linkToStorageCenter);
			
			for(int k = 0; k< portNum;k++){
				AggregateSwitch aggregateSwitch = (AggregateSwitch)CloudSim.getEntity("aggregateswitch_"+1+"_"+(k*(portNum/2)+(y+1)%(portNum/2)));
//				System.out.println("aggregateswitch_"+1+"_"+(k*(portNum/2)+(y)%(portNum/2)));
				DataCenterLink link = new DataCenterLink(
						rootSwitch.getId(),
						aggregateSwitch.getId(),
								0,NetworkConstants.BandWidthAggRoot);
				this.getLinkList().add(link);
				
				rootSwitch.downlinkswitches.add(aggregateSwitch);
				rootSwitch.getDownlinks().add(link);
				aggregateSwitch.uplinkswitches.add(rootSwitch);
				aggregateSwitch.getUplinks().add(link);
			}
		}		
		
		this.setStorageCenter(storageCenter);

	}
	
	public List<DataCenterLink> getLinkList() {
		return linkList;
	}

	public void setLinkList(List<DataCenterLink> linkList) {
		this.linkList = linkList;
	}

	public List<DataCenterNode> getNodeList() {
		return nodeList;
	}

	public void setNodeList(List<DataCenterNode> nodeList) {
		this.nodeList = nodeList;
	}

	public List<RootSwitch> getRootSwitchList() {
		return rootSwitchList;
	}

	public void setRootSwitchList(List<RootSwitch> rootSwitchList) {
		this.rootSwitchList = rootSwitchList;
	}

	public List<AggregateSwitch> getAggregateSwitchList() {
		return aggregateSwitchList;
	}

	public void setAggregateSwitchList(List<AggregateSwitch> aggregateSwitchList) {
		this.aggregateSwitchList = aggregateSwitchList;
	}

	public List<EdgeSwitch> getEdgeSwitchList() {
		return edgeSwitchList;
	}

	public void setEdgeSwitchList(List<EdgeSwitch> edgeSwitchList) {
		this.edgeSwitchList = edgeSwitchList;
	}

	public List<? extends Host> getHostList() {
		return hostList;
	}

	public void setHostList(List<? extends Host> hostList) {
		this.hostList = hostList;
	}

	/**
	 * adds an link between two topological nodes
	 * 
	 * @param edge the topological link
	 */
	public void addLink(DataCenterLink edge) {
		linkList.add(edge);
	}

	/**
	 * adds an Topological Node to this graph
	 * 
	 * @param node the topological node to add
	 */
	public void addNode(DataCenterNode node) {
		nodeList.add(node);
	}
	

	/**
	 * returns the number of nodes contained inside the topological-graph
	 * 
	 * @return number of nodes
	 */
	public int getNumberOfNodes() {
		return nodeList.size();
	}

	/**
	 * returns the number of links contained inside the topological-graph
	 * 
	 * @return number of links
	 */
	public int getNumberOfLinks() {
		return linkList.size();
	}

	/**
	 * return an iterator through all network-graph links
	 * 
	 * @return the iterator throug all links
	 */
	public Iterator<DataCenterLink> getLinkIterator() {
		return linkList.iterator();
	}

	/**
	 * returns an iterator through all network-graph nodes
	 * 
	 * @return the iterator through all nodes
	 */
	public Iterator<DataCenterNode> getNodeIterator() {
		return nodeList.iterator();
	}
	

	public NetworkStorageHost getStorageCenter() {
		return storageCenter;
	}

	public void setStorageCenter(NetworkStorageHost storageCenter) {
		this.storageCenter = storageCenter;
	}
	
	public void clearVisited(){
		for(int i = 0; i < nodeList.size(); i++){
			nodeList.get(i).setHasVisited(false);
		}
	}

	/**
	 * prints out all internal node and link information
	 */
	@Override
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("topological-node-information: \n");

		for (DataCenterNode node : nodeList) {
			buffer.append(CloudSim.getEntityId(node.getName()) + " | x is: " + node.getWorldX() + " y is: "
					+ node.getWorldY() + "\n");
		}

		buffer.append("\n\n node-link-information:\n");

		for (DataCenterLink link : linkList) {
			buffer.append("from: " + link.getSrcNodeID() + " to: " + link.getDestNodeID() + " delay: "
					+ link.getLinkDelay() + "\n");
		}
		return buffer.toString();
	}
	
	public void printResult(int size,double totallength,double totaltime,Carrier c,double r){
		double rootCKPPacket = 0, aggCKPPacket = 0, edgeCKPPacket = 0;
		double rootServicePacket = 0, aggServicePacket = 0, edgeServicePacket = 0;
		double appStorageSize = 0, cloudletStorageSize = 0;
		
		for(int i = 0; i < this.rootSwitchList.size(); i++){
			rootCKPPacket = rootCKPPacket + rootSwitchList.get(i).hasReceviedCKPPacketSize;
			rootServicePacket = rootServicePacket + rootSwitchList.get(i).hasReceviedServiceDataPacketSize;
		}
		
		for(int i = 0; i < this.aggregateSwitchList.size(); i++){
			aggCKPPacket = aggCKPPacket + aggregateSwitchList.get(i).hasReceviedCKPPacketSize;
			aggServicePacket = aggServicePacket + aggregateSwitchList.get(i).hasReceviedServiceDataPacketSize;
		}
		
		for(int i = 0; i < this.edgeSwitchList.size(); i++){
			edgeCKPPacket = edgeCKPPacket + edgeSwitchList.get(i).hasReceviedCKPPacketSize;
			edgeServicePacket = edgeServicePacket + edgeSwitchList.get(i).hasReceviedServiceDataPacketSize;
		}
		
		if(storageCenter.dc.getCheckpointimageindex() instanceof CentralCheckpointStorageIndex){
			Map<AppNetCloudlet, AppCheckpoint> appcenter = storageCenter.appCheckpointCenter;
			Map<NetworkResCloudlet, CloudletCheckpoint> cloudletcenter = storageCenter.cloudletCheckpointCenter;
			
			Iterator iter = appcenter.entrySet().iterator();
			while (iter.hasNext()) {
				Map.Entry entry = (Map.Entry) iter.next();
				AppNetCloudlet key = (AppNetCloudlet)entry.getKey();
				AppCheckpoint val = (AppCheckpoint)entry.getValue();
				appStorageSize = appStorageSize + val.getSize();
			}
			
			iter = cloudletcenter.entrySet().iterator();
			while (iter.hasNext()) {
				Map.Entry entry = (Map.Entry) iter.next();
				NetworkResCloudlet key = (NetworkResCloudlet)entry.getKey();
				CloudletCheckpoint val = (CloudletCheckpoint)entry.getValue();
				cloudletStorageSize = cloudletStorageSize + val.getSize();
			}			
		}
		else{
			for(int i = 0; i < hostList.size(); i++){
				Map<AppNetCloudlet, AppCheckpoint> appcenter = ((NetworkHost)hostList.get(i)).appCheckpointCenter;
				Map<NetworkResCloudlet, CloudletCheckpoint> cloudletcenter = ((NetworkHost)hostList.get(i)).cloudletCheckpointCenter;
				
				Iterator iter = appcenter.entrySet().iterator();
				while (iter.hasNext()) {
					Map.Entry entry = (Map.Entry) iter.next();
					AppNetCloudlet key = (AppNetCloudlet)entry.getKey();
					AppCheckpoint val = (AppCheckpoint)entry.getValue();
					appStorageSize = appStorageSize + val.getSize();
				}
				
				iter = cloudletcenter.entrySet().iterator();
				while (iter.hasNext()) {
					Map.Entry entry = (Map.Entry) iter.next();
					NetworkResCloudlet key = (NetworkResCloudlet)entry.getKey();
					CloudletCheckpoint val = (CloudletCheckpoint)entry.getValue();
					cloudletStorageSize = cloudletStorageSize + val.getSize();
				}	
			}
			
		}
		RecordToLogger.logger.info("========== OUTPUT ==========");
		RecordToLogger.logger.info("RootSwitch Checkpoint Packet Processed: " + rootCKPPacket);
		RecordToLogger.logger.info("AggregateSwitch Checkpoint Packet Processed: " + aggCKPPacket);
		RecordToLogger.logger.info("EdgeSwitch Checkpoint Packet Processed: " + edgeCKPPacket);
		RecordToLogger.logger.info("RootSwitch Service Packet Processed: " + rootServicePacket);
		RecordToLogger.logger.info("AggregateSwitch Service Packet Processed: " + aggServicePacket);
		RecordToLogger.logger.info("EdgeSwitch Service Packet Processed: " + edgeServicePacket);
		RecordToLogger.logger.info("RootSwitch Packet Processed: " + (rootCKPPacket+rootServicePacket));
		RecordToLogger.logger.info("AggregateSwitch Packet Processed: " + (aggCKPPacket+aggServicePacket));
		RecordToLogger.logger.info("EdgeSwitch Packet Processed: " + (edgeCKPPacket+edgeServicePacket));
		RecordToLogger.logger.info("APP Checkpoint Storage: " + appStorageSize);
		RecordToLogger.logger.info("Cloudlet Checkpoint Storage: " + cloudletStorageSize);
		RecordToLogger.logger.info("========== ===== ==========");
		
		c.resNrs=rootCKPPacket+rootServicePacket+aggCKPPacket+aggServicePacket+edgeCKPPacket+edgeServicePacket;
		c.resNrs*=r;
		
		Timestamp nowdatatime = new Timestamp(System.currentTimeMillis()); 
		RecordToLogger.logger.info("INSERT INTO log4j(CKProot,CKPaggre,CKPedge,ServiceCKProot,ServiceCKPaggre,ServiceCKPedge,RootSwitch,AgreeSwitch,EdgeSwitch,AppCKPstorage,CloudletCKPstorage,runtime,size,totallength,totalruntime) values("+"'" + rootCKPPacket+"'"+","
		
				+"'" + aggCKPPacket+"'"+","+"'" + edgeCKPPacket+"'"+","+"'" + rootServicePacket+"'"+","+"'" + aggServicePacket+"'"+","+"'" + 
				
				edgeServicePacket+"'"+","+"'" + (rootCKPPacket+rootServicePacket)+"'"+","+"'" + (aggCKPPacket+aggServicePacket)+"'"+","+"'" + 
				
				(edgeCKPPacket+edgeServicePacket)+"'"+","+"'" + appStorageSize+"'"+","+"'" + cloudletStorageSize+"'"+","+"'"+nowdatatime+"'"+","+"'"+size+"'"+","+"'"+totallength+"'"+","+"'"+totaltime+"'"+")");
		

		
	}
	
	

			
	
	public static void main(String[] args) {
		
		
		Timestamp nowdatatime = new Timestamp(System.currentTimeMillis()); 
		 try{
		      Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		      String strurl="jdbc:odbc:driver={Microsoft Access Driver (*.mdb,*.accdb)};DBQ=c:\\db1.mdb";
		      System.out.println("���ӳɹ�!");
		      Connection con=DriverManager.getConnection(strurl) ;
		      System.out.println("���ӳɹ�!");
		      Statement stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
		      
			  String sql="INSERT INTO log4j(runtime)  values("+"'" + nowdatatime+"'"+")";
			  stmt.execute(sql);
			  con.close();
		 
		 
		 
		 }
		
		     catch(Exception e)
		     { System.out.println(e); }

//		RecordToLogger.logger.info("INSERT INTO log4j(RCPP,ACPP,ECPP,RSPP,ASPP,ESPP,RPP,APP,EPP,ACS,CCS,TIME) values("+"'" + rootCKPPacket+"'"+","
//				
//				+"'" + aggCKPPacket+"'"+","+"'" + edgeCKPPacket+"'"+","+"'" + rootServicePacket+"'"+","+"'" + aggServicePacket+"'"+","+"'" + 
//				
//				edgeServicePacket+"'"+","+"'" + (rootCKPPacket+rootServicePacket)+"'"+","+"'" + (aggCKPPacket+aggServicePacket)+"'"+","+"'" + 
//				
//				(edgeCKPPacket+edgeServicePacket)+"'"+","+"'" + appStorageSize+"'"+","+"'" + cloudletStorageSize+"'"+","+"'" + nowdatatime+"'"+")");
	}
}
