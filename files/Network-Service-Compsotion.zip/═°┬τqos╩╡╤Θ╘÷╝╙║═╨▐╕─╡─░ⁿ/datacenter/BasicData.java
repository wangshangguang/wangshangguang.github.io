package org.cloudbus.cloudsim.CKP.datacenter;

public class BasicData extends Data {
	
	private int type;
	
	public BasicData(double size, int type){
		super(size);
		setSize(size);
		this.type = type;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

}
