/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package org.cloudbus.cloudsim.CKP.datacenter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Map.Entry;

import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.checkpoint.DCNetworkVisitor;
import org.cloudbus.cloudsim. core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEvent;
import org.cloudbus.cloudsim.core.predicates.PredicateType;
import org.cloudbus.cloudsim.lists.VmList;


/**
 * This class allows to simulate Edge switch for Datacenter network. It interacts with other
 * switches in order to exchange packets.
 * 
 * Please refer to following publication for more details:
 * 
 * Saurabh Kumar Garg and Rajkumar Buyya, NetworkCloudSim: Modelling Parallel Applications in Cloud
 * Simulations, Proceedings of the 4th IEEE/ACM International Conference on Utility and Cloud
 * Computing (UCC 2011, IEEE CS Press, USA), Melbourne, Australia, December 5-7, 2011.
 * 
 * @author Saurabh Kumar Garg
 * @since CloudSim Toolkit 3.0
 */
public class EdgeSwitch extends Switch {
	public Map<Integer, List<NetworkPacket>> packetTohost;
	
	public Map<Integer, NetworkHost> hostlist;

	/**
	 * Constructor for Edge Switch We have to specify switches that are connected to its downlink
	 * and uplink ports, and corresponding bandwidths. In this switch downlink ports are connected
	 * to hosts not to a switch.
	 * 
	 * @param name Name of the switch
	 * @param level At which level switch is with respect to hosts.
	 * @param dc Pointer to Datacenter
	 */
	public EdgeSwitch(String name, int level, NetworkDatacenter dc, int worldX, int worldY) {
		super(name, level, dc, worldX, worldY);
		hostlist = new HashMap<Integer, NetworkHost>();
		uplinkswitchpktlist = new HashMap<Integer, List<NetworkPacket>>();
		packetTohost = new HashMap<Integer, List<NetworkPacket>>();
		uplinkbandwidth = NetworkConstants.BandWidthEdgeAgg;
		downlinkbandwidth = NetworkConstants.BandWidthEdgeHost;
		latency = NetworkConstants.SwitchingDelayEdge;
		numport = NetworkConstants.EdgeSwitchPort;
		uplinkswitches = new ArrayList<Switch>();
	}
	
	@Override
	public void processEvent(SimEvent ev) {
		// RecordToLogger.logger.info(CloudSim.clock()+"[Broker]: event received:"+ev.getTag());
		switch (ev.getTag()) {
		// Resource characteristics request
			case CloudSimTags.Network_Event_UP:
				// process the packet from down switch or host
				processpacket_up(ev);
				break;
			case CloudSimTags.Network_Event_DOWN:
				// process the packet from uplink
				processpacket_down(ev);
				break;
			case CloudSimTags.Network_Event_send:
				processpacketforward(ev);
				break;

			case CloudSimTags.Network_Event_Host:
				processhostpacket(ev);
				break;
			case CloudSimTags.RESOURCE_Register:
				registerHost(ev);
				break;
			// other unknown tags are processed by this method
			default:
				super.processEvent(ev);
				break;
		}
	}

	/**
	 * Send Packet to switch connected through a uplink port
	 * 
	 * @param ev Event/packet to process
	 */
	@Override
	protected void processpacket_up(SimEvent ev) {
		// packet coming from down level router/host.
		// has to send up
		// check which switch to forward to
		// add packet in the switch list
		//
		// int src=ev.getSource();
		NetworkPacket hspkt = (NetworkPacket) ev.getData();
		int recvVMid = hspkt.pkt.virtualrecvid;
		CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.Network_Event_send));
		schedule(getId(), 0, CloudSimTags.Network_Event_send);

		// packet is recieved from host
		// packet is to be sent to aggregate level or to another host in the same level

//		NetworkDatacenterCharacteristics characteristics = (NetworkDatacenterCharacteristics)dc.getCharacteristics();
//		int hostid = characteristics.VmtoHostlist.get(recvVMid);
//		NetworkHost hs = hostlist.get(hostid);
//		hspkt.recieverhostid = hostid;
		
		int hostid = hspkt.recieverhostid;
		NetworkHost hs = hostlist.get(hostid);
		
		// packet needs to go to a host which is connected directly to switch
		if (hs != null) {
			// packet to be sent to host connected to the switch
			List<NetworkPacket> pktlist = packetTohost.get(hostid);
			if (pktlist == null) {
				pktlist = new ArrayList<NetworkPacket>();
				packetTohost.put(hostid, pktlist);
			}
			pktlist.add(hspkt);
			return;

		}
		// otherwise
		// packet is to be sent to upper switch
		// ASSUMPTION EACH EDGE is Connected to one aggregate level switch
		// if there are more than one Aggregate level switch one need to modify following code
		Random r = new Random(System.currentTimeMillis());
		Switch sw = uplinkswitches.get(r.nextInt(uplinkswitches.size()-1));
		List<NetworkPacket> pktlist = uplinkswitchpktlist.get(sw.getId());
		if (pktlist == null) {
			pktlist = new ArrayList<NetworkPacket>();
			uplinkswitchpktlist.put(sw.getId(), pktlist);
		}
		pktlist.add(hspkt);
		return;

	}
	
	protected void processpacket_down(SimEvent ev) {
		// packet coming from up level router.
		// has to send downward
		// check which switch to forward to
		// add packet in the switch list
		// add packet in the host list
		// int src=ev.getSource();
		NetworkPacket hspkt = (NetworkPacket) ev.getData();
		int recvVMid = hspkt.pkt.virtualrecvid;
		CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.Network_Event_send));
		schedule(getId(), 0, CloudSimTags.Network_Event_send);

		// packet is to be recieved by host
//		NetworkDatacenterCharacteristics characteristics = (NetworkDatacenterCharacteristics)dc.getCharacteristics();
//		int hostid = characteristics.VmtoHostlist.get(recvVMid);
//		hspkt.recieverhostid = hostid;
//		
		int hostid = hspkt.recieverhostid;
		NetworkHost hs = hostlist.get(hostid);
		
		List<NetworkPacket> pktlist = packetTohost.get(hostid);
		if (pktlist == null) {
			pktlist = new ArrayList<NetworkPacket>();
			packetTohost.put(hostid, pktlist);
		}
		pktlist.add(hspkt);
		return;
	}

	/**
	 * Send Packet to hosts connected to the switch
	 * 
	 * @param ev Event/packet to process
	 */
	@Override
	protected void processpacketforward(SimEvent ev) {
		// search for the host and packets..send to them

		if (uplinkswitchpktlist != null) {
			for (Entry<Integer, List<NetworkPacket>> es : uplinkswitchpktlist.entrySet()) {
				int tosend = es.getKey();
				List<NetworkPacket> hspktlist = es.getValue();
				if (!hspktlist.isEmpty()) {
					// sharing bandwidth between packets
					double avband = uplinkbandwidth / hspktlist.size();
					Iterator<NetworkPacket> it = hspktlist.iterator();
					while (it.hasNext()) {
						NetworkPacket hspkt = it.next();
						double delay = hspkt.pkt.data.getSize() / avband + NetworkConstants.SwitchingDelayEdge;
//						System.out.println(delay+"checkpoint"+CloudSim.clock());
						this.send(tosend, delay, CloudSimTags.Network_Event_UP, hspkt);
						
						hasReceviedCKPPacketSize = hasReceviedCKPPacketSize + hspkt.pkt.data.getSize();
						
						if(hspkt.pkt.type == NetworkConstants.RECOVERY_CLOUDLIT)
							hspkt.arriveTime.add(this);
					}
					hspktlist.clear();
				}
			}
		}
		if (packetTohost != null) {
			for (Entry<Integer, List<NetworkPacket>> es : packetTohost.entrySet()) {
				int hostid = es.getKey();
				List<NetworkPacket> hspktlist = es.getValue();				
				if (!hspktlist.isEmpty()) {
					double avband = downlinkbandwidth / hspktlist.size();
					Iterator<NetworkPacket> it = hspktlist.iterator();
					while (it.hasNext()) {
						NetworkPacket hspkt = it.next();
						// hspkt.recieverhostid=tosend;
						// hs.packetrecieved.add(hspkt);
						double delay = hspkt.pkt.data.getSize() / avband + NetworkConstants.SwitchingDelayEdge;
						this.send(getId(), delay, CloudSimTags.Network_Event_Host, hspkt);

						hasReceviedCKPPacketSize = hasReceviedCKPPacketSize + hspkt.pkt.data.getSize();
						
						if(hspkt.pkt.type == NetworkConstants.RECOVERY_CLOUDLIT)
							hspkt.arriveTime.add(this);
					}
					hspktlist.clear();
				}
			}
		}

		// or to switch at next level.
		// clear the list

	}
	
	protected void processhostpacket(SimEvent ev) {
		// Send packet to host
		NetworkPacket hspkt = (NetworkPacket) ev.getData();
		NetworkHost hs = hostlist.get(hspkt.recieverhostid);
		
		if(hs.isFailed())
			return;
		
		hs.packetrecieved.add(hspkt);
		
		CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.Network_Event_UP));
		schedule(hs.getId(), 0, CloudSimTags.Network_Event_DOWN);
	}
	

	private void registerHost(SimEvent ev) {
		NetworkHost hs = (NetworkHost) ev.getData();
		hostlist.put(hs.getId(), (NetworkHost) ev.getData());
	}
	
	protected NetworkHost getHostwithVM(int vmid) {
		for (Entry<Integer, NetworkHost> es : hostlist.entrySet()) {
			Vm vm = VmList.getById(es.getValue().getVmList(), vmid);
			if (vm != null) {
				return es.getValue();
			}
		}
		return null;
	}

	protected List<NetworkVm> getfreeVmlist(int numVMReq) {
		List<NetworkVm> freehostls = new ArrayList<NetworkVm>();
		for (Entry<Integer, NetworkVm> et : Vmlist.entrySet()) {
			if (et.getValue().isFree()) {
				freehostls.add(et.getValue());
			}
			if (freehostls.size() == numVMReq) {
				break;
			}
		}

		return freehostls;
	}

	protected List<NetworkHost> getfreehostlist(int numhost) {
		List<NetworkHost> freehostls = new ArrayList<NetworkHost>();
		for (Entry<Integer, NetworkHost> et : hostlist.entrySet()) {
			if (et.getValue().getNumberOfFreePes() == et.getValue().getNumberOfPes()) {
				freehostls.add(et.getValue());
			}
			if (freehostls.size() == numhost) {
				break;
			}
		}
		return freehostls;
	}
	
	public List<NetworkHost> getHostFromTheSameSubnet(NetworkHost host){
		ArrayList<NetworkHost> hosts = new ArrayList<NetworkHost>();
		for (Entry<Integer, NetworkHost> es : hostlist.entrySet()) {
			if(es.getValue().equals(host))
				continue;
			hosts.add(es.getValue());
		}
		return hosts;
	}
	
	@Override
	public void accept(DCNetworkVisitor visitor, Object data) {
		visitor.visit(this, data);
		
	}

}
