/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package org.cloudbus.cloudsim.CKP.datacenter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Random;

import org.cloudbus.cloudsim.checkpoint.DCNetworkVisitor;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEvent;
import org.cloudbus.cloudsim.core.predicates.PredicateType;

/**
 * This class allows to simulate aggregate switch for Datacenter network. It interacts with other
 * switches in order to exchange packets.
 * 
 * Please refer to following publication for more details:
 * 
 * Saurabh Kumar Garg and Rajkumar Buyya, NetworkCloudSim: Modelling Parallel Applications in Cloud
 * Simulations, Proceedings of the 4th IEEE/ACM International Conference on Utility and Cloud
 * Computing (UCC 2011, IEEE CS Press, USA), Melbourne, Australia, December 5-7, 2011.
 * 
 * @author Saurabh Kumar Garg
 * @since CloudSim Toolkit 1.0
 */
public class AggregateSwitch extends Switch {

	/**
	 * Constructor for Aggregate Switch We have to specify switches that are connected to its
	 * downlink and uplink ports, and corresponding bandwidths
	 * 
	 * @param name Name of the switch
	 * @param level At which level switch is with respect to ,hosts.
	 * @param dc Pointer to Datacenter
	 */
	public AggregateSwitch(String name, int level, NetworkDatacenter dc, int worldX, int worldY) {
		super(name, level, dc, worldX, worldY);
		downlinkswitchpktlist = new HashMap<Integer, List<NetworkPacket>>();
		uplinkswitchpktlist = new HashMap<Integer, List<NetworkPacket>>();
		uplinkbandwidth = NetworkConstants.BandWidthAggRoot;
		downlinkbandwidth = NetworkConstants.BandWidthEdgeAgg;
		latency = NetworkConstants.SwitchingDelayEdge;
		numport = NetworkConstants.AggSwitchPort;
		uplinkswitches = new ArrayList<Switch>();
		downlinkswitches = new ArrayList<Switch>();
	}
	
	@Override
	public void processEvent(SimEvent ev) {
		// RecordToLogger.logger.info(CloudSim.clock()+"[Broker]: event received:"+ev.getTag());
		switch (ev.getTag()) {
		// Resource characteristics request
			case CloudSimTags.Network_Event_UP:
				// process the packet from down switch or host
				processpacket_up(ev);
				break;
			case CloudSimTags.Network_Event_DOWN:
				// process the packet from uplink
				processpacket_down(ev);
				break;
			case CloudSimTags.Network_Event_send:
				processpacketforward(ev);
				break;
			// other unknown tags are processed by this method
			default:
				super.processEvent(ev);
				break;
		}
	}

	/**
	 * Send Packet to switch connected through a downlink port
	 * 
	 * @param ev Event/packet to process
	 */

	@Override
	protected void processpacket_down(SimEvent ev) {
		// packet coming from up level router.
		// has to send downward
		// check which switch to forward to
		// add packet in the switch list
		// add packet in the host list
		NetworkPacket hspkt = (NetworkPacket) ev.getData();
		int recvVMid = hspkt.pkt.virtualrecvid;
		CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.Network_Event_send));
		schedule(getId(), 0, CloudSimTags.Network_Event_send);

		// packet is coming from root so need to be sent to edgelevel swich
		// find the id for edgelevel switch
		NetworkDatacenterCharacteristics characteristics = (NetworkDatacenterCharacteristics)dc.getCharacteristics();
//		int switchid = characteristics.VmToSwitchid.get(recvVMid);
		NetworkHost host = (NetworkHost)CloudSim.getEntity(hspkt.recieverhostid);
		int switchid = host.sw.getId();
		List<NetworkPacket> pktlist = downlinkswitchpktlist.get(switchid);
		if (pktlist == null) {
			pktlist = new ArrayList<NetworkPacket>();
			downlinkswitchpktlist.put(switchid, pktlist);
		}
		pktlist.add(hspkt);
		return;
		
	}

	/**
	 * Send Packet to switch connected through a uplink port
	 * 
	 * @param ev Event/packet to process
	 */
	@Override
	protected void processpacket_up(SimEvent ev) {
		// packet coming from down level router.
		// has to send up
		// check which switch to forward to
		// add packet in the switch list
		//
		// int src=ev.getSource();
		NetworkPacket hspkt = (NetworkPacket) ev.getData();
		int recvVMid = hspkt.pkt.virtualrecvid;
		CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.Network_Event_send));
		schedule(getId(), 0, CloudSimTags.Network_Event_send);
		// packet is coming from edge level router so need to be sent to
		// either root or another edge level swich
		// find the id for edgelevel switch
		boolean flagtoswtich = false;
		int switchid = 0;
//		if(recvVMid >=0){
//			NetworkDatacenterCharacteristics characteristics = (NetworkDatacenterCharacteristics)dc.getCharacteristics();
//			NetworkHost host = (NetworkHost)CloudSim.getEntity(hspkt.recieverhostid);
//			switchid = host.sw.getId();
////			switchid = characteristics.VmToSwitchid.get(recvVMid);
//			for (Switch sw : downlinkswitches) {
//				if (switchid == sw.getId()) {
//					flagtoswtich = true;
//				}
//			}
//		}
		if(CloudSim.getEntity(hspkt.recieverhostid) instanceof NetworkHost){
			NetworkHost host = (NetworkHost)CloudSim.getEntity(hspkt.recieverhostid);
			switchid = host.sw.getId();
			for (Switch sw : downlinkswitches) {
				if (switchid == sw.getId()) {
					flagtoswtich = true;
				}
			}
		}
		if (flagtoswtich) {
			List<NetworkPacket> pktlist = downlinkswitchpktlist.get(switchid);
			if (pktlist == null) {
				pktlist = new ArrayList<NetworkPacket>();
				downlinkswitchpktlist.put(switchid, pktlist);
			}
			pktlist.add(hspkt);
		} else// send to up
		{
			Random r = new Random(System.currentTimeMillis());
			Switch sw = uplinkswitches.get(r.nextInt(uplinkswitches.size()-1));
			List<NetworkPacket> pktlist = uplinkswitchpktlist.get(sw.getId());
			if (pktlist == null) {
				pktlist = new ArrayList<NetworkPacket>();
				uplinkswitchpktlist.put(sw.getId(), pktlist);
			}
				pktlist.add(hspkt);
		}
	}
	
	protected void processpacketforward(SimEvent ev) {
		// search for the host and packets..send to them

		if (downlinkswitchpktlist != null) {
			for (Entry<Integer, List<NetworkPacket>> es : downlinkswitchpktlist.entrySet()) {
				int tosend = es.getKey();
				List<NetworkPacket> hspktlist = es.getValue();
				if (!hspktlist.isEmpty()) {
					double avband = downlinkbandwidth / hspktlist.size();
					Iterator<NetworkPacket> it = hspktlist.iterator();
					while (it.hasNext()) {
						NetworkPacket hspkt = it.next();
						double delay = hspkt.pkt.data.getSize() / avband + NetworkConstants.SwitchingDelayAgg;

						this.send(tosend, delay, CloudSimTags.Network_Event_DOWN, hspkt);
//						System.out.println(this.getName()+"send packet"+CloudSim.clock());
						
						hasReceviedCKPPacketSize = hasReceviedCKPPacketSize + hspkt.pkt.data.getSize();
						
						if(hspkt.pkt.type == NetworkConstants.RECOVERY_CLOUDLIT)
							hspkt.arriveTime.add(this);
					}
					hspktlist.clear();
				}
			}
		}
		if (uplinkswitchpktlist != null) {
			for (Entry<Integer, List<NetworkPacket>> es : uplinkswitchpktlist.entrySet()) {
				int tosend = es.getKey();
				List<NetworkPacket> hspktlist = es.getValue();
				if (!hspktlist.isEmpty()) {
					double avband = uplinkbandwidth / hspktlist.size();
					Iterator<NetworkPacket> it = hspktlist.iterator();
					while (it.hasNext()) {
						NetworkPacket hspkt = it.next();
						double delay = hspkt.pkt.data.getSize() / avband + NetworkConstants.SwitchingDelayAgg;
//						System.out.println(delay+"checkpoint"+CloudSim.clock());
						this.send(tosend, delay, CloudSimTags.Network_Event_UP, hspkt);
						
						hasReceviedCKPPacketSize = hasReceviedCKPPacketSize + hspkt.pkt.data.getSize();
						
						if(hspkt.pkt.type == NetworkConstants.RECOVERY_CLOUDLIT)
							hspkt.arriveTime.add(this);
					}
					hspktlist.clear();
				}
			}
		}
	}
	
	public List<NetworkHost> getHostFromOtherSubnet(NetworkHost host){
		ArrayList<NetworkHost> hosts = new ArrayList<NetworkHost>();
		for(int i = 0; i < downlinkswitches.size(); i++){
			EdgeSwitch es = (EdgeSwitch)downlinkswitches.get(i);
			if(es.equals(host.sw))
				continue;
			hosts.addAll(es.hostlist.values());
		}
		return hosts;
	}
	
	public List<NetworkHost> getAllHostBelow(){
		ArrayList<NetworkHost> hosts = new ArrayList<NetworkHost>();
		for(int i = 0; i < downlinkswitches.size(); i++){
			EdgeSwitch es = (EdgeSwitch)downlinkswitches.get(i);
			hosts.addAll(es.hostlist.values());
		}
		return hosts;
	}
	
	@Override
	public void accept(DCNetworkVisitor visitor, Object data) {
		visitor.visit(this, data);
		
	}

}
