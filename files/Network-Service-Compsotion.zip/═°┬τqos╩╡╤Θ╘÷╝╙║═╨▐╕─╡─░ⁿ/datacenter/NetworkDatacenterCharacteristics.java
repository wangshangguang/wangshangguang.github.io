package org.cloudbus.cloudsim.CKP.datacenter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.checkpoint.CheckpointStorageIndex;
import org.cloudbus.cloudsim.checkpoint.CheckpointMakingScheduler;

public class NetworkDatacenterCharacteristics extends DatacenterCharacteristics {
	private DCNetwork datacenternetwork;

	public Map<Integer, Integer> VmToSwitchid;

//	public Map<Integer, Integer> HostToSwitchid;

//	public Map<Integer, Switch> Switchlist;

	public Map<Integer, Integer> VmtoHostlist;

	public NetworkDatacenterCharacteristics(String architecture, String os,
			String vmm, List<? extends Host> hostList, double timeZone,
			double costPerSec, double costPerMem, double costPerStorage,
			double costPerBw) {
		super(architecture, os, vmm, hostList, timeZone, costPerSec, costPerMem,
				costPerStorage, costPerBw);
		VmToSwitchid = new HashMap<Integer, Integer>();
//		HostToSwitchid = new HashMap<Integer, Integer>();
		VmtoHostlist = new HashMap<Integer, Integer>();
//		Switchlist = new HashMap<Integer, Switch>();
		
	}


	public DCNetwork getDatacenternetwork() {
		return datacenternetwork;
	}


	public void setDatacenternetwork(DCNetwork datacenternetwork) {
		this.datacenternetwork = datacenternetwork;
	}



}
