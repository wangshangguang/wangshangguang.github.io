%Here, y_j1 is a cell parameter, is decided by the number of its s_j1;
%l_remain is RXn_j1 matrix;
function [y_temp,x_temp]=ILPend(j,y_j1,e_j1j,n_j1,R,M,s,f,p,S_remain,F_remain,l_remain,R_c,dcm,alpha,lambda,H,einout)

  cvx_begin
  cvx_solver mosek
        variable y_temp(R,M) binary
        variable x_temp(1,M) integer
        minimize sum(x_temp.*alpha(j)+max(x_temp-H(j),0).*lambda(j))
        subject to
        x_temp>=sum(y_temp,1)/p(j); % the number of requests allocated to c_k
        s(j)*x_temp<=S_remain; %1xM
        f(j)*x_temp<=F_remain;
        for i=1:n_j1     %the number of its s_j1
            diag(y_j1{i}*dcm*y_temp'*e_j1j(i)+y_temp*dcm*R_c'*einout(2))<=l_remain(:,i); 
        end
        sum(y_temp,2)==1; %each user only select one server
   cvx_end
end