%abstract: for each task r_ij,recover y according to z, then comput x
%���������ѡ��

function [x_rand,y_rand,c_rand,c_rand_1,c_rand_2,l_rand]=Random_recover(R,N,M,I,pro,s,f,p,e,dcm,S,F,alpha,H,lambda,einout,R_c)
x_rand=zeros(N,M);
y_rand=zeros(R,N,M);
Ir=I;
pror=pro;
for j=1:N
    for i=1:R
        temp=pro{i,j};
        temp(1)=1-sum(temp)+temp(1);
        pror{i,j}=temp;
        while 1
            temp1= randsrc(1,1,[Ir{i,j,1};pror{i,j}]); %Sum of pro must equal one.
            y_rand(i,j,temp1)=1;  
            r_num=squeeze(y_rand(:,j,:));
            x_rand(j,:)=ceil(sum(r_num)/p(j));           
           if s*x_rand<S & f*x_rand<F  %|�Ƚϵ�����Ϊ����������||����
               break
           else
               y_rand(i,j,temp1)=0;
           end   
        end
    end        
end
 
%Calculate time and cost according to x&y
c_rand_1=sum(sum(alpha.*x_rand));
c_rand_2=sum(sum(max((x_rand-H),0).*lambda));
c_rand=c_rand_1+c_rand_2; 
l_rand=zeros(R,N+1); 
for i=1:R
    l_rand(i,1)=0+R_c(i,:)*dcm*squeeze(y_rand(i,1,:))*einout(1);%computation delay=0
    l_rand(i,3)=0+R_c(i,:)*dcm*squeeze(y_rand(i,3,:))*einout(1);
    for j1=1:N-1
            for j=2:N
                if e(j1,j)>0 
                    l_rand(i,j)=max(l_rand(i,j1)+e(j1,j)*squeeze(y_rand(i,j1,:))'*dcm*squeeze(y_rand(i,j,:)),l_rand(i,j));
                end
            end
    end
    l_rand(i,N+1)=l_rand(i,N)+squeeze(y_rand(i,N,:))'*dcm*R_c(i,:)'*einout(2);
end
 
end
