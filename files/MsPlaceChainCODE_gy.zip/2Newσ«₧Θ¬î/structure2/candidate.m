% compute the candidate set I
function [I,pro]=candidate(zout,R,N,M,e)
I=cell(R,N);  %r_ij的候选
pro=cell(R,N); %概率
% zj=squeeze(sum(sum(z,2),3)); %z_ijk  c_k上的s_j收到的来自r_ij的
% zz=zeros(R,N,M); %probility 
% for i=1:R
%       for j=[2,3,4,5,7,8]
%            for k=1:M
%                  if zj(i,j,k)>0.0001
%                      zz(i,j,k)=zj(i,j,k)/sum(e(:,j) ,1); 
%                  end
%             end
%       end
% end
% zj1=squeeze(sum(sum(z,4),5)); %z_ij'k' c_k'上的s_j'发出的 r_ij的数据量
% temp=find(zj1<0.001);
% zj1(temp)=0;
% zz(:,1,:)=zj1(:,1,:)./e(1,2); 
% zz(:,6,:)=zj1(:,6,:)./e(6,7);

for i=1:R
    for j=1:N
        for k=1:M
            if zout(i,j,k)>0.0001
                I{i,j}=[I{i,j},k];
                pro{i,j}=[pro{i,j},round(zout(i,j,k),3)];
            end
        end
    end
end
end