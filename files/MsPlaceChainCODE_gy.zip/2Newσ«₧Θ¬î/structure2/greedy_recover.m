function [x_gre,y_gre,c_gre,c_gre_1,c_gre_2,l_gre]=greedy_recover(R,N,M,I,pro,s,f,p,e,dcm,S,F,alpha,H,lambda,einout,R_c)
% select edge server with the highest probility
x_gre=zeros(N,M);
y_gre=zeros(R,N,M);
for i=1:R
    for j=1:N
        hp=1; % the highest pro
        temp=I{i,j};
        [~,temp1]=sort(pro{i,j},'descend');%select one with the highest pro
        while 1       
            temp2=temp1(hp);
            y_gre(i,j,temp(temp2))=1;
            r_num=squeeze(sum(y_gre,1));   % the number of rquests recieved by s_j in c_k
            x_gre(j,:)=ceil( r_num(j,:)/p(j));
            if s*x_gre<=S & f*x_gre<=F  %|�Ƚϵ�����Ϊ����������||����
               break
            else
              y_gre(i,j,temp(temp2))=0;  
              hp=hp+1;  % the second/... highest pro
            end
        end
    end   
end
 
%Calculate time and cost according to x&y
c_gre_1=sum(sum(alpha.*x_gre));
c_gre_2=sum(sum(max((x_gre-H),0).*lambda));
c_gre=c_gre_1 +c_gre_2;

l_gre=zeros(R,N+1); 
for i=1:R
    l_gre(i,1)=R_c(i,:)*dcm*squeeze(y_gre(i,1,:))*einout(1);
    l_gre(i,3)=R_c(i,:)*dcm*squeeze(y_gre(i,3,:))*einout(1);
    for j1=1:N-1
            for j=2:N
                if e(j1,j)>0 
                    l_gre(i,j)=max(l_gre(i,j1)+e(j1,j)*squeeze(y_gre(i,j1,:))'*dcm*squeeze(y_gre(i,j,:)),l_gre(i,j));
                end
            end
    end
    l_gre(i,N+1)=l_gre(i,N)+squeeze(y_gre(i,j,:))'*dcm*R_c(i,:)'*einout(2);
end
% the constraint of storege and CPU

end