function [x_l,y_l,c_l,c_l_1,c_l_2,l_l]=l_recover(R,N,M,s,f,p,e,dcm,S,F,alpha,H,lambda,einout,R_c,l_r,L)
%select edge server from the candidate set I
x_l=zeros(N,M);
y_l=zeros(R,N,M);
l_l=zeros(R,N+1);
S_remain=S;
F_remain=F;
for j=1:N % place s_j one by one  % divided into 3 situations
    fprintf("place s_%d\n",j);
    if j==1||j==3
        l_remain=l_r(:,j);
        [y_temp,x_temp]=ILPstart(j,R,M,s,f,p,S_remain,F_remain,l_remain,R_c,dcm,alpha,lambda,H,einout);
        l_l(:,j)=diag(R_c*dcm*y_temp')*einout(1);
    else
        if j==N  %j=5
           y_j1=cell(1);
           e_j1j=[];
           n_j1=0;
           l_remain=[];
           for j1=1:N-1
               if e(j1,j)>0 %2-5 4-5
                    n_j1=n_j1+1;
                    y_j1{n_j1}=squeeze(y_l(:,j1,:));
                    e_j1j=[e_j1j,e(j1,j)];
                    l_remain=[l_remain,L'-l_l(:,j1)]; % RXn_j1 matrix
               end
           end
            [y_temp,x_temp]=ILPend(j,y_j1,e_j1j,n_j1,R,M,s,f,p,S_remain,F_remain,l_remain,R_c,dcm,alpha,lambda,H,einout);
            l_real=[]; 
            for j1=1:N-1
                if e(j1,j)>0
                    l_real=[l_real,l_l(:,j1)+diag(squeeze(y_l(:,j1,:))*dcm*y_temp')*e(j1,j)];
                end
            end
            l_l(:,N)=max(l_real,[],2);
            l_l(:,N+1)=l_l(:,N)+diag(y_temp*dcm*R_c'*einout(2));
        else 
            %j=2 4
            j1=j-1; 
            y_j1=squeeze(y_l(:,j1,:));
            e_j1j=e(j1,j);
            l_remain=l_r(:,j)-l_l(:,j1); % RX1 matrix
            [y_temp,x_temp]=ILPnormal(j,y_j1,e_j1j,R,M,s,f,p,S_remain,F_remain,l_remain,dcm,alpha,lambda,H);
            l_l(:,j)=l_l(:,j1)+diag(y_j1*dcm*y_temp')*e(j1,j);
        end
    end            
    y_l(:,j,:)=y_temp;
    x_l(j,:)=x_temp;
    S_remain=S_remain-s(j)*x_temp;
    F_remain=F_remain-f(j)*x_l(j,:);
    fprintf("%d ",S_remain,s(j)*x_temp);
end   
    
    c_l_1=sum(sum(alpha.*x_l));
    c_l_2=sum(sum(max((x_l-H),0).*lambda));
    c_l=c_l_1+c_l_2;
end



% 2 4


