function [x_ca_lya,y_ca_lya,c_ca_lya,c_ca_lya_1,c_ca_lya_2,l_ca_lya]=ca_lya_recover(R,N,M,I,s,f,p,e,dcm,S,F,alpha,H,lambda,einout,R_c,l_r,L,V)
%Lyapunov   % I candidate set
D1=cell(1,N+1); % predicted delay
D=cell(1,N+1); % real delay
D1{1}=l_r(:,1);
D1{3}=l_r(:,3);
for j=2:N
    for j1=1:N-1
        if e(j1,j)>0
            D1{j}=[D1{j},l_r(:,j)-l_r(:,j1)]; %the delay of e(j1,j) 
        end
    end
end
D1{N+1}=L'-l_r(:,N);  

% constract virtual queue
x_ca_lya=zeros(N,M);
y_ca_lya=zeros(R,N,M);
l_ca_lya=zeros(R,N+1);
S_remain=S;
F_remain=F;
q=cell(1,N); %virtual queue

for j=1:N
    fprintf("place s_%d\n",j);
    if j==1||j==3
        [y_temp,x_temp]=ca_lya_ILPstart(j,R,M,s,f,p,S_remain,F_remain,R_c,dcm,alpha,lambda,H,einout,D1,V,I);
        D{j}=diag(R_c*dcm*y_temp')*einout(1); 
        l_ca_lya(:,j)=D{j}; 
        for j1=2:N 
               if e(j,j1)>0  %q2,q4
                q{j1}=[q{j1},D{j}-D1{j}];
               end
        end
    else
          if  j==2||j==4   
            j1=j-1;  
            y_j1=squeeze(y_ca_lya(:,j1,:));
            e_j1j=e(j1,j);
            [y_temp,x_temp]=ca_lya_ILPnormal(j,y_j1,e_j1j,R,M,s,f,p,S_remain,F_remain,dcm,alpha,lambda,H,D1{j},q{j},V,I);
            D{j}=diag(y_j1*dcm*y_temp')*e(j1,j);
            l_ca_lya(:,j)=l_ca_lya(:,j1)+D{j};
            for j1=3:N
                if e(j,j1)>0   % j=2,q5;j=4,q5; 
                q{j1}=[q{j1},max(q{j}+D{j}-D1{j},[],2)]; 
                end
            end
        else 
            %j==N   %j=5
           y_j1=cell(1);
           e_j1j=[];
           n_j1=0;
           l_remain=[];
           for j1=1:N-1
               if e(j1,j)>0 %2-5 4-5
                    n_j1=n_j1+1;
                    y_j1{n_j1}=squeeze(y_ca_lya(:,j1,:));
                    e_j1j=[e_j1j,e(j1,j)];
                    l_remain=[l_remain,L'-l_ca_lya(:,j1)];
               end
           end
            [y_temp,x_temp]=ILPend(j,n_j1,y_j1,e_j1j,R,M,s,f,p,S_remain,F_remain,l_remain,R_c,dcm,alpha,lambda,H,einout);
            l_real=[]; 
            for j1=1:N-1
                if e(j1,j)>0
                    l_real=[l_real,l_ca_lya(:,j1)+diag(squeeze(y_ca_lya(:,j1,:))*dcm*y_temp')*e(j1,j)];
                end
            end
            l_ca_lya(:,j)=max(l_real,[],2);
            l_ca_lya(:,N+1)=l_ca_lya(:,N)+diag(y_temp*dcm*R_c'*einout(2));
           
         end
    end
    y_ca_lya(:,j,:)=y_temp;
    x_ca_lya(j,:)=x_temp;
    S_remain=S_remain-s(j)*x_ca_lya(j,:);
    F_remain=F_remain-f(j)*x_ca_lya(j,:);
      %Rx1  
end
    c_ca_lya_1=sum(sum(alpha.*x_ca_lya));
    c_ca_lya_2=sum(sum(max((x_ca_lya-H),0).*lambda));
    c_ca_lya=c_ca_lya_1+c_ca_lya_2;
end


function [y_temp,x_temp]=ca_lya_ILPstart(j,R,M,s,f,p,S_remain,F_remain,R_c,dcm,alpha,lambda,H,einout,D1,V,I) 
  I_j=unique([I{:,j}]); %candidate edge servers of s_j
  m=length(I_j); %the number of candidate edge servers
  
  cvx_begin
    cvx_solver mosek
        variable y_tempI(R,m) binary
        variable x_tempI(1,m) integer
        c_func=sum(x_tempI.*alpha(j,I_j)+max(x_tempI-H(j,I_j),0).*lambda(j,I_j));
        d=diag(R_c*dcm(:,I_j)*y_tempI')*einout(1)-D1{j};
        func=V*c_func+sum(pos(d));
        minimize(func)
        subject to
        x_tempI>=sum(y_tempI,1)/p(j); % the number of requests allocated to c_k
        s(j)*x_tempI<=S_remain(I_j); %1xm
        f(j)*x_tempI<=F_remain(I_j);   
        sum(y_tempI,2)==1; %each user only select one server
   cvx_end
   
   %transformation y_tempI to y_temp; x_tempI to x_temp
       y_temp=zeros(R,M);
       x_temp=zeros(1,M);
        for j=1:m
            x_temp(I_j(j))=x_tempI(j);
            for  i=1:R
              y_temp(i,I_j(j))=y_tempI(i,j); 
            end
        end
   
end
   
function [y_temp,x_temp]=ca_lya_ILPnormal(j,y_j1,e_j1j,R,M,s,f,p,S_remain,F_remain,dcm,alpha,lambda,H,D1_j,q_j,V,I) 
I_j=unique([I{:,j}]); %candidate edge servers of s_j
I_j=unique([I_j,find(sum(y_j1))]);% add the edge server where s_j1 are placed
m=length(I_j); %the number of candidate edge servers

   cvx_begin
   cvx_solver mosek
        variable y_tempI(R,m) binary
        variable x_tempI(1,m) integer
        c_func=sum(x_tempI.*alpha(j,I_j)+max(x_tempI-H(j,I_j),0).*lambda(j,I_j));
        d=q_j+diag(y_j1*dcm(:,I_j)*y_tempI')*e_j1j-D1_j;
        func=V*c_func+sum(pos(d));
        minimize(func)
        subject to
        x_tempI>=sum(y_tempI,1)/p(j); % the number of requests allocated to c_k
        s(j)*x_tempI<=S_remain(I_j);
        f(j)*x_tempI<=F_remain(I_j);
        sum(y_tempI,2)==1; %each user only select one server
 cvx_end   
       y_temp=zeros(R,M);
       x_temp=zeros(1,M);
        for j=1:m
            x_temp(I_j(j))=x_tempI(j);
            for  i=1:R
              y_temp(i,I_j(j))=y_tempI(i,j); 
            end
        end
end

 
function [y_temp,x_temp]=ILPend(j,n_j1,y_j1,e_j1j,R,M,s,f,p,S_remain,F_remain,l_remain,R_c,dcm,alpha,lambda,H,einout)
  cvx_begin
  cvx_solver mosek
        variable y_temp(R,M) binary
        variable x_temp(1,M) integer
        minimize sum(x_temp.*alpha(j)+max(x_temp-H(j),0).*lambda(j))
        subject to
        x_temp>=sum(y_temp,1)/p(j); % the number of requests allocated to c_k
        s(j)*x_temp<=S_remain; %1xM
        f(j)*x_temp<=F_remain;  
        for i=1:n_j1
            diag(y_j1{i}*dcm*y_temp'*e_j1j(i)+y_temp*dcm*R_c'*einout(2))<=l_remain(:,i); 
        end
        sum(y_temp,2)==1; %each user only select one server
   cvx_end
end