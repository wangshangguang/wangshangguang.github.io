function [x_ca,y_ca,c_ca,c_ca_1,c_ca_2,l_ca]=ca_l_recover(R,N,M,I,s,f,p,e,dcm,S,F,alpha,H,lambda,einout,R_c,l,L)
%select edge server from the candidate set I
x_ca=zeros(N,M);
y_ca=zeros(R,N,M);
l_ca=zeros(R,N+1);
S_remain=S;
F_remain=F;
for j=1:N % place s_j one by one  % divided into 3 situations
    fprintf("place s_%d\n",j);
    if j==1||j==3
        l_remain=l(:,j);
        [y_temp,x_temp]=ca_ILPstart(j,R,M,s,f,p,S_remain,F_remain,l_remain,R_c,dcm,alpha,lambda,H,einout,I);
        if isnan(x_temp)
            [y_temp,x_temp]=ILPstart(j,R,M,s,f,p,S_remain,F_remain,l_remain,R_c,dcm,alpha,lambda,H,einout);
        end
        l_ca(:,j)=diag(R_c*dcm*y_temp')*einout(1);
    else
        if j==N  %j=5
           y_j1=cell(1);
           e_j1j=[];
           n_j1=0;
           l_remain=[];
           for j1=1:N-1
               if e(j1,j)>0 %2-5 4-5
                    n_j1=n_j1+1;
                    y_j1{n_j1}=squeeze(y_ca(:,j1,:));
                    e_j1j=[e_j1j,e(j1,j)];
                    l_remain=[l_remain,L'-l_ca(:,j1)]; % RXn_j1 matrix
               end
           end
            [y_temp,x_temp]=ILPend(j,y_j1,e_j1j,n_j1,R,M,s,f,p,S_remain,F_remain,l_remain,R_c,dcm,alpha,lambda,H,einout);
            l_real=[]; 
            for j1=1:N-1
                if e(j1,j)>0
                    l_real=[l_real,l_ca(:,j1)+diag(squeeze(y_ca(:,j1,:))*dcm*y_temp')*e(j1,j)];
                end
            end
            l_ca(:,N)=max(l_real,[],2);
            l_ca(:,N+1)=l_ca(:,N)+diag(y_temp*dcm*R_c'*einout(2));
        else 
            %j=2 4
            j1=j-1; 
            y_j1=squeeze(y_ca(:,j1,:));
            e_j1j=e(j1,j);
            l_remain=l(:,j)-l_ca(:,j1); % RX1 matrix
            [y_temp,x_temp]=ca_ILPnormal(j,y_j1,e_j1j,R,M,s,f,p,S_remain,F_remain,l_remain,dcm,alpha,lambda,H,I);
            if  any(isnan(x_temp)) %����һ��NaN
                fprintf("place s_%d again\n",j);
                [y_temp,x_temp]=ILPnormal(j,y_j1,e_j1j,R,M,s,f,p,S_remain,F_remain,l_remain,dcm,alpha,lambda,H);
            end
            l_ca(:,j)=l_ca(:,j1)+diag(y_j1*dcm*y_temp')*e(j1,j);
        end
    end            
    y_ca(:,j,:)=y_temp;
    x_ca(j,:)=x_temp;
    S_remain=S_remain-s(j)*x_temp;
    F_remain=F_remain-f(j)*x_ca(j,:);
end     
    c_ca_1=sum(sum(alpha.*x_ca));
    c_ca_2=sum(sum(max((x_ca-H),0).*lambda));
    c_ca=c_ca_1+c_ca_2;
end

%recover x,y(i,1)/y(i,3) according to l(i,1)/l(i,3)
function [y_temp,x_temp]=ca_ILPstart(j,R,M,s,f,p,S_remain,F_remain,l_remain,R_c,dcm,alpha,lambda,H,einout,I)
  I_j=unique([I{:,j}]); %candidate edge servers of s_j
  m=length(I_j); %the number of candidate edge servers
  cvx_begin
  cvx_solver mosek
        variable y_temp_I(R,m) binary
        variable x_temp(1,M) integer
        minimize sum(x_temp.*alpha(j)+max(x_temp-H(j),0).*lambda(j))
        subject to
        expression y_temp(R,M)  %transformation
        for i=1:R
            for j=1:M
                y_temp(i,j)=0;
            end
            for j=1:m 
              y_temp(i,I_j(j))=y_temp_I(i,j);
            end
        end
        
        x_temp>=sum(y_temp,1)/p(j); % the number of requests allocated to c_k
        s(j)*x_temp<=S_remain; %1xM
        f(j)*x_temp<=F_remain;   
        diag(R_c*dcm*y_temp')*einout(1)<=l_remain;   %Rx1
        sum(y_temp,2)==1; %each user only select one server
   cvx_end
end

% 2 4
function [y_temp,x_temp]=ca_ILPnormal(j,y_j1,e_j1j,R,M,s,f,p,S_remain,F_remain,l_remain,dcm,alpha,lambda,H,I)

I_j=unique([I{:,j}]); %candidate edge servers of s_j
I_j=unique([I_j,find(sum(y_j1))]); % add the edge server where s_j1 are placed
m=length(I_j); %the number of candidate edge servers 
cvx_begin
cvx_solver mosek
        variable y_temp_I(R,m) binary
        variable x_temp_I(1,m) integer
        minimize sum(x_temp_I.*alpha(j,I_j)+max(x_temp_I-H(j,I_j),0).*lambda(j,I_j)) 
        subject to  
        x_temp_I>=sum(y_temp_I,1)/p(j); % the number of requests allocated to c_k
        s(j)*x_temp_I<=S_remain(I_j);
        f(j)*x_temp_I<=F_remain(I_j);  
        diag(y_j1*dcm(:,I_j)*y_temp_I')*e_j1j<=l_remain;
        sum(y_temp_I,2)==1; %each user only select one server
 cvx_end
 
 %transformation y_temp_I to y_temp; x_temp_I to x_temp
       y_temp=zeros(R,M);
       x_temp=zeros(1,M);
        for j=1:m
            x_temp(I_j(j))=x_temp_I(j);
            for  i=1:R
              y_temp(i,I_j(j))=y_temp_I(i,j); 
            end
        end
end
