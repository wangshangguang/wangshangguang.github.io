function [e,einout,s,f,a,p,P]=inputN(N) %微服务相关参数
Er=rand(1,4)*4.5+0.5; %6条边传输的数据量
e1=[1,2,Er(1); %输入
   3,4,Er(2);
   2,5,Er(3);
   4,5,Er(4)]; %输出 %(N-1)xN 
e2=spconvert(e1);  %sparse matrix
e=full(e2); %边传输的数据量矩阵 (N-1)xN 
einout=rand(1,2)*4.5+0.5; %e(0,1)=e(0,5) e(6,7)
s=rand(1,N)*30+20; %the allocated resource for each instance
f=rand(1,N)*4+1; 
p=randi([5,10],1,N);
a=rand(1,N)*2+1; %the computation demand of each task
%%格式转化
P=diag(p);
end







