%input parameter
N=5; %the number of microservices 5
[e,einout,s,f,a,p,P]=inputN(N); %΢������ز���
R=20; % the number of requests
[r_c,L,E]=inputR(R,N,e);

M=21;  % the number of edge servers and 1��Internet cloud 
[S,F,dcm,H,alpha,lambda]=inputM(M,N,s,f);
% %��ʽת��
R_c=zeros(R,M);
ind=sub2ind(size(R_c),[1:R],r_c);
R_c(ind)=1;

 
% % solve P2
[x,z,zout,l,c]=cvx_relaxed(R,N,M,S,F,s,f,a,P,alpha,lambda,H,E,e,einout,R_c,dcm,L);%z ������
x(find(x<0.001))=0;
c_1=sum(sum(alpha.*x));
c_2=sum(sum(max((x-H),0).*lambda));
x_r=ceil(x);  %recover x directly
c_r=sum(sum(alpha.*x_r +max((x_r-H),0).*lambda)); %the placement cost
c_r_1=sum(sum(alpha.*x_r));
c_r_2=sum(sum(max((x_r-H),0).*lambda));
[I,pro]=candidate(zout,R,N,M,e);

 %Recover
 %random recover; greedy recover;ILP recover;lya recover
 [x_rand,y_rand,c_rand,c_rand_1,c_rand_2,l_rand]=Random_recover(R,N,M,I,pro,s,f,p,e,dcm,S,F,alpha,H,lambda,einout,R_c);
 [x_gre,y_gre,c_gre,c_gre_1,c_gre_2,l_gre]=greedy_recover(R,N,M,I,pro,s,f,p,e,dcm,S,F,alpha,H,lambda,einout,R_c);
  [x_ca,y_ca,c_ca,c_ca_1,c_ca_2,l_ca]=ca_l_recover(R,N,M,I,s,f,p,e,dcm,S,F,alpha,H,lambda,einout,R_c,l,L); %the input of l_r is l
  V=1; 
 [x_ca_lya,y_ca_lya,c_ca_lya,c_ca_lya_1,c_ca_lya_2,l_ca_lya]=ca_lya_recover(R,N,M,I,s,f,p,e,dcm,S,F,alpha,H,lambda,einout,R_c,l,L,V);

 

