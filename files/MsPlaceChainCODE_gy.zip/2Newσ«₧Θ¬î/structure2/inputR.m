
function [r_c,L,E]=inputR(R,N,e)
r_c=randi([1,5],1,R); % the edge server which recieves request r_i
L=randi([40,50],1,R); %deadline
%%格式转化   
E=zeros(R,N-1,N);
for i=1:R
    E(i,:,:)=e;
end
end