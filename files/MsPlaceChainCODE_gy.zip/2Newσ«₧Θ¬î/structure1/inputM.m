function [S,F,dcm,H,alpha,lambda]=inputM(M,N,s,f)
S=randi([150,300],1,M); 
S(M)=10000; 
F=randi([10,25],1,M);
F(M)=100;
dcm=d(M);
% %the microservice placement at t-1
cvx_begin
    variable h(N,M) 
    s*h<=S;         %satisfy the constraints
    f*h<=F;
    h>=0;
    h(:,M)>=ones(N,1);
 cvx_end
H=fix(h); %取整
alpha=randi([3,10],N,M); 
lambda=randi([10,15],N,M);
 

end

function rdcm=d(M)
dcm1=zeros(M);
dcm=zeros(M);
r=rand(10)>0.5;
r1=tril(r,-1)+triu(r',0);

r=rand(5)>0.5;
r2=tril(r,-1)+triu(r',0);

r=rand(3)>0.5;
r3=tril(r,-1)+triu(r',0);

dcm1(1:10,1:10)=r1;
dcm1(11:15,11:15)=r2;
dcm1(16:18,16:18)=r3;
dcm1(19,20)=1;
dcm1(20,19)=1;

for i=1:M
   dcm1(i,i)=0;
end

for i=1:M
    for j=1:M
        if dcm1(i,j)==1
            dcm(i,j)=rand(1)*2;
        end
    end
end

dcm(3,11)=rand(1)*3;
dcm(5,12)=rand(1)*3;
dcm(7,13)=rand(1)*3;
dcm([11,12,13],[3,5,7])=dcm([3,5,7],[11,12,13]);
dcm(12,17)=rand(1)+2;
dcm(17,20)=rand(1)*3+1;
dcm(20,21)=rand(1)*8+2;
dcm([17,20,21],[12,17,20])=dcm([12,17,20],[17,20,21]);

[i,j,v]=find(tril(dcm,-1)); %下三角矩阵
b=sparse(i,j,v,M,M);
rdcm=graphallshortestpath(b);
end