% %input parameter
 N=6; %the number of microservices 5
[e,einout,s,f,a,p,P]=inputN(N); %΢������ز���
 M=21;  % the number of edge servers and 1��Internet cloud 
[S,F,dcm,H,alpha,lambda]=inputM(M,N,s,f);
R=10; % the number of requests
[r_c,L,E]=inputR(R,N,e);
% %��ʽת��
R_c=zeros(R,M);
ind=sub2ind(size(R_c),[1:R],r_c);
R_c(ind)=1;

% % solve P2
[x,z,zout,l,c]=cvx_relaxed(R,N,M,S,F,s,f,a,P,alpha,lambda,H,E,e,einout,R_c,dcm,L);%z ������
x(find(x<0.001))=0;
c_1=sum(sum(alpha.*x));
c_2=sum(sum(max((x-H),0).*lambda));
x_r=ceil(x);  %recover x directly
c_r_1=sum(sum(alpha.*x_r));
c_r_2=sum(sum(max((x_r-H),0).*lambda));
c_r=c_r_1+c_r_2; %the placement cost
[I,pro]=candidate(zout,R,N,M);

% Recover
% random recover / greedy recover / 
[x_rand,y_rand,c_rand,c_rand_1,c_rand_2,l_rand]=Random_recover1(R,N,M,I,pro,s,f,p,e,dcm,S,F,alpha,H,lambda,einout,R_c);
[x_gre,y_gre,c_gre,c_gre_1,c_gre_2,l_gre]=greedy_recover1(R,N,M,I,pro,s,f,p,e,dcm,S,F,alpha,H,lambda,einout,R_c);
[x_ca,y_ca,c_ca,c_ca_1,c_ca_2,l_ca]=ca_l_recover1(R,N,M,I,s,f,p,e,dcm,S,F,alpha,H,lambda,einout,R_c,l,L);
 V=2;
[x_ca_lya,y_ca_lya,c_ca_lya,c_ca_lya_1,c_ca_lya_2,l_ca_lya]=ca_lya_recover1(R,N,M,I,s,f,p,e,dcm,S,F,alpha,H,lambda,einout,R_c,l,L,V);



% compute the candidate set I
function [I,pro]=candidate(zout,R,N,M)
I=cell(R,N);  %r_ij�ĺ�ѡ
pro=cell(R,N); %����
for i=1:R
    for j=1:N
        for k=1:M
            if zout(i,j,k)>0.0001
                I{i,j}=[I{i,j},k];
                pro{i,j}=[pro{i,j},round(zout(i,j,k),3)];
            end
        end
    end
end
end