%Lyapunov   % I candidate set
function [x_ca_lya,y_ca_lya,c_ca_lya,c_ca_lya_1,c_ca_lya_2,l_ca_lya]=ca_lya_recover1(R,N,M,I,s,f,p,e,dcm,S,F,alpha,H,lambda,einout,R_c,l,L,V)
D1=cell(1,N+1); % predicted delay
D=cell(1,N+1); % real delay
D1{1}=l(:,1);
D1{5}=l(:,5);
for j=2:N
    for j1=1:N-1
        if e(j1,j)>0
            D1{j}=[D1{j},l(:,j)-l(:,j1)]; %the delay of e(j1,j)
        end
    end
end
D1{N+1}=L'-l(:,N);  

% constract virtual queue
x_ca_lya=zeros(N,M);
y_ca_lya=zeros(R,N,M);
l_ca_lya=zeros(R,N+1);
S_remain=S;
F_remain=F;
q=cell(1,N); %virtual queue

for j=1:N
    fprintf("place s_%d\n",j);
    if j==1||j==5
        [y_temp,x_temp]=ca_lya_ILPstart(j,R,M,s,f,p,S_remain,F_remain,R_c,dcm,alpha,lambda,H,einout,D1,V,I);
        D{j}=diag(R_c*dcm*y_temp')*einout(1);
        l_ca_lya(:,j)=diag(R_c*dcm*y_temp')*einout(1); 
        for j1=2:N
               if e(j,j1)>0  %q2,q3,/q6
                q{j1}=[q{j1},D{j}-D1{j}];
               end
        end
    else
        if j==N
            n_j1=2;
            y_j1={squeeze(y_ca_lya(:,4,:)),squeeze(y_ca_lya(:,5,:))};
            e_j1j=[e(4,6),e(5,6)];
            l_remain=[L'-l_ca_lya(:,4),L'-l_ca_lya(:,5)];
            [y_temp,x_temp]=ILPend1(j,y_j1,n_j1,e_j1j,R,M,s,f,p,S_remain,F_remain,l_remain,R_c,dcm,alpha,lambda,H,einout); 
            l_real=[]; 
            for j1=1:N-1
                if e(j1,j)>0
                    l_real=[l_real,l_ca_lya(:,j1)+diag(squeeze(y_ca_lya(:,j1,:))*dcm*y_temp')*e(j1,j)];
                end
            end
            l_ca_lya(:,N)=max(l_real,[],2);
            l_ca_lya(:,N+1)=l_ca_lya(:,N)+diag(y_temp*dcm*R_c'*einout(2));
        else    
            %j=2 3 4 
            y_j1=cell(1);
            e_j1j=[];
            n_j1=0;
            for j1=1:N-1
                if e(j1,j)>0
                    n_j1=n_j1+1;
                    y_j1{n_j1}=squeeze(y_ca_lya(:,j1,:));
                    e_j1j=[e_j1j,e(j1,j)];
                end
            end
            [y_temp,x_temp]=ca_lya_ILPnormal(j,y_j1,e_j1j,n_j1,R,M,s,f,p,S_remain,F_remain,dcm,alpha,lambda,H,D1{j},q{j},V,I);
           l_real=[];
           for j1=1:N-1
                if e(j1,j)>0
                   D_temp=diag(squeeze(y_ca_lya(:,j1,:))*dcm*y_temp')*e(j1,j);
                   D{j}=[D{j},D_temp];
                   l_real=[l_real,l_ca_lya(:,j1)+D_temp];
                end
           end 
           l_ca_lya(:,j)=max(l_real,[],2);
           %q(:,j)=q(:,j-1)+sum(D{j-1},2)/size(D{j-1},2)-sum(D1{j-1},2)/size(D{j-1},2); 
           for j1=3:N
               if e(j,j1)>0   %when j=2/3, q4={q2+ ,q3+ ,}; j=4,q6={q4+ ,q5+ }
               q{j1}=[q{j1},max(q{j}+D{j}-D1{j},[],2)];  %special case:when j=4,6
               end
           end
           
        end
    end
    y_ca_lya(:,j,:)=y_temp;
    x_ca_lya(j,:)=x_temp;
    S_remain=S_remain-s(j)*x_ca_lya(j,:);
    F_remain=F_remain-f(j)*x_ca_lya(j,:);
      %Rx1  
end
    c_ca_lya_1=sum(sum(alpha.*x_ca_lya));
    c_ca_lya_2=sum(sum(max((x_ca_lya-H),0).*lambda));
    c_ca_lya=c_ca_lya_1+c_ca_lya_2;
    
end


function [y_temp,x_temp]=ca_lya_ILPstart(j,R,M,s,f,p,S_remain,F_remain,R_c,dcm,alpha,lambda,H,einout,D1,V,I) 
I_j=unique([I{:,j}]); %candidate edge servers of s_j
  m=length(I_j); %the number of candidate edge servers
  
cvx_begin
  cvx_solver mosek
        variable y_tempI(R,m) binary
        variable x_tempI(1,m) integer
        c_func=sum(x_tempI.*alpha(j,I_j)+max(x_tempI-H(j,I_j),0).*lambda(j,I_j));
        d=diag(R_c*dcm(:,I_j)*y_tempI')*einout(1)-D1{j};
        func=V*c_func+sum(pos(d));
        minimize(func)
        subject to
        x_tempI>=sum(y_tempI,1)/p(j); % the number of requests allocated to c_k
        s(j)*x_tempI<=S_remain(I_j); %1xm
        f(j)*x_tempI<=F_remain(I_j);   
        sum(y_tempI,2)==1; %each user only select one server
   cvx_end
   
   %transformation y_tempI to y_temp; x_tempI to x_temp
       y_temp=zeros(R,M);
       x_temp=zeros(1,M);
        for j=1:m
            x_temp(I_j(j))=x_tempI(j);
            for  i=1:R
              y_temp(i,I_j(j))=y_tempI(i,j); 
            end
        end
   
end
   
function [y_temp,x_temp]=ca_lya_ILPnormal(j,y_j1,e_j1j,n_j1,R,M,s,f,p,S_remain,F_remain,dcm,alpha,lambda,H,D1_j,q_j,V,I) 
I_j=unique([I{:,j}]); %candidate edge servers of s_j
  for i=1:n_j1
    I_j=unique([I_j,find(sum(y_j1{i}))]);% add the edge server where s_j1 are placed  %Function "unique(a)" can sort a.
  end
  m=length(I_j); %the number of candidate edge servers
  
if n_j1==1
   cvx_begin
   cvx_solver mosek
        variable y_tempI(R,m) binary
        variable x_tempI(1,m) integer
        c_func=sum(x_tempI.*alpha(j,I_j)+max(x_tempI-H(j,I_j),0).*lambda(j,I_j));
        d=q_j+diag(y_j1{1}*dcm(:,I_j)*y_tempI')*e_j1j(1)-D1_j;
        func=V*c_func+sum(pos(d));
        minimize(func)
        subject to
        x_tempI>=sum(y_tempI,1)/p(j); % the number of requests allocated to c_k
        s(j)*x_tempI<=S_remain(I_j);
        f(j)*x_tempI<=F_remain(I_j);
        sum(y_tempI,2)==1; %each user only select one server
 cvx_end   
else
    %n_j1==2:   %j=4 
   cvx_begin
   cvx_solver mosek
        variable y_tempI(R,m) binary
        variable x_tempI(1,m) integer
        c_func=sum(x_tempI.*alpha(j)+max(x_tempI-H(j,I_j),0).*lambda(j));
        d=max(q_j+[diag(y_j1{1}*dcm(:,I_j)*y_tempI')*e_j1j(1),diag(y_j1{2}*dcm(:,I_j)*y_tempI')*e_j1j(2)]-D1_j,[],2);
        func=V*c_func+sum(pos(d));
        minimize(func)
        subject to
        x_tempI>=sum(y_tempI,1)/p(j); % the number of requests allocated to c_k
        s(j)*x_tempI<=S_remain(I_j);
        f(j)*x_tempI<=F_remain(I_j);
        sum(y_tempI,2)==1; %each user only select one server
 cvx_end   
end
%transformation y_tempI to y_temp; x_tempI to x_temp
       y_temp=zeros(R,M);
       x_temp=zeros(1,M);
        for j=1:m
            x_temp(I_j(j))=x_tempI(j);
            for  i=1:R
              y_temp(i,I_j(j))=y_tempI(i,j); 
            end
        end
end