1. Please download the data set used in the experiment from   http://sguangwang.com/dataset/telecom.zip. You may need to Modify code in utils.py to load the data set. Because the public version of data set is processed to protect privacy.
2. You should both install cplex from Official website and install python package by " pip install cplex"
3. To run the code, just  "python run_and_print.py".
