import logging
import csv
import random
from datetime import datetime
from typing import List, Iterable
from utils import Random_BaseStation_Set, print_matrix, Sorted_BaseStation_Set
from copy import deepcopy

import numpy as np
import scipy.cluster.vq as vq

from base_station import BaseStation
from edge_server import EdgeServer
from utils import DataUtils


class ServerPlacer(object):
    def __init__(self, all_base_stations: List[BaseStation], distances: List[List[float]]):
        self.all_base_stations = all_base_stations.copy()
        logging.info('载入基站信息，共有{0}个基站'.format(len(all_base_stations)))
        self.distances = distances
        self.edge_servers = None

    def workload_to_energy(self, workload):
        return (118.8 + workload*59.4/3000000)

    def place_server(self, base_station_num, edge_coverage):
        raise NotImplementedError

    def _distance_edge_server_base_station(self, edge_server: EdgeServer, base_station: BaseStation) -> float:
        """
        Calculate distance between given edge server and base station

        :param edge_server:
        :param base_station:
        :return: distance(km)
        """
        if edge_server.base_station_id:
            return self.distances[edge_server.base_station_id][base_station.id]
        return DataUtils.calc_distance(edge_server.latitude, edge_server.longitude, base_station.latitude,
                                       base_station.longitude)

    def objective_latency(self):
        """
        Calculate average edge server access delay
        """
        assert self.edge_servers
        total_delay = 0
        base_station_num = 0
        for es in self.edge_servers:
            for bs in es.assigned_base_stations:
                delay = self._distance_edge_server_base_station(es, bs)
                logging.debug("base station={0}  delay={1}".format(bs.id, delay))
                total_delay += delay
                base_station_num += 1
        return total_delay / base_station_num

    def objective_workload(self):
        """
        Calculate average edge server workload

        Max worklaod of edge server - Min workload
        """
        assert self.edge_servers
        workloads = [e.workload for e in self.edge_servers]
        logging.debug("standard deviation of workload" + str(workloads))
        res = np.std(workloads)
        return res

    def objective_source_utilization(self):
        """计算平均资源利用率"""
        assert self.edge_servers
        sum = 0
        for e in self.edge_servers:
            sum += e.workload/EdgeServer.max_workload
        ans = sum/len(self.edge_servers)
        logging.debug("平均资源利用率" + str(ans))
        return ans

    def edge_sum(self):
        return len(self.edge_servers)

    def total_energy_consumption(self):
        raise NotImplementedError

class TopFirstPlacer(ServerPlacer):
    def __init__(self, all_base_stations: List[BaseStation], distances: List[List[float]]):
        super().__init__(all_base_stations, distances)
        self.base_station_to_place = []
        self.edge_coverage = 0          # 先初始化为0，后面会修改

    def place_server(self, base_station_num, edge_coverage):
        logging.info("{0}:Start running TopFirst with bs_num={1}, edge_coverage={2}".format(
            datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            base_station_num, edge_coverage))

        self.base_station_to_place = self.all_base_stations[:base_station_num]
        self.edge_coverage = edge_coverage

        edge_servers = []
        count_edge_id = 0

        sorted_base_stations = sorted(self.base_station_to_place, key=lambda x: x.workload)  # 从小到大排序，因为pop默认从末尾弹出

        while sorted_base_stations:  # 只要未放置的非空

            # 选择当前负载最大的作为edge
            bs_e = sorted_base_stations.pop()
            edge_temp = EdgeServer(count_edge_id, bs_e.latitude, bs_e.longitude, bs_e.id)
            count_edge_id += 1
            edge_temp.workload = bs_e.workload  # 初始化的时候只有所在基站的负载
            edge_temp.assigned_base_stations.append(bs_e)

            # 开始分配基站，采用首适应算法
            # 找出覆盖范围内的基站
            for station in sorted_base_stations:  # 这里的station就是一个bs对象
                distance = self._distance_edge_server_base_station(edge_temp, station)
                if distance <= self.edge_coverage:  # 在范围内就可以考虑
                    if station.workload + edge_temp.workload <= edge_temp.max_workload:
                        edge_temp.assigned_base_stations.append(station)  # 加入分配队列
                        edge_temp.workload += station.workload  # 更新edge负载
                        sorted_base_stations.remove(station)  # 从待放置集合中删除
                    else:  # 在距离内，但是edge负载已经超了
                        break
            # 将负载饱和的edge加入edge队列
            edge_servers.append(edge_temp)

        self.edge_servers = edge_servers
        logging.info("{0}:End running TopFirst ".format(datetime.now().strftime('%Y-%m-%d %H:%M:%S')))

    def total_energy_consumption(self):
        total_energy = 0
        for edge in self.edge_servers:
            total_energy += self.workload_to_energy(edge.workload)
        return total_energy


class RandomPlacer(ServerPlacer):
    def __init__(self, all_base_stations: List[BaseStation], distances: List[List[float]]):
        super().__init__(all_base_stations, distances)
        self.base_station_to_place = []
        self.edge_coverage = 0          # 先初始化为0，后面会修改

    def place_server(self, base_station_num, edge_coverage):
        logging.info("{0}:Start running Random with bs_num={1}, edge_coverage={2}".format(datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                                                                        base_station_num, edge_coverage))

        self.base_station_to_place = self.all_base_stations[:base_station_num]
        self.edge_coverage = edge_coverage

        edge_servers = []
        count_edge_id = 0

        unplaced_set = Random_BaseStation_Set(base_station_num)
        while not unplaced_set.is_empty():

            # 初始化---随机选一个作为edge
            e = unplaced_set.pop()
            bs_e = self.base_station_to_place[e]
            edge_temp = EdgeServer(count_edge_id, bs_e.latitude, bs_e.longitude, bs_e.id)
            count_edge_id += 1
            edge_temp.workload = bs_e.workload  # 初始化的时候只有所在基站的负载
            edge_temp.assigned_base_stations.append(bs_e)

            # 开始分配基站，采用首适应算法
            # 找出覆盖范围内的基站
            for station in unplaced_set:
                if self.distances[e][station] <= self.edge_coverage:  # 在范围内就可以考虑
                    if self.base_station_to_place[station].workload + edge_temp.workload <= EdgeServer.max_workload:
                        edge_temp.assigned_base_stations.append(self.base_station_to_place[station])  # 加入分配队列
                        edge_temp.workload += self.base_station_to_place[station].workload  # 更新edge负载
                        unplaced_set.remove(station)   # 从待放置集合中删除
                    else:   # 在距离内，但是edge负载已经超了
                        break
            # 将负载饱和的edge加入edge队列
            edge_servers.append(edge_temp)

        self.edge_servers = edge_servers

        # print("debug: Random放置结果， edge_num=", len(self.edge_servers))

        logging.info("{0}:End running Random ".format(datetime.now().strftime('%Y-%m-%d %H:%M:%S')))

    def total_energy_consumption(self):
        total_energy = 0
        for edge in self.edge_servers:
            total_energy += self.workload_to_energy(edge.workload)
        return total_energy

class PSOPlacer(ServerPlacer):
    def __init__(self, all_base_stations: List[BaseStation], distances: List[List[float]], particle_size):
        super().__init__(all_base_stations, distances)
        self.NUM_OF_PARTICLES = particle_size
        self.MAX_GENERATION = 5
        self.base_station_to_place = []
        self.edge_coverage = 0          # 先初始化为0，后面会修改

        # =========下方参数待定==============
        self.edge_MAX_WORKLOAD = EdgeServer.max_workload
        # 3000000

        # 定义： 字典--->  {energy：xxx,   particle: 二维矩阵, edge_servers: {放置edge的bs的矩阵编号（不是id！）：总负载}}
        self.particles = []     # 元素是20个字典
        self.p_bests = []       # 元素是20个字典,      修改元素的时候要用拷贝
        self.g_best = {}        # 一个元素,           修改元素的时候要用拷贝
        self.V = []             # 20 个一维向量

        # =========debug参数================
        self.debug_count = 0
        self.place_log = open(r'../data/place_log.txt', 'w')
        self.edge_num_log = open(r'../data/edge_num.csv', 'w', newline='')

    def place_server(self, base_station_num, edge_coverage):
        logging.info("{0}:Start running PSO with bs_num={1}, edge_coverage={2}".format(datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                                                                        base_station_num, edge_coverage))
        # ==============每改变一次参数后要重新初始化的内容========================
        self.particles = []     # 元素是20个字典
        self.p_bests = []       # 元素是20个字典,      修改元素的时候要用拷贝
        self.g_best = {}        # 一个元素,           修改元素的时候要用拷贝
        self.V = []             # 20 个一维向量
        # =====================================================================

        self.base_station_to_place = self.all_base_stations[:base_station_num]
        self.edge_coverage = edge_coverage

        # self.place_log = open(r'C:\Users\Monster-Desk\Desktop\place_log.txt', 'w')

        # =============edge num 统计初始化=============================
        debug_edge_num = []
        # 表头
        debug_edge_head = ['','']
        for num_edge in range(self.NUM_OF_PARTICLES):
            debug_edge_head.append(str(num_edge))
        debug_edge_head.append('gbest')
        # ============================================================

        # 批量初始化
        for i in range(self.NUM_OF_PARTICLES):

            self.particles.append({'num':0, 'matrix': 0, 'edge_workload_dict':0, 'total_energy':0, 'diagonal':0})
            self.init(base_station_num, self.particles[i])

            wrong_set_i = self.check_particles(self.particles[i]['matrix'])
            print('After initiation, the wrong set' + str(i) + ':  ' + str(list(wrong_set_i)))
            print('After initiation, the wrong set' + str(i) + ':  ' + str(list(wrong_set_i)), file=self.place_log)

        # 初次更新pbest gbest
        self.update_pbest(base_station_num)
        self.update_gbest()

        # 记录初始化情况情况
        debug_line = ['覆盖半径 ' + str(self.edge_coverage), '初始化']
        for i_edge in range(self.NUM_OF_PARTICLES):
            # print('num = ', self.particles[i_edge]['num'], file=self.edge_num_log)
            debug_line.append(self.particles[i_edge]['num'])
        debug_line.append(self.g_best['num'])
        debug_edge_num.append(debug_line)
        # 演进操作
        # 开始演进

        # 更新粒子
        for generation in range(self.MAX_GENERATION):
            print("\n\n==============覆盖半径", self.edge_coverage,'  基站数目', base_station_num, "  第", generation, "代==================")
            print("\n\n==============覆盖半径", self.edge_coverage,'  基站数目', base_station_num, "  第", generation, "代========================", file = self.place_log)
            for particle in range(self.NUM_OF_PARTICLES):
                self.evelution(particle)
                self.update_particle(self.particles[particle])

            self.update_pbest(base_station_num)
            self.update_gbest()

            # 记录粒子情况
            debug_line = ['覆盖半径 '+str(self.edge_coverage), '代数 '+str(generation)]
            for i_edge in range(self.NUM_OF_PARTICLES):
                # print('num = ', self.particles[i_edge]['num'], file=self.edge_num_log)
                debug_line.append(self.particles[i_edge]['num'])
            debug_line.append(self.g_best['num'])

            debug_edge_num.append(debug_line)

        debug_edge_num.append([])

        debug_csv_writer = csv.writer(self.edge_num_log)
        debug_csv_writer.writerow(debug_edge_head)
        debug_csv_writer.writerows(debug_edge_num)

        # 把结果翻译成标准输出
        edge_servers = []
        count_edge_id = 0

        for edge_bs_id, edge_workload in self.g_best['edge_workload_dict'].items():
            bs_temp = self.base_station_to_place[edge_bs_id]
            edge_temp = EdgeServer(count_edge_id, bs_temp.latitude, bs_temp.longitude, bs_temp.id)
            count_edge_id += 1
            edge_temp.workload = edge_workload

            for line in range(len(self.g_best['matrix'])):
                if self.g_best['matrix'][line][edge_bs_id]:
                    edge_temp.assigned_base_stations.append(self.base_station_to_place[line])

            edge_servers.append(edge_temp)

        self.edge_servers = edge_servers

        # self.place_log.close()
        logging.info("{0}:End running PSO ".format(datetime.now().strftime('%Y-%m-%d %H:%M:%S')))


    # 初始化放置,包括粒子、pbest、gbest的初始化
    def init(self, base_station_num, particle):

        edge_count = 0

        unplaced_set = Random_BaseStation_Set(base_station_num)
        # unplaced_set = Sorted_BaseStation_Set(self.base_station_to_place, base_station_num)

        matrix = [[False for i in range(base_station_num)] for j in range(base_station_num)]
        edge_workload = {}


        # 只要未放置集合非空
        while not unplaced_set.is_empty():

            edge_count += 1

            # 放置边缘服务器
            e = unplaced_set.pop()
            matrix[e][e] = True    # 先将这个标记成已经放置

            # 待绑定的基站
            candidates = {}
            candidates_total_workload = 0

            # 找出覆盖范围内的基站
            for station in unplaced_set:
                if self.distances[e][station] <= self.edge_coverage:            # 在范围内就加入备选序列
                    candidates[station] = 0         # 初始化
                    candidates_total_workload += self.base_station_to_place[station].workload   # 计算范围内的基站的总负载

            # 计算排序权重
            for k in candidates.keys():
                # 防止有0距离
                if self.distances[e][k] == 0:
                    self.distances[e][k] = DataUtils.calc_distance(self.base_station_to_place[e].latitude, self.base_station_to_place[e].longitude, self.base_station_to_place[k].latitude,
                                                                         self.base_station_to_place[k].longitude)

                if self.distances[e][k] * candidates_total_workload > 0:
                    candidates[k] = (self.edge_coverage / self.distances[e][k]) + (self.base_station_to_place[k].workload / candidates_total_workload)


            # 按权重排序
            sorted_canditates = dict(sorted(candidates.items(), key=lambda d:d[1], reverse = True))

            # sorted_canditates = candidates

            # 开始修改矩阵，给edge分配bs
            edge_temp_workload = self.base_station_to_place[e].workload
            for bs in sorted_canditates.keys():
                bs_i = bs         # bs_i 仅仅是编码矩阵中的位置，并非基站id
                if self.base_station_to_place[bs_i].workload + edge_temp_workload <= self.edge_MAX_WORKLOAD:
                    matrix[bs_i][e] = True
                    unplaced_set.remove(bs_i)
                    edge_temp_workload += self.base_station_to_place[bs_i].workload


            # 记录edge的负载
            edge_workload[e] = edge_temp_workload

        print('初始化完成，放置edge节点个数:', edge_count)
        # print('length of edge_workload:', len(edge_workload))

        # 将初始化结果写入particle
        particle['num'] = edge_count
        particle['matrix'] = matrix
        particle['edge_workload_dict'] = edge_workload
        particle['total_energy'] = self._cal_energy(edge_workload)
        particle['diagonal'] = [matrix[i][i] for i in range(len(matrix))]

    '''jj'''
    # init_2
    # def init(self, base_station_num, particle):
    #
    #
    #     edge_count = 0
    #
    #     unplaced_set = Random_BaseStation_Set(base_station_num)
    #
    #     matrix = [[False for i in range(base_station_num)] for j in range(base_station_num)]
    #     edge_workload = {}
    #
    #     # 只要未放置集合非空
    #     while not unplaced_set.is_empty():
    #         edge_count += 1
    #
    #         # 放置边缘服务器
    #         e = unplaced_set.pop()
    #         matrix[e][e] = True    # 先将这个标记成已经放置
    #
    #         edge_temp_workload = self.base_station_to_place[e].workload
    #         for station in unplaced_set:
    #             if self.distances[e][station] <= self.edge_coverage:
    #                 if self.base_station_to_place[station].workload + edge_temp_workload <= self.edge_MAX_WORKLOAD:
    #                     matrix[station][e] = True
    #                     unplaced_set.remove(station)
    #                     edge_temp_workload += self.base_station_to_place[station].workload
    #
    #         edge_workload[e] = edge_temp_workload
    #
    #     print('bug_id count:',edge_count)
    #     # print('length of edge_workload:', len(edge_workload))
    #
    #     # 将初始化结果写入particle
    #     particle['num'] = edge_count
    #     particle['matrix'] = matrix
    #     particle['edge_workload_dict'] = edge_workload
    #     particle['total_energy'] = self._cal_energy(edge_workload)
    #     particle['diagonal'] = [matrix[i][i] for i in range(len(matrix))]

    def update_particle(self, particle):

        edge_num, edge_workload_dict = self._edge_condition(particle)

        # 更新粒子信息
        particle['num'] = edge_num
        particle['edge_workload_dict'] = edge_workload_dict
        particle['total_energy'] = self._cal_energy(edge_workload_dict)
        particle['diagonal'] = self._get_diagonal(particle)

    # 获取对角线
    def _get_diagonal(self, particle):
        diagonal = [particle['matrix'][i][i] for i in range(len(particle['matrix']))]
        return diagonal

    # 获取{每个edge的bs号码:能耗}
    def _edge_condition(self, particle):

        matrix = particle['matrix']
        edge_workload_dict = {}

        edge_num = 0
        for i in range(len(matrix)):
            bs = matrix[i][i]
            edge_energy_i = 0

            if bs == True:
                edge_num += 1
                for j in range(len(matrix)):
                    if matrix[j][i] == True:
                        edge_energy_i += self.base_station_to_place[j].workload

                edge_workload_dict[i] = edge_energy_i  # 放在if范围内，只有edge才录入

        return edge_num, edge_workload_dict

    # 计算能耗
    def _cal_energy(self, edge_workload_dict):   # 输入{edge：edge_consumption，...}
        total_energy_consumption = 0
        for edge, workload in edge_workload_dict.items():

            # ========================能耗公式待定=======================================
            total_energy_consumption += self.workload_to_energy(workload)
        return total_energy_consumption


    def total_energy_consumption(self):
        return self.g_best['total_energy']

    # 更新pbest
    def update_pbest(self, base_station_num):

        if len(self.p_bests) == 0:
            print('start initiate p_best')
            self.p_bests = deepcopy(self.particles)
            print('p_best initiation complete')
        else:
            print('start update p_best')
            for i in range(self.NUM_OF_PARTICLES):
                if self.p_bests[i]['total_energy'] > self.particles[i]['total_energy']:
                    self.p_bests[i] = deepcopy(self.particles[i])

                    self.init(base_station_num, self.particles[i])   # 更新为pbest之后重新初始化

                print('p_best[',i,'] update complete')

    # 更新gbest
    def update_gbest(self):
        # 求pbest中的最优值
        print('start update g_best')
        mark, energy_mark = 0, self.p_bests[0]['total_energy']
        for j in range(1, self.NUM_OF_PARTICLES):
            if energy_mark > self.p_bests[j]['total_energy']:
                mark = j
                energy_mark = self.p_bests[j]['total_energy']

        print('find best p_best complete')

        if self.g_best == {}:
            self.g_best = deepcopy(self.p_bests[mark])
        else:
            if self.g_best['total_energy'] > self.p_bests[mark]['total_energy']:
                self.g_best = deepcopy(self.p_bests[mark])
        print('g_best update complete')


    # 粒子进化
    def evelution(self, particle_id):   # particle_id 指在0到19号粒子中的位置
        particle_i_now = deepcopy(self.particles[particle_id])
        particle_i_next = self.particles[particle_id]
        pbest_i = self.p_bests[particle_id]
        gbest_i = self.g_best

        # 提取对角线（diagonal）
        X_diagonal= self.particles[particle_id]['diagonal']
        X_pbest_diagonal= self.p_bests[particle_id]['diagonal']
        X_gbest_diagonal= self.g_best['diagonal']

        # 随机初始化V_0
        if self.V == []:
            for count in range(self.NUM_OF_PARTICLES):
                V_0 = [True if random.random()>0.5 else False for i in range(len(pbest_i['matrix'])) ]
                self.V.append(V_0)

        # 计算三个概率
        E_1 = self.particles[particle_id]['total_energy']
        E_2 = self.p_bests[particle_id]['total_energy']
        E_3 = self.g_best['total_energy']
        E_min = min([E_1,E_2,E_3])



        # ===============待优化================================
        e1 = (E_1-E_min*0.9)**2
        e2 = (E_2-E_min*0.9)**2
        e3 = (E_3-E_min*0.9)**2
        fen_mu = 1 / e1 + 1 / e2 + 1 / e3

        # ======================================================

        p_1 = (1/e1)/fen_mu
        p_2 = (1/e2)/fen_mu
        p_3 = (1/e3)/fen_mu

        print(E_min, '---', E_1, E_2, E_3)
        print(E_min, '---', E_1, E_2, E_3, file= self.place_log )
        print(p_1, p_2, p_3)
        print(p_1, p_2, p_3, file=self.place_log)

        # 速度更新
        v_now = self.V[particle_id]
        v_next = []
        for i in range(len(v_now)):
            r = random.random()
            if r <= p_1:
                v_next.append(v_now[i])
            elif (r > p_1) and (r <= p_2 + p_1):
                v_next.append(not X_pbest_diagonal[i] == X_diagonal[i])
            else:
                v_next.append(not X_gbest_diagonal[i] == X_diagonal[i])
        # 写回，使修改生效
        self.V[particle_id] = v_next

        # 坐标更新
        for i in range(len(v_next)):
            if v_next[i]:
                r = random.random()
                if r <= p_1:
                    target = particle_i_now
                elif (r > p_1) and (r <= p_2 + p_1):
                    target = pbest_i
                else:
                    target = gbest_i

                for line in range(len(particle_i_now['matrix'])):
                    particle_i_next['matrix'][line][i] = target['matrix'][line][i]

        # 检查错误
        wrong_lines = self.check_particles(particle_i_next['matrix'])

        # 删除&回填
        self.del_and_refill(particle_i_next, wrong_lines)

        print('回填后，错误为：', self.check_particles(particle_i_next['matrix']))

    # 检查粒子是否合法，分别按照行列检查
    # 返回出错的行号
    def check_particles(self, matrix):
        wrong_lines = set([])
        # 按行遍历
        for row in range(len(matrix)):
            count = 0
            to_delete = False
            for col in range(len(matrix)):
                if matrix[row][col] == True:
                    count += 1
                    # 检查是否连在有效edge上
                    if matrix[col][col] !=True:
                        # count = 999
                        to_delete = True
                        break
                    if count > 1:
                        # to_delete = True
                        break
            if count != 1:       # 0个或超过1个都不行
                to_delete = True
            # 对有标记的行加入删除集合
            if to_delete:
                wrong_lines.add(row)
                # 如果要删除的是edge，则连到它的都删除
                if matrix[row][row] == True:
                    for line in range(len(matrix)):
                        if matrix[line][row] == True:
                            wrong_lines.add(line)
        return wrong_lines

    # 删除与回填操作
    def del_and_refill(self, target_particle, wrong_lines):

        matrix_length = len(target_particle['matrix'])

        # 删除操作
        for line in wrong_lines:
            target_particle['matrix'][line] = [False for i in range(matrix_length)]

        # 获取当前particle状态
        edge_state = self._get_diagonal(target_particle)
        _, edge_workload = self._edge_condition(target_particle)

        # 回填
        for line in wrong_lines:
            is_refilled = False

            # 先找现有的基站看能否接入
            for e in range(matrix_length):
                if edge_state[e]:
                    # 能耗不超标 且 在覆盖范围内
                    if (edge_workload[e]+self.base_station_to_place[line].workload < self.edge_MAX_WORKLOAD) and (self.distances[e][line] < self.edge_coverage):
                        edge_workload[e] += self.base_station_to_place[line].workload
                        target_particle['matrix'][line][e] = True
                        is_refilled = True
                        break

            # 如果没有现有的可用，就开辟为新的edge
            if not is_refilled:
                target_particle['matrix'][line][line] = True
                edge_state[line] = True
                edge_workload[line] = self.base_station_to_place[line].workload
                # is_refilled = True
                # break

            # 更新负载字典
            target_particle['edge_workload_dict'] = edge_workload
