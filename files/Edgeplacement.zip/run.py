import time
from typing import Dict

from algorithms import *
from utils import *
import csv


def run_problem(problem: ServerPlacer, n, k):
    assert hasattr(problem, "place_server")
    problem.place_server(n, k)
    return (problem.objective_latency(), problem.objective_workload(), problem.total_energy_consumption(), problem.objective_source_utilization(), problem.edge_sum())


def run_with_parameters(problems: Dict[str, ServerPlacer], n, k):
    results = {}
    results['PSO'] = run_problem(problems['PSO'], n, k)

    #
    # # 重复试验次数
    # repeat = 10
    #
    # # ans_latency = []
    # # ans_workload = []
    # # ans_energy = []
    # # ans_utilization = []
    # # ans_edge_sum = []
    # # for t in range(repeat):
    # #     res = run_problem(problems['TopFirst'], n, k)
    # #     ans_latency.append(res[0])
    # #     ans_workload.append(res[1])
    # #     ans_energy.append(res[2])
    # #     ans_utilization.append(res[3])
    # #     ans_edge_sum.append(res[4])
    # #     # time.sleep(1)
    # # results['TopFirst'] = (get_average(ans_latency), get_average(ans_workload), get_average(ans_energy), get_average(ans_utilization), get_average(ans_edge_sum))
    # #
    # # ans_latency = []
    # # ans_workload = []
    # # ans_energy = []
    # # ans_utilization = []
    # # ans_edge_sum = []
    # # for t in range(repeat):
    # #     res = run_problem(problems['Random'], n, k)
    # #     ans_latency.append(res[0])
    # #     ans_workload.append(res[1])
    # #     ans_energy.append(res[2])
    # #     ans_utilization.append(res[3])
    # #     ans_edge_sum.append(res[4])
    # #     # time.sleep(1)
    # # results['Random'] = (get_average(ans_latency), get_average(ans_workload), get_average(ans_energy), get_average(ans_utilization), get_average(ans_edge_sum))
    #
    # sum_a = 0
    # sum_b = 0
    # sum_c = 0
    # sum_d = 0
    # sum_bs = 0
    # for t in range(repeat):
    #     res = run_problem(problems['TopFirst'], n, k)
    #     sum_a += res[0]
    #     sum_b += res[1]
    #     sum_c += res[2]
    #     sum_d += res[3]
    #     sum_bs += res[4]
    #     # time.sleep(1)
    # results['TopFirst'] = (sum_a / repeat, sum_b / repeat, sum_c / repeat, sum_d / repeat, sum_bs / repeat)
    #
    # sum_a = 0
    # sum_b = 0
    # sum_c = 0
    # sum_d = 0
    # sum_bs = 0
    # for t in range(repeat):
    #     res = run_problem(problems['Random'], n, k)
    #     sum_a += res[0]
    #     sum_b += res[1]
    #     sum_c += res[2]
    #     sum_d += res[3]
    #     sum_bs += res[4]
    #     # time.sleep(1)
    # results['Random'] = (sum_a / repeat, sum_b / repeat, sum_c / repeat, sum_d / repeat, sum_bs / repeat)

    return results


def run(data: DataUtils):
    problems = {}
    # problems['TopFirst'] = TopFirstPlacer(data.base_stations, data.distances)
    # problems['Random'] = RandomPlacer(data.base_stations, data.distances)

    particle_size = 10
    problems['PSO'] = PSOPlacer(data.base_stations, data.distances, particle_size)

    # 存数据的矩阵
    ans_distance = [['distance:'], ['N', 'PSO', 'TopFirst', 'Random']]
    ans_workload = [['workload:'], ['N', 'PSO', 'TopFirst', 'Random']]
    ans_energy = [['energy:'], ['N', 'PSO', 'TopFirst', 'Random']]
    ans_utilization = [['utilization:'], ['N', 'PSO', 'TopFirst', 'Random']]
    ans_edge_sum = [['bs_sum:'], ['N', 'PSO', 'TopFirst', 'Random']]

    with open('../data/results.txt', 'w') as txt_file:



        # 变基站数量

        # k = 5
        # for n in range(300, 1400, 200):
        #     print("N={0}, K={1}".format(n, k), file=txt_file)
        #     results = run_with_parameters(problems, n, k)
        #
        #     line_distance = [n]
        #     line_workload = [n]
        #     line_energy = [n]
        #     line_utilization = [n]
        #     line_edge_sum = [n]
        #
        #     for key, value in results.items():
        #         print(key, "平均距离(km)={0}, 负载标准差={1}, 能耗为={2}, 平均资源利用率={3}".format(value[0], value[1], value[2], value[3], value[4]), file=txt_file)
        #         txt_file.flush()
        #
        #         line_distance.append(value[0])
        #         line_workload.append(value[1])
        #         line_energy.append(value[2])
        #         line_utilization.append(value[3])
        #         line_edge_sum.append(value[4])
        #
        #     ans_distance.append(line_distance)
        #     ans_workload.append(line_workload)
        #     ans_energy.append(line_energy)
        #     ans_utilization.append(line_utilization)
        #     ans_edge_sum.append(line_edge_sum)

        # 变距离
        # n = 1596  # 6月15日后
        n = 1393
        for k in range(5, 6):
            print("N={0}, K={1}".format(n, k), file=txt_file)
            results = run_with_parameters(problems, n, k)

            line_distance = [particle_size]
            line_workload = [particle_size]
            line_energy = [particle_size]
            line_utilization = [particle_size]
            line_edge_sum = [particle_size]

            for key, value in results.items():
                print(key, "平均距离(km)={0}, 负载标准差={1}, 能耗为={2}, 平均资源利用率={3}".format(value[0], value[1], value[2], value[3], value[4]), file=txt_file)
                txt_file.flush()

                line_distance.append(value[0])
                line_workload.append(value[1])
                line_energy.append(value[2])
                line_utilization.append(value[3])
                line_edge_sum.append(value[4])

            ans_distance.append(line_distance)
            ans_workload.append(line_workload)
            ans_energy.append(line_energy)
            ans_utilization.append(line_utilization)
            ans_edge_sum.append(line_edge_sum)
        # txt_file.close()

    # 写入csv文件
    with open('../data/results.csv', 'w', newline='') as csv_file:
        logging.info('写入csv文件')
        csv_writer = csv.writer(csv_file)
        csv_writer.writerows(ans_distance)
        csv_writer.writerows(ans_workload)
        csv_writer.writerows(ans_energy)
        csv_writer.writerows(ans_utilization)
        csv_writer.writerows(ans_edge_sum)
        logging.info('csv写入成功')



if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)


    start_time = "start run at: {0}".format(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

    data = DataUtils('../data/基站经纬度.csv', '../data/上网信息输出表（日表）7月15号之后.csv')
    run(data)

    end_time = "end run at:{0}".format(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

    print('\n\n\n')
    logging.info(start_time)
    logging.info(end_time)
