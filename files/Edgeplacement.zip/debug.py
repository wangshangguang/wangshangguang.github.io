from algorithms import *
from utils import DataUtils
import csv

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)

    data = DataUtils('../data/基站经纬度.csv', '../data/上网信息输出表（日表）7月15号之后.csv')
    # pso_placer = PSOPlacer(data.base_stations, data.distances)
    # pso_placer.place_server(1596, 5)


    with open(r"C:\Users\Monster-Desk\Desktop\base_station_info.csv",'w', newline='') as file:
        csv_writer = csv.writer(file)
        title = ['id', 'usernum', 'latitude', 'longitude', 'workload']
        list = [[data.base_stations[i].id, data.base_stations[i].user_num, data.base_stations[i].latitude, data.base_stations[i].longitude, data.base_stations[i].workload] for i in range(len(data.base_stations))]
        csv_writer.writerow(title)
        csv_writer.writerows(list)