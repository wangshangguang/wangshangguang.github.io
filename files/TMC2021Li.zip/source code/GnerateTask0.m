function TaV=GnerateTask0(T)

%---------Parameters------------------
%global T; % 总的任务数
fileID = fopen('taxi_sequence.txt','r');
C = textscan(fileID,'%s %D %f %f %d %d %d','Delimiter',',');
fclose(fileID);
id=C{1,1};
time=C{1,2};
lat=C{1,3};
lon=C{1,4};
sp=C{1,5};
ang=C{1,6};
rl=C{1,7};
a=0.25;
b=0.25; %生成[a,b]内的时延.单位是秒
for i=1:T
TaV(i).ID=id((i-1)*11+1); %编号
TaV(i).role=rl((i-1)*11+1); %身份 任务车辆还是空闲车辆 
TaV(i).speed=sp((i-1)*11+1); %速度
TaV(i).RSU1=0; %任务分配的位置即关联的RSU
TaV(i).RSU2=0; %任务返回的位置即关联的RSU
TaV(i).direction=1; %行驶方向
TaV(i).input=1e6; %任务属性，输入数据
TaV(i).output=0.5e6;%任务属性，输出数据
TaV(i).cpu=200e6;%任务属性，需要计算量
TaV(i).latency= a+(b-a)*rand(); %任务属性，时延要求
TaV(i).completion=0;%任务属性，是否完成
 TaV(i).Single_completion=0;
 TaV(i).DelayOptimal_completion=0;
  TaV(i).Oracle_completion=0;
  TaV(i).Reliability_completion=0;
end