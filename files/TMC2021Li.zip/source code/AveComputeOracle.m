function avef2=AveComputeOracle(SeV,TaV,t,Repliset,Queue2,Queue3,Queue4)
global segment;% CDF��ɢ�����ܸ���
global ita;

if sum(Repliset)==0 %������Ƽ���Ϊ�գ�����ֵΪ�����
    avef2=10000;
else
produ=zeros(1,3*segment);
for j=1:3*segment
    produ(j)=1;
    for i=1:length(SeV)
        if Repliset(i)==1  
            produ(j)=produ(j).*(1-SeV(i).Oracle_Fv(j));
        end
        
    end
end
aveL=sum(produ)/segment; %ȡֵ��ΧΪ[0,3]
if aveL>=1
    flag=1;
else 
    flag=0;
end
    
for tao=1:t-1
Tcompletion(tao)=TaV(tao).completion;
end
avef2=ita*aveL+Queue2* sum(Tcompletion)./(t-1)+ Queue3*(aveL-1)*flag+Queue4*(aveL-1)^2*flag;
end
