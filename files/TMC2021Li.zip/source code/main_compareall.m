%%%--------------------AlgorithmCompare0713------
clc; clear all; 
%---------Parameters------------------
global T; % 总的任务数


global ipslon;%可靠性要求
global xi;%可靠性要求
global sigma;%可靠性要求
global segment;% CDF离散化的总个数
global budget;% 成本约束，单位s
global ita;
global Lmax; %仿真中最大的时延

global DistRSU; % RSU的覆盖范围
global RateR2V; % RSU 到 SeV 的数据速率
global RateV2R; % RSU 到 SeV 的数据速率
global Backhaul; % RSU 到 RSU 的时延



segment=20;%暂时先把没有超过时延范围的,归一化之后[0,1]之间，分为segment份， 设置返回的归一化时延最多不超过3，如果超过按3算，[1,3]之间分为2segment份
ipslon=0.01;%
% xi=0.23; 
% sigma=5e-2;
xi=-0.59; 
sigma=1.18;
ita=2;

budget=2;
%budget=0.8;
T=20000;
Lmax=2.5;
PD1=0.01;
PD2=0.1;
alpha=1.1;
Dim=1;
hT=10;

ave_seq_RecordLatency= zeros(6,T);
ave_seq_RecordComLatency= zeros(6,T);
 ave_seq_RecordComplete= zeros(6,T);
 ave_seq_RecordRegret= zeros(6,T);
  
%rand('seed',200); 概率值的变化

for iter=1:1
 
%rand('seed',200);
% probPrio=0.5+0.5*rand(1,10);  
%---------Generate Veihcles（1）------------------
%Step1:仿真生成一个RSU，一个任务队列，一些固定的SeVle]
TaV=GnerateTask(T);
SeV=GnerateSeV();
%--------------Generate from dataset-------------
% 
% 
%  TaV=GnerateTask0(T);
%  for t=1:T
%  SeV=GnerateSeV0(t);
%  end
%----------------------------------------
 probPrio=0.5+0.5*rand(1,length(SeV)); 
 
    
RecordOptimalSet=zeros(1,T);
RecordLatencyOracle=zeros(1,T);
RecordComLatencyOracle=zeros(1,T);
RecordCompleteOracle=zeros(1,T);

RecordLatency=zeros(1,T);
RecordComLatency=zeros(1,T);
RecordRepliset=zeros(T, length(SeV));
RecordComplete=zeros(1,T);

RecordLatencyDATE=zeros(1,T);
RecordComLatencyDATE=zeros(1,T);
RecordReplisetDATE=zeros(T, length(SeV));
RecordCompleteDATE=zeros(1,T);

RecordLatencyLTR=zeros(1,T);
RecordComLatencyLTR=zeros(1,T);
RecordReplisetLTR=zeros(T, length(SeV));
RecordCompleteLTR=zeros(1,T);

RecordLatencySingle=zeros(1,T);
RecordComLatencySingle=zeros(1,T);
RecordReplisetSingle=zeros(T, length(SeV));
RecordCompleteSingle=zeros(1,T);

RecordLatencyRandom=zeros(1,T);
RecordComLatencyRandom=zeros(1,T);
RecordReplisetRandom=zeros(T, length(SeV));
RecordCompleteRandom=zeros(1,T);
RecordL=zeros(length(SeV),T);
RecordLC=zeros(length(SeV),T);


for t=1:T
    LC=zeros(1,length(SeV));
     L=zeros(1,length(SeV));
%     % ----------generate latency（1）=====
     
         LC=0.1+1*rand(1,length(SeV));
        L=zeros(1,length(SeV));
       % prob=0.5+0.5*rand();  
       for i=1:length(SeV)
        if rand()< probPrio(i)
%            L(i)=rand()*1+1.5;
            L(i)=LC(i)+(2.5-LC(i))*rand();
          % L(i)=0.7+rand()*1.8;
            
        else
           L(i)=2*Lmax*rand()+Lmax;
        end
       end
     
% %       %----------compute latency（2）=====
% for i=1:length(SeV)
%     SeV(i).idleCPU=150e6+0.3e9*rand();
%    if rand()< probPrio(i)
%       [LC(i), L(i)]=LatencyCompute(TaV(t), SeV(i));
%    else
%       [LC(i), L(i)]=LatencyCompute(TaV(t), SeV(i));
%        L(i)=2*Lmax*rand()+Lmax;
%    end 
% 
% end
%-------------------------
    RecordL(:,t)=L;
     RecordLC(:,t)=LC;
       
%        
     %---------Our Algorithm--------------------------------------

        %-------------------更新队列长度---------------------
        if t==1  
          Queue(1,t)=0;
          Queue(2,t)=0;
          Queue(3,t)=0;
          Queue(4,t)=0;
        else
            for i=1:length(SeV)
             SeVcomlatency(i)=getfield(SeV(i),'comlatency'); 
            SeVlatency(i)=getfield(SeV(i),'latency'); 
            end
         TempSeVlatency=SeVlatency.*Repliset;
         Queue(1,t)=Queue(1,t-1)+max(sum(SeVcomlatency.*Repliset)-budget,0);
         Queue(2,t)=Queue(2,t-1)+max(Indicate(SeV,Repliset)-ipslon,0);
         Queue(3,t)=Queue(3,t-1)+max((min(TempSeVlatency(TempSeVlatency~=0))-1-sigma/(1-xi))*Indicate(SeV,Repliset),0);
        % Queue(3,t)=Queue(3,t-1)+(min(TempSeVlatency(TempSeVlatency~=0))-1-sigma/(1-xi))*Indicate(SeV,Repliset);
         Queue(4,t)=Queue(4,t-1)+max(((min(TempSeVlatency(TempSeVlatency~=0))-1)^2-2*sigma^2/(1-xi)/(1-2*xi))*Indicate(SeV,Repliset),0);
        % Queue(4,t)=Queue(4,t-1)+(( min(TempSeVlatency(TempSeVlatency~=0))-1)^2-2*sigma/(1-xi)/(1-2*xi))*Indicate(SeV,Repliset),0;
         %----------------------------------------------------------------------------------------------------------------------------  
        %记录----------------------------------------
             RecordLatency(t-1)=min(TempSeVlatency(TempSeVlatency~=0));
             RecordComLatency(t-1)=sum(SeVcomlatency.*Repliset);
        %记录----------------------------------------
        end
    
    fistshow=zeros(1,length(SeV)); %重置第一次出现的车辆向量记录
     Repliset=zeros(1,length(SeV)); %重置复制集合
    %ReplisetSingle=zeros(1,length(SeV)); %重置复制集合
    
    for i=1:length(SeV) %检查是否有第一次出现的车辆
        SeV(i).show=0; %出现次数， Step 1 用这句
         %SeV(i).show= SeV(i).show+1; %出现次数，Step 2 用这句
         if  SeV(i).show==1
             fistshow(i)=1;
         end
    end
    %-------对于直接生成的情况------------------
    if t==1
    fistshow=ones(1,length(SeV));
    end
    %------------------------------------------
    
    if any(fistshow) %如果有第一次出现的车辆，就直接选择它
       Repliset=fistshow;
      % ReplisetSingle=fistshow;
       for  i=1:length(SeV) %%获得各种时延
            if  Repliset(i)==1 % 为选中的SeV计算时延
                SeV(i).play=SeV(i).play+1;
%                  %----------generate latency（step1）=====
%                  LC=0.1+1*rand();
%                 if rand()< probPrio(i)
%                    L=rand()*2+0.5;
%                 else
%                    L=2*Lmax*rand()+Lmax;
%                 end
                 %----------compute latency （step2）=====
                     %  [LC, L]=LatencyCompute(TaV, SeV,SINR)
                %-----------更新车的选择次数， 计算时延的均值，总时延的分布----------
                 SeV(i).comlatency=LC(i)/Lmax; %归一化后的数值，瞬时值
                 SeV(i).latency=L(i)/Lmax;  %归一化后的数值，瞬时值  
                 SeV(i).LCv= (SeV(i).play-1)/SeV(i).play *SeV(i).LCv+ SeV(i).comlatency/SeV(i).play;
                 % SeV(i).LCv
                 %----------------------------------------
                 if SeV(i).latency>3
                     SeV(i).latency=3;
                 end
                 for j=1:3*segment
                       if    (SeV(i).latency>(j-1)/segment)&& ( SeV(i).latency<=(j)/segment)
                              SeV(i).Count(j)=SeV(i).Count(j)+1; 
                       end
                 end
                 for j=1:3*segment
                     SeV(i).Fv(j)=sum(SeV(i).Count(1:j))/sum(SeV(i).Count);% CDF 
                 end
               %SeV(i).Fv
               %----------------------------------------
            end
   end
   %---------------------记录----------------------     
%     if Indicate(SeV,Repliset)==1
%        TaV(t).completion=1;% 1表示未完成
%     else
%       TaV(t).completion=0;% 1表示未完成
%     end
    RecordComplete(t)=Indicate(SeV,Repliset);
    %---------------------记录----------------------         
            
        %------------没有新出现的车辆-----------  
 else  %更新选择依据
        for  i=1:length(SeV) %
            if  SeV(i).play==0
                 SeV(i).BarLCv(i)=0;
                 SeV(i).BarFv(i,:)=1;
            else
             SeV(i).BarLCv=max(SeV(i).LCv-sqrt(PD1*log(t- SeV(i).show)./SeV(i).play),0); %log前面的参数还需要调
%              SeV(i).BarLCv
             SeV(i).BarFv=min( SeV(i).Fv+sqrt(PD2*log(t- SeV(i).show)./SeV(i).play),1); %log前面的参数还需要调
%              SeV(i).BarFv
            end
        end
        %------从分布情况得到replication set-----------
      for  i=1:length(SeV) % 先找出
         tempRepliset=zeros(1,length(SeV));
         tempRepliset(i)=1;
%          if SeV(i).BarLCv==0
%              temp(i)=AveCompute(SeV,TaV,t,zeros(1,length(SeV)),Queue(2,t), Queue(3,t), Queue(4,t))-AveCompute(SeV,TaV,t,tempRepliset,Queue(2,t), Queue(3,t), Queue(4,t));
%          else
         temp(i)=(AveCompute(SeV,TaV,t,zeros(1,length(SeV)),Queue(2,t), Queue(3,t), Queue(4,t))-AveCompute(SeV,TaV,t,tempRepliset,Queue(2,t), Queue(3,t), Queue(4,t)))/(Queue(1,t)*SeV(i).BarLCv);
%          end
      end
     flagRepliset=zeros(1,length(SeV));
     [value,index]=max(temp); %找到第一个
     flagRepliset(index)=1;
    % ReplisetSingle=flagRepliset;
     for  i=1:length(SeV)
     SeVBarLCv(i)=getfield(SeV(i),'BarLCv');
     end
     k=0;
    while  AveCompute(SeV,TaV,t,Repliset, Queue(2,t), Queue(3,t), Queue(4,t))+( Queue(1,t)*sum(SeVBarLCv.*Repliset))> AveCompute(SeV,TaV,t,flagRepliset,Queue(2,t), Queue(3,t), Queue(4,t))+(Queue(1,t)*sum(SeVBarLCv.*flagRepliset))

        Repliset=flagRepliset; %更新到最好的集合
        for i=1:length(SeV) % 先找出
            tempRepliset=Repliset;
           if tempRepliset(i)==1
              temp(i)=0;
           else
              tempRepliset(i)=1;
              temp(i)=(AveCompute(SeV,TaV,t,Repliset,Queue(2,t), Queue(3,t), Queue(4,t))-AveCompute(SeV,TaV,t,tempRepliset,Queue(2,t), Queue(3,t), Queue(4,t)))/(Queue(1,t)*SeV(i).BarLCv);
           end
        end
     flagRepliset=Repliset;
     [value,index]=max(temp); %找到最大值
     flagRepliset(index)=1;
        %-----display-----------------------------------------------
     %  AveCompute(SeV,TaV,t,Repliset, Queue(2,t), Queue(3,t), Queue(4,t))+( Queue(1,t)*sum(SeVBarLCv.*Repliset))
      % AveCompute(SeV,TaV,t,flagRepliset,Queue(2,t), Queue(3,t), Queue(4,t))+(Queue(1,t)*sum(SeVBarLCv.*flagRepliset))
      %---------------------------------------------------------------------------------
    end
  
   %------------------------收集反馈信息更新均值--------------------
    for  i=1:length(SeV) %%获得各种时延
            if  Repliset(i)==1 % 为选中的SeV计算时延
                SeV(i).play=SeV(i).play+1;         
            
          %----------compute latency=====
         %  [LC, L]=LatencyCompute(TaV, SeV,SINR)
          %-----------更新车的选择次数， 计算时延的均值，总时延的分布----------
           SeV(i).comlatency=LC(i)/Lmax; %归一化后的数值，瞬时值
           SeV(i).latency=L(i)/Lmax;  %归一化后的数值，瞬时值  
           
           SeV(i).LCv= (SeV(i).play-1)/SeV(i).play *SeV(i).LCv+ SeV(i).comlatency/SeV(i).play;
            SeV(i).LCv
           if SeV(i).latency>3
                SeV(i).latency=3;
           end
           for j=1:3*segment
                 if    ( SeV(i).latency<=j/segment)&&(SeV(i).latency>(j-1)/segment)
                       SeV(i).Count(j)=SeV(i).Count(j)+1;
                 end
           end
            for j=1:3*segment
              SeV(i).Fv(j)=sum(SeV(i).Count(1:j))/sum(SeV(i).Count);% CDF
           end
            end
    end
%     if Indicate(SeV,Repliset)==1
%                TaV(t).completion=1;% 1表示未完成
%     end
        
          RecordComplete(t)=Indicate(SeV,Repliset);
    end  
RecordRepliset(t,:)= Repliset;
    
    %-------------------------DATE-V algorithm-------------------------
    
      K=t^(2*alpha/(3*alpha+Dim))*log(t);
       
    if t==1
         ReplisetDATE=ones(1,length(SeV));
         
             for  i=1:length(SeV)
                if  ReplisetDATE(i)==1 % 为选中的SeV计算时延
                   SeV(i).DATE_play=SeV(i).DATE_play+1;
                   SeV(i).DATE_comlatency=LC(i)/Lmax; %归一化后的数值，瞬时值
                  SeV(i).DATE_latency=L(i)/Lmax;  %归一化后的数值，瞬时值  
                   SeV(i).DATE_quality=(SeV(i).DATE_play-1)/SeV(i).DATE_play*SeV(i).DATE_quality+(1-IndicateDate(SeV,ReplisetDATE))/SeV(i).DATE_play;
                 SeVcomlatency(i)=getfield(SeV(i),'DATE_comlatency'); 
                 SeVlatency(i)=getfield(SeV(i),'DATE_latency'); 
               %----------------------------------------
                end
           
             end
              TempSeVlatency=SeVlatency.*ReplisetDATE;
             RecordLatencyDATE(t)=min(TempSeVlatency(TempSeVlatency~=0));
             RecordComLatencyDATE(t)=sum(SeVcomlatency.*ReplisetDATE);     
               RecordCompleteDATE(t)=IndicateDate(SeV,ReplisetDATE);
               RecordReplisetDATE(t,:)=ReplisetDATE;
         
    else
        Repliset= RecordRepliset(t,:);
         ReplisetDATE=zeros(1,length(SeV));
        UnSet=zeros(1,length(SeV));
        for i=1:length(SeV) 
            if SeV(i).DATE_play<= K
                UnSet(i)=1;
            end      
        end
        if sum(UnSet)~=0
            if sum(UnSet)>=length(Repliset(Repliset~=0))
                IndexUnSet=find(UnSet);
                idx = randperm(length(IndexUnSet));
                ReplisetDATE(IndexUnSet(idx(1:length(Repliset(Repliset~=0)))))=1;
            else
                qualityVector=zeros(1,length(SeV));
                 ReplisetDATE=UnSet;
                  for  i=1:length(SeV)
                      if UnSet(i)==0  % 取出不在unset中的SeV
                      qualityVector(i)=SeV(i).DATE_quality;
                      end
                  end
                  [Sort_qualityVector,SI]=sort(qualityVector,'descend');
                  ReplisetDATE(SI(1:(length(Repliset(Repliset~=0))-sum(UnSet))))=1;
                 
                
            end
            
        else
            qualityVector=zeros(1,length(SeV));
             for  i=1:length(SeV)
                 qualityVector(i)=SeV(i).DATE_quality;
             end
             [Sort_qualityVector,SI]=sort(qualityVector,'descend');
             ReplisetDATE(SI(1:length(Repliset(Repliset~=0))))=1;
        end
        
       %%-------------根据选择更新=============================
          for  i=1:length(SeV)
                if  ReplisetDATE(i)==1 % 为选中的SeV计算时延
                   SeV(i).DATE_play=SeV(i).DATE_play+1;
                   SeV(i).DATE_comlatency=LC(i)/Lmax; %归一化后的数值，瞬时值
                  SeV(i).DATE_latency=L(i)/Lmax;  %归一化后的数值，瞬时值  
                   SeV(i).DATE_quality=(SeV(i).DATE_play-1)/SeV(i).DATE_play*SeV(i).DATE_quality+(1-IndicateDate(SeV,ReplisetDATE))/SeV(i).DATE_play;
                 SeVcomlatency(i)=getfield(SeV(i),'DATE_comlatency'); 
                 SeVlatency(i)=getfield(SeV(i),'DATE_latency'); 
               %----------------------------------------
                end
           
             end
             TempSeVlatency=SeVlatency.*ReplisetDATE;
             RecordLatencyDATE(t)=min(TempSeVlatency(TempSeVlatency~=0));
             RecordComLatencyDATE(t)=sum(SeVcomlatency.*ReplisetDATE);
             RecordCompleteDATE(t)=IndicateDate(SeV,ReplisetDATE);
            RecordReplisetDATE(t,:)=ReplisetDATE;
        
        
    end
    
    %-------- %LTR-SUN--------------------------------------   
    
    fistshow=zeros(1,length(SeV)); %重置第一次出现的车辆向量记录
     ReplisetLTR=zeros(1,length(SeV)); %重置复制集合
    %ReplisetSingle=zeros(1,length(SeV)); %重置复制集合
    
    for i=1:length(SeV) %检查是否有第一次出现的车辆
        SeV(i).show=0; %出现次数， Step 1 用这句 
         %SeV(i).show= SeV(i).show+1; %出现次数，Step 2 用这句
         if  SeV(i).show==1
             fistshow(i)=1;
         end
    end
    %-------对于直接生成的情况------------------
    if t==1
    fistshow=ones(1,length(SeV));
    end
    %------------------------------------------
    if any(fistshow) %如果有第一次出现的车辆，就直接选择它
       ReplisetLTR=fistshow;
      % ReplisetSingle=fistshow;
       for  i=1:length(SeV) %%获得各种时延
            if  ReplisetLTR(i)==1 % 为选中的SeV计算时延
                SeV(i).LTR_play=SeV(i).LTR_play+1;
                 SeV(i).LTR_comlatency=LC(i)/Lmax; %归一化后的数值，瞬时值
                 SeV(i).LTR_latency=L(i)/Lmax;  %归一化后的数值，瞬时值  
                 %SeV(i).LTR_LCv= (SeV(i).LTR_play-1)/SeV(i).LTR_play *SeV(i).LCv+ SeV(i).LTR_comlatency/SeV(i).LTR_play;
                 % SeV(i).LTR_LCv
                 %----------------------------------------
                 if SeV(i).LTR_latency>3
                     SeV(i).LTR_latency=3;
                 end
                 for j=1:3*segment
                       if    (SeV(i).LTR_latency>(j-1)/segment)&& ( SeV(i).LTR_latency<=(j)/segment)
                              SeV(i).LTR_Count(j)=SeV(i).LTR_Count(j)+1; 
                       end
                 end
                 for j=1:3*segment
                     SeV(i).LTR_Fv(j)=sum(SeV(i).LTR_Count(1:j))/sum(SeV(i).LTR_Count);% CDF 
                 end
               %SeV(i).Fv
               %----------------------------------------
            end
     end
   %---------------------记录----------------------     
  
    RecordCompleteLTR(t)=IndicateLTR(SeV,ReplisetLTR);
    %---------------------记录----------------------         
            
        %------------没有新出现的车辆-----------  
 else  %更新选择依据
        for  i=1:length(SeV) %
            if  SeV(i).LTR_play==0
                 SeV(i).LTR_BarFv(i,:)=1;
            else
             SeV(i).LTR_BarFv=min( SeV(i).LTR_Fv+sqrt(PD2*log(t- SeV(i).show)./SeV(i).LTR_play),1); %log前面的参数还需要调
            end
        end
        %------从分布情况得到replication set-----------
      for  i=1:length(SeV) % 先找出
         tempRepliset=zeros(1,length(SeV));
         tempRepliset(i)=1;
%          if SeV(i).BarLCv==0
%              temp(i)=AveCompute(SeV,TaV,t,zeros(1,length(SeV)),Queue(2,t), Queue(3,t), Queue(4,t))-AveCompute(SeV,TaV,t,tempRepliset,Queue(2,t), Queue(3,t), Queue(4,t));
%          else
         temp(i)=AveComputeLTR(SeV,TaV,t,tempRepliset);
%          end
      end
     flagRepliset=zeros(1,length(SeV));
     [value,index]=min(temp(temp~=0)); %找到第一个
     flagRepliset(index)=1;
    % ReplisetSingle=flagRepliset;
     k=0;
     Repliset= RecordRepliset(t,:);
    while  AveComputeLTR(SeV,TaV,t,ReplisetLTR)> AveComputeLTR(SeV,TaV,t,flagRepliset)&& sum(ReplisetLTR)<sum(Repliset)

        ReplisetLTR=flagRepliset; %更新到最好的集合
        for i=1:length(SeV) % 先找出
            tempRepliset=ReplisetLTR;
           if tempRepliset(i)==1
              temp(i)=0;
           else
              tempRepliset(i)=1;
%               temp(i)=AveComputeLTR(SeV,TaV,t,ReplisetLTR)-AveComputeLTR(SeV,TaV,t,tempRepliset );
                temp(i)=AveComputeLTR(SeV,TaV,t,tempRepliset );
           end
        end
     flagRepliset=ReplisetLTR;
     [value,index]=min(temp(temp~=0)); %找到最大值
     flagRepliset(index)=1;
        %-----display-----------------------------------------------
     %  AveCompute(SeV,TaV,t,ReplisetLTR, Queue(2,t), Queue(3,t), Queue(4,t))+( Queue(1,t)*sum(SeVBarLCv.*ReplisetLTR))
      % AveCompute(SeV,TaV,t,flagRepliset,Queue(2,t), Queue(3,t), Queue(4,t))+(Queue(1,t)*sum(SeVBarLCv.*flagRepliset))
      %---------------------------------------------------------------------------------
    end
  
   %------------------------收集反馈信息更新均值--------------------
    for  i=1:length(SeV) %%获得各种时延
            if  ReplisetLTR(i)==1 % 为选中的SeV计算时延
                SeV(i).LTR_play=SeV(i).LTR_play+1;         
            
          %----------compute latency=====
         %  [LC, L]=LatencyCompute(TaV, SeV,SINR)
          %-----------更新车的选择次数， 计算时延的均值，总时延的分布----------
           SeV(i).LTR_comlatency=LC(i)/Lmax; %归一化后的数值，瞬时值
           SeV(i).LTR_latency=L(i)/Lmax;  %归一化后的数值，瞬时值 
           if SeV(i).LTR_latency>3
                SeV(i).LTR_latency=3;
           end
           for j=1:3*segment
                 if    ( SeV(i).LTR_latency<=j/segment)&&(SeV(i).LTR_latency>(j-1)/segment)
                       SeV(i).LTR_Count(j)=SeV(i).LTR_Count(j)+1;
                 end
           end
            for j=1:3*segment
              SeV(i).LTR_Fv(j)=sum(SeV(i).LTR_Count(1:j))/sum(SeV(i).LTR_Count);% CDF
           end
            end
    end
  
        RecordCompleteLTR(t)=IndicateLTR(SeV,ReplisetLTR);
    end  
     RecordReplisetLTR(t,:)= ReplisetLTR;
     
            for i=1:length(SeV)
             SeVcomlatency(i)=getfield(SeV(i),'LTR_comlatency'); 
            SeVlatency(i)=getfield(SeV(i),'LTR_latency'); 
            end     
            RecordLatencyLTR(t)=min(TempSeVlatency(TempSeVlatency~=0));
             RecordComLatencyLTR(t)=sum(SeVcomlatency.*ReplisetLTR);
    %---------------Single Offloading------------------
   %-------------------更新队列长度---------------------
       if t==1  
          SingleQueue(1,t)=0;
          SingleQueue(2,t)=0;
          SingleQueue(3,t)=0;
          SingleQueue(4,t)=0;
        else
            for i=1:length(SeV)
             SeVcomlatency(i)=getfield(SeV(i),'Single_comlatency'); 
            SeVlatency(i)=getfield(SeV(i),'Single_latency'); 
            end
         TempSeVlatency=SeVlatency.* ReplisetSingle;
         SingleQueue(1,t)=SingleQueue(1,t-1)+max(sum(SeVcomlatency.* ReplisetSingle)-budget,0);
         SingleQueue(2,t)=SingleQueue(2,t-1)+max(IndicateSingle(SeV, ReplisetSingle)-ipslon,0);
         SingleQueue(3,t)=SingleQueue(3,t-1)+max((min(TempSeVlatency(TempSeVlatency~=0))-1-sigma/(1-xi))*IndicateSingle(SeV, ReplisetSingle),0);
        % SingleQueue(3,t)=SingleQueue(3,t-1)+(min(TempSeVlatency(TempSeVlatency~=0))-1-sigma/(1-xi))*Indicate(SeV,Repliset);
         SingleQueue(4,t)=SingleQueue(4,t-1)+max(((min(TempSeVlatency(TempSeVlatency~=0))-1)^2-2*sigma^2/(1-xi)/(1-2*xi))*IndicateSingle(SeV, ReplisetSingle),0);
        % SingleQueue(4,t)=Queue(4,t-1)+(( min(TempSeVlatency(TempSeVlatency~=0))-1)^2-2*sigma/(1-xi)/(1-2*xi))*Indicate(SeV,Repliset),0;
         %----------------------------------------------------------------------------------------------------------------------------  
        %记录----------------------------------------
             RecordLatencySingle(t-1)=min(TempSeVlatency(TempSeVlatency~=0));
             RecordComLatencySingle(t-1)=sum(SeVcomlatency.*ReplisetSingle);
        %记录----------------------------------------
       end
      fistshow=zeros(1,length(SeV)); %重置第一次出现的车辆向量记录
     %Repliset=zeros(1,length(SeV)); %重置复制集合
    ReplisetSingle=zeros(1,length(SeV)); %重置复制集合
    
    for i=1:length(SeV) %检查是否有第一次出现的车辆
        SeV(i).show=0; %出现次数， Step 1 用这句
         %SeV(i).show= SeV(i).show+1; %出现次数，Step 2 用这句
         if  SeV(i).show==1
             fistshow(i)=1;
         end
    end
    %-------对于直接生成的情况------------------
    if t==1
    fistshow=ones(1,length(SeV));
    end
    %------------------------------------------
    
    if any(fistshow) %如果有第一次出现的车辆，就直接选择它
       ReplisetSingle=fistshow;
      % ReplisetSingle=fistshow;
       for  i=1:length(SeV) %%获得各种时延
            
            if  ReplisetSingle(i)==1 % 为选中的SeV计算时延
                SeV(i).Single_play=SeV(i).Single_play+1;
                  SeV(i).Single_comlatency=LC(i)/Lmax; %归一化后的数值，瞬时值
                  SeV(i).Single_latency=L(i)/Lmax;  %归一化后的数值，瞬时值                    
                %-----------更新车的选择次数， 计算时延的均值，总时延的分布----------
                
                 SeV(i).Single_LCv= (SeV(i).Single_play-1)/SeV(i).Single_play *SeV(i).Single_LCv+ SeV(i).Single_comlatency/SeV(i).Single_play;
                 % SeV(i).LCv
                 %----------------------------------------
                 if SeV(i).Single_latency>3
                     SeV(i).Single_latency=3;
                 end
                 for j=1:3*segment
                       if    (SeV(i).Single_latency>(j-1)/segment)&& ( SeV(i).Single_latency<=(j)/segment)
                              SeV(i).Single_Count(j)=SeV(i).Single_Count(j)+1; 
                       end
                 end
                 for j=1:3*segment
                     SeV(i).Single_Fv(j)=sum(SeV(i).Single_Count(1:j))/sum(SeV(i).Single_Count);% CDF 
                 end
               %SeV(i).Fv
               %----------------------------------------
            end
     end
   %---------------------记录----------------------     
    if IndicateSingle(SeV,ReplisetSingle)==1
       TaV(t).Single_completion=1;% 1表示未完成
    end
    RecordCompleteSingle(t)=TaV(t).Single_completion;
    %---------------------记录----------------------         
            
        %------------没有新出现的车辆-----------   
     else  %更新选择依据
        for  i=1:length(SeV) %
            if  SeV(i).Single_play==0
                 SeV(i).Single_BarLCv(i)=0;
                 SeV(i).Single_BarFv(i,:)=1;
            else
             SeV(i).Single_BarLCv=max(SeV(i).Single_LCv-sqrt(PD1*log(t- SeV(i).show)./SeV(i).Single_play),0); %log前面的参数还需要调
%              SeV(i).Single_BarLCv
             SeV(i).Single_BarFv=min( SeV(i).Single_Fv+sqrt(PD2*log(t- SeV(i).show)./SeV(i).Single_play),1); %log前面的参数还需要调
%              SeV(i).Single_BarFv
            end
        end
        %------从分布情况得到replication set-----------
      for  i=1:length(SeV) % 先找出
         tempRepliset=zeros(1,length(SeV));
         tempRepliset(i)=1;
%          if SeV(i).BarLCv==0
%              temp(i)=AveCompute(SeV,TaV,t,zeros(1,length(SeV)),Queue(2,t), Queue(3,t), Queue(4,t))-AveCompute(SeV,TaV,t,tempRepliset,Queue(2,t), Queue(3,t), Queue(4,t));
%          else
        %temp(i)=(AveComputeSingle(SeV,TaV,t,zeros(1,length(SeV)),SingleQueue(2,t), SingleQueue(3,t), SingleQueue(4,t))-AveComputeSingle(SeV,TaV,t,tempRepliset,SingleQueue(2,t), SingleQueue(3,t), SingleQueue(4,t)))/(SingleQueue(1,t)*SeV(i).Single_BarLCv);
          temp(i)=AveComputeSingle(SeV,TaV,t,tempRepliset,SingleQueue(2,t), SingleQueue(3,t), SingleQueue(4,t))+(SingleQueue(1,t)*SeV(i).Single_BarLCv);
%          end
      end
     flagRepliset=zeros(1,length(SeV));
    %[value,index]=max(temp); %找到第一个
       [value,index]=min(temp); %找到第一个
     flagRepliset(index)=1;
 ReplisetSingle=flagRepliset;
     for  i=1:length(SeV)
     SeVBarLCv(i)=getfield(SeV(i),'Single_BarLCv');
     end
     k=0;
   %------------------------收集反馈信息更新均值--------------------
    for  i=1:length(SeV) %%获得各种时延
            if  ReplisetSingle(i)==1 % 为选中的SeV计算时延
                SeV(i).Single_play=SeV(i).Single_play+1;         
            
          %----------compute latency=====
         %  [LC, L]=LatencyCompute(TaV, SeV,SINR)
          %-----------更新车的选择次数， 计算时延的均值，总时延的分布----------
           SeV(i).Single_comlatency=LC(i)/Lmax; %归一化后的数值，瞬时值
           SeV(i).Single_latency=L(i)/Lmax;  %归一化后的数值，瞬时值  
           
           SeV(i).Single_LCv= (SeV(i).Single_play-1)/SeV(i).Single_play *SeV(i).Single_LCv+ SeV(i).Single_comlatency/SeV(i).Single_play;
            SeV(i).LCv
                 if SeV(i).Single_latency>3
                     SeV(i).Single_latency=3;
                 end
                 for j=1:3*segment
                       if    (SeV(i).Single_latency>(j-1)/segment)&& ( SeV(i).Single_latency<=(j)/segment)
                              SeV(i).Single_Count(j)=SeV(i).Single_Count(j)+1; 
                       end
                 end
                 for j=1:3*segment
                     SeV(i).Single_Fv(j)=sum(SeV(i).Single_Count(1:j))/sum(SeV(i).Single_Count);% CDF 
                 end
            end
     end 
    if IndicateSingle(SeV,ReplisetSingle)==1
               TaV(t).Single_completion=1;% 1表示未完成
    end
 end
RecordReplisetSingle(t,:)= ReplisetSingle;
RecordCompleteSingle(t)=TaV(t).Single_completion;  
    
    
end

for t=1:T
    %-------------------Random Algorithm-----------------------------
ReplisetRandom=zeros(1,length(SeV));
R=randperm(length(SeV));
Repliset= RecordRepliset(t,:);
index_R= R(1:length(Repliset(Repliset~=0)));
% index_R= R(1);
ReplisetRandom([index_R])=1;
RecordReplisetRandom(t,:)=ReplisetRandom;

 L=zeros(1,length(SeV));
  for i=1:length(SeV)
  L(i)=RecordL(i,t);
  end

tempr=L.*ReplisetRandom;
  [RecordLatencyRandom(t)]= min(tempr(tempr~=0))/Lmax;
  LC=zeros(1,length(SeV));
  for i=1:length(SeV)
  LC(i)=RecordLC(i,t);
  end
   RecordComLatencyRandom(t)=sum(LC.*ReplisetRandom/Lmax);
      if RecordLatencyRandom(t)>1  
         RecordCompleteRandom(t)=1; 
      end   
end
%--------------------------global best arms------------------------------
for i=1:length(SeV)
    aveL(i)=sum(RecordL(i,:))/(T*Lmax); 
end
[VectorL,index]=sort(aveL);

RecordReplisetOracle=zeros(T,length(SeV));
for t=1:T
   Repliset= RecordRepliset(t,:);
  RecordReplisetOracle(t,[index(1:length(Repliset(Repliset~=0)))])=1;
 
 RecordLatencyOracle(t)=min(RecordL([index(1:length(Repliset(Repliset~=0)))],t))/Lmax;
 
   
   RecordComLatencyOracle(t)=sum (RecordLC([index(1:length(Repliset(Repliset~=0)))],t))/Lmax;
    if RecordLatencyOracle(t)>1  
         RecordCompleteOracle(t)=1; 
    else
         RecordCompleteOracle(t)=0; 
    end   
end


 RecordRegretSingle=zeros(1,T);
 RecordRegretRandom=zeros(1,T);
 RecordRegret=zeros(1,T);
 RecordRegretDATE=zeros(1,T);
 RecordRegretLTR=zeros(1,T);
 
 for t=1:T
    Repliset= RecordRepliset(t,:);
    tem1=aveL.*Repliset;
    RecordRegret(t)= min(tem1(tem1~=0))-VectorL(1);
 % RecordRegret(t)=RecordLatency(t)-min(RecordL(:,t))/Lmax;
%      RecordRegret(t)= min(tem1(tem1~=0))-min(VectorL(1:length(Repliset(Repliset~=0))));
%  RecordRegret(t)= RecordLatency(t)-min(VectorL(1:length(Repliset(Repliset~=0))));
    %sumRegret(t)=sum(RecordRegret(1:t))/Lmax;
    

     ReplisetDATE= RecordReplisetDATE(t,:);
    tem1=aveL.*ReplisetDATE;
%   RecordRegretDelayOptimal(t)= min(tem1(tem1~=0))-min(VectorL(1:length(ReplisetDelayOptimal(ReplisetDelayOptimal~=0))));
%   RecordRegretDelayOptimal(t)= RecordLatencyDelayOptimal(t)-min(VectorL(1:length(ReplisetDelayOptimal(ReplisetDelayOptimal~=0))));
%   RecordRegretDelayOptimal(t)= min(tem1(tem1~=0))-min(VectorL(1:length(Repliset(Repliset~=0))));
%RecordRegretDATE(t)=RecordLatencyDATE(t)-min(RecordL(:,t))/Lmax;
RecordRegretDATE(t)= min(tem1(tem1~=0))-VectorL(1);

%      
%      ReplisetReliability= RecordReplisetReliability(t,:);
%     tem1=aveL.*ReplisetReliability;
%     RecordRegretReliability(t)= min(tem1(tem1~=0))-min(VectorL(1:length(ReplisetReliability(ReplisetReliability~=0))));
%  

    ReplisetLTR= RecordReplisetLTR(t,:);
    tem1=aveL.*ReplisetLTR;
 RecordRegretLTR(t)= min(tem1(tem1~=0))-VectorL(1);
%RecordRegretLTR(t)=RecordLatencyLTR(t)-min(RecordL(:,t))/Lmax;


 ReplisetRandom= RecordReplisetRandom(t,:);
   tem1=aveL.* ReplisetRandom;
     RecordRegretRandom(t)= min(tem1(tem1~=0))-VectorL(1);
    
    ReplisetSingle= RecordReplisetSingle(t,:);
    tem1=aveL.*ReplisetSingle;
     RecordRegretSingle(t)= min(tem1(tem1~=0))-VectorL(1);
 end
 
end


