function [yes]=IndicateDate(SeV,Repliset)
for i=1:length(SeV)
SeVlatency(i)=getfield(SeV(i),'DATE_latency'); 
end
 TempSeVlatency=SeVlatency.*Repliset;
Lmin=min(TempSeVlatency(TempSeVlatency~=0));
if Lmin>1
    yes=1;
else
    yes=0;
end