function SeV=GnerateSeV0(t)
global T; % 总的任务数
global DistRSU; % RSU之间的距离
global RateR2S; % RSU 到 SeV 的数据速率
global RateBackhaul; % RSU 到 RSU 的数据速率
global BandWidth; %  车 到 RSU 带宽
global TransPower; % 车到 RSU 链路上的发射功率
global N0; % 信道噪声
global segment;% CDF离散化的总个数
NumSeV=10; % SeV 的种类数
fileID = fopen('taxi_sequence.txt','r');
C = textscan(fileID,'%s %D %f %f %d %d %d','Delimiter',',');
fclose(fileID);
id=C{1,1};
time=C{1,2};
lat=C{1,3};
lon=C{1,4};
sp=C{1,5};
ang=C{1,6};
rl=C{1,7};
for i=1:NumSeV
    SeV(i).ID=id((t-1).*11+i+1); %编号
    SeV(i).role=rl((t-1).*11+i+1); %身份 任务车辆还是空闲车辆
    SeV(i).speed=sp((t-1).*11+i+1); %速度
    SeV(i).RSU1=0; %任务分配的位置即关联的RSU
    SeV(i).RSU2=0; %任务完成的位置即关联的RSU
    SeV(i).direction=1; %行驶方向{1,-1}
    SeV(i).idleCPU=0; %计算能力
    SeV(i).show=0; %出现次数
    SeV(i).play=0; %选过的次数
    
    SeV(i).Oracle_latency=0; %最优情况
    SeV(i).Oracle_comlatency=0; %最优情况
    SeV(i).Oracle_LCv=0; %预测的计算时延均值  
     SeV(i).Oracle_Count=zeros(1,3*segment);%频次
    SeV(i).Oracle_Fv=zeros(1,3*segment); %预测的累计密度分布函数，离散化之后的,存出现的次数 
    
    SeV(i).Single_play=0;
     SeV(i).Single_latency=0; %对比算法，不复制
    SeV(i).Single_comlatency=0;%对比算法，不复制
    SeV(i).Single_Count=zeros(1,3*segment);%频次
    SeV(i).Single_Fv=zeros(1,3*segment); %预测的累计密度分布函数，离散化之后的,存出现的次数
    SeV(i).Single_BarFv=zeros(1,3*segment); %修正后的累计密度分布函数
    SeV(i).Single_LCv=0; %预测的计算时延均值  
    SeV(i).Single_BarLCv=0; %修正后的计算时延
    
     SeV(i).DelayOptimal_play=0;
    SeV(i).DelayOtimal_latency=0; %对比算法，不考虑可靠性
    SeV(i).DelayOtimal_comlatency=0; %对比算法，不考虑可靠性
   SeV(i).DelayOptimal_Count=zeros(1,3*segment);%频次
    SeV(i).DelayOtimal_Fv=zeros(1,3*segment); %预测的累计密度分布函数，离散化之后的,存出现的次数
    SeV(i).DelayOtimal_BarFv=zeros(1,3*segment); %修正后的累计密度分布函数 
    SeV(i).DelayOtimal_LCv=0; %预测的计算时延均值  
    SeV(i).DelayOtimal_BarLCv=0; %修正后的计算时延
    
     SeV(i).LTR_play=0;
    SeV(i).LTR_latency=0; %对比算法，不考虑可靠性
    SeV(i).LTR_comlatency=0; %对比算法，不考虑可靠性
   SeV(i).LTR_Count=zeros(1,3*segment);%频次
    SeV(i).LTR_Fv=zeros(1,3*segment); %预测的累计密度分布函数，离散化之后的,存出现的次数
    SeV(i).LTR_BarFv=zeros(1,3*segment); %修正后的累计密度分布函数 
  
    
    
     SeV(i).Reliability_play=0;
    SeV(i).Reliability_latency=0; %对比算法，不考虑可靠性
    SeV(i).Reliability_comlatency=0; %对比算法，不考虑可靠性
    SeV(i).Reliability_Count=zeros(1,3*segment);%频次
    SeV(i).Reliability_Fv=zeros(1,3*segment); %预测的累计密度分布函数，离散化之后的,存出现的次数
    SeV(i).Reliability_BarFv=zeros(1,3*segment); %修正后的累计密度分布函数 
    SeV(i).Reliability_LCv=0; %预测的计算时延均值  
    SeV(i).Reliability_BarLCv=0; %修正后的计算时延
    
    SeV(i).DATE_play=0;
    SeV(i).DATE_latency=0; %对比算法，DATE
    SeV(i).DATE_comlatency=0; %对比算法，DATE
   SeV(i).DATE_quality=0; %对比算法，DATE
    
%     SeV(i).Reliability_Fv=zeros(1,3*segment); %预测的累计密度分布函数，离散化之后的,存出现的次数
%     SeV(i).Reliability_BarFv=zeros(1,3*segment); %修正后的累计密度分布函数 
%     SeV(i).Reliability_LCv=0; %预测的计算时延均值  
%     SeV(i).Reliability_BarLCv=0; %修正后的计算时延
    
    SeV(i).Rand_latency=0; %对比算法，随机复制
    SeV(i).Rand_comlatency=0; %对比算法，随机复制
  
    SeV(i).latency=0; %真实值，整体时延对于每个任务需要根据时延建模的部分计算出来，第一步
    SeV(i).comlatency=0; %真实值，计算时延，对于每个任务需要根据时延建模的部分计算出来
   SeV(i).Count=zeros(1,3*segment);%频次
    SeV(i).Fv=zeros(1,3*segment); %预测的累计密度分布函数，离散化之后的,存出现的次数
    SeV(i).BarFv=zeros(1,3*segment); %修正后的累计密度分布函数
    
    SeV(i).LCv=0; %预测的计算时延均值  
    SeV(i).BarLCv=0; %修正后的计算时延
end