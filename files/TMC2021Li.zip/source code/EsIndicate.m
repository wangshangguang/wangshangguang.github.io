function [yes]=EsIndicate(SeV,Repliset)
for i=1:length(SeV)
SeVlatency(i)=getfield(SeV(i),'BarFv'); 
end
Lmin=min(SeVlatency.*Repliset(SeVlatency.*Repliset~=0));
if Lmin>1
    yes=1;
else
    yes=0;
end