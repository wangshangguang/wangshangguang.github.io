function [yes]=IndicateLTR(SeV,Repliset)
for i=1:length(SeV)
SeVlatency(i)=getfield(SeV(i),'LTR_latency'); 
end
 TempSeVlatency=SeVlatency.*Repliset;
Lmin=min(TempSeVlatency(TempSeVlatency~=0));
if Lmin>1
    yes=1;
else
    yes=0;
end