package AEFRCov;

class Qosparameter implements Comparable<Qosparameter> {
	private int lineNumber;
	private double averageres;
	private double averageprice;
	private double covres;
	private double covprice;
	private double cov;
	
	public Qosparameter(int lineNumber, double averageres, double averageprice,
			double covres, double covprice, double cov) {
		super();
		this.lineNumber = lineNumber;
		this.averageres = averageres;
		this.averageprice = averageprice;
		this.covres = covres;
		this.covprice = covprice;
		this.cov = cov;
	}

	public Qosparameter() {
		// TODO Auto-generated constructor stub
	}

	public int getLineNumber() {
		return lineNumber;
	}
	public void setLineNumber(int lineNumber) {
		this.lineNumber = lineNumber;
	}
	public double getAverageres() {
		return averageres;
	}

	public void setAverageres(double averageres) {
		this.averageres = averageres;
	}
	public double getAverageprice() {
		return averageprice;
	}
	public void setAverageprice(double averageprice) {
		this.averageprice = averageprice;
	}
	public double getCovres() {
		return covres;
	}
	public void setCovres(double covres) {
		this.covres = covres;
	}
	public double getCovprice() {
		return covprice;
	}
	public void setCovprice(double covprice) {
		this.covprice = covprice;
	}
	public double getCov() {
		return cov;
	}
	public void setCov(double cov) {
		this.cov = cov;
	}

	@Override
	public int compareTo(Qosparameter qosparameter) {
		// TODO Auto-generated method stub
		if (this.getCov() > qosparameter.getCov()) {
			return 1;
		} else if (this.getCov() < qosparameter
				.getCov()) {
			return -1;
		} else {
			return 0;
		}
	}

}