package GlobalCoV;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class GlobalCoV {

	public static final int serviceclass = 10;// ���������
	public static final int servicehistoricalcounts = 500;// ����ȫ�ֳ�������ʾһ���������з���ĸ���
	public static final int servicecandidates = 1000;// һ���������������

	public static final float coefficientavariation = 0.5f;
	public static final float wres = 0.5f;
	public static final float wprice = 0.5f;

	public static void main(String[] agrs) {

		try {

			File fileres = new File(
					"./data/dataselectRandom/data1000/datares1000/");
			File filesres[] = fileres.listFiles();
			File fileprice = new File(
					"./data/dataselectRandom/data1000/dataprice1000/");
			File filesprice[] = fileprice.listFiles();

			for (int i = 0; i < filesres.length; i++) {

				System.out.println(filesres[i]);
				System.out.println(filesprice[i]);

				Data_process data_process = new Data_process();

				BufferedReader readerres = new BufferedReader(new FileReader(
						filesres[i]));
				BufferedReader readerprice = new BufferedReader(new FileReader(
						filesprice[i]));
				data_process.serviceDataProcess(readerres, readerprice);

				FileWriter writerres = new FileWriter(
						"./data/dataselectRandom/data1000/outputres.txt", true);
				FileWriter writerprice = new FileWriter(
						"./data/dataselectRandom/data1000/outputprice.txt",
						true);
				FileWriter writercovres = new FileWriter(
						"./data/dataselectRandom/data1000/outputcovres.txt",
						true);// ׷��ģʽ,���з��������
				FileWriter writercovprice = new FileWriter(
						"./data/dataselectRandom/data1000/outputcovprice.txt",
						true);// ׷��ģʽ,���з��������

				data_process.dataOperate(writerres, writerprice, writercovres,
						writercovprice);

			}

			// ����Matalab��ʽ
			BufferedReader readerres = new BufferedReader(new FileReader(
					"./data/dataselectRandom/data1000/outputres.txt"));
			BufferedReader readerprice = new BufferedReader(new FileReader(
					"./data/dataselectRandom/data1000/outputprice.txt"));

			BufferedReader readercovres = new BufferedReader(
					new FileReader(
							"./data/dataselectRandom/data1000/outputcovres.txt"));
			BufferedReader readercovprice = new BufferedReader(
					new FileReader(
							"./data/dataselectRandom/data1000/outputcovprice.txt"));

			FileWriter writerComputeTime = new FileWriter(
					"./data/dataselectRandom/data1000/Computetime.txt");
			FileWriter writerUtiltityValue = new FileWriter(
					"./data/dataselectRandom/data1000/ComputeUtilityValue.txt");

			FileWriter writer_const = new FileWriter(
					"./data/dataselectRandom/const.txt", true);

			FormatMatlab formatMatlab = new FormatMatlab();

			formatMatlab.formatMatlabBySelected(readerres, readerprice,
					readercovres, readercovprice, writerComputeTime,
					writerUtiltityValue, writer_const);

			System.out.println("finish!");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
