package GlobalCoV;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;

public class FormatMatlab {

	public static float wres = GlobalCoV.wres;
	public static float wprice = GlobalCoV.wprice;

	public static float aggregationmaxres = (float) Data_process.aggregationmaxres;// �ۺ������Ӧʱ��,���
	public static float aggregationminres = (float) Data_process.aggregationminres;

	public static float aggregationmaxprice = (float) Data_process.aggregationmaxprice;// �ۺ����������,����Сֵ(n����������С�����ֵ)
	public static float aggregationminprice = (float) Data_process.aggregationminprice;// �ۺ���С������,����Сֵ(n����������С����Сֵ)

	private float constraintsumres = (float) (Data_process.constraintsumres); // ��Ӧʱ��Լ��,����������ƽ����Ӧʱ������ֵ
	private float constraintsumprice = (float) (Data_process.constraintsumprice);// ������Լ��,����������ƽ������������Сֵ

	public static double Constantcoefficients;// ��ϵ��

	// �����������Ϊ10ʱ
	public void outputaeq10(int N, int M, int count, FileWriter writer) {
		try {
			// ��ӡaeq ��ʽԼ��,��1����
			count = 0;
			int i, j;
			for (i = 0; i < N; i++) {
				for (j = 0; j < M; j++) {
					if (i == 0) {
						if (count == 0) {
							writer.write("aeq = [" + "1" + " ");
							count++;
						} else {
							writer.write("1" + " ");
							count++;
						}
					} else {
						if (count == N * M - 1) {
							writer.write("0" + ";");
						} else {
							writer.write("0" + " ");
							count++;
						}
					}
				}
			}

			// ��ӡaeq ��ʽԼ��,��2����
			count = 0;
			for (i = 0; i < N; i++) {
				for (j = 0; j < M; j++) {
					if (i == 1) {
						writer.write("1" + " ");
						count++;
					} else {
						if (count == N * M - 1) {
							writer.write("0" + ";");
						} else {
							writer.write("0" + " ");
							count++;
						}
					}
				}
			}
			// ��ӡaeq ��ʽԼ��,��3����
			count = 0;
			for (i = 0; i < N; i++) {
				for (j = 0; j < M; j++) {
					if (i == 2) {
						writer.write("1" + " ");
						count++;
					} else {
						if (count == N * M - 1) {
							writer.write("0" + ";");
						} else {
							writer.write("0" + " ");
							count++;
						}
					}
				}
			}
			// ��ӡaeq ��ʽԼ��,��4����
			count = 0;
			for (i = 0; i < N; i++) {
				for (j = 0; j < M; j++) {
					if (i == 3) {
						writer.write("1" + " ");
						count++;
					} else {
						if (count == N * M - 1) {
							writer.write("0" + ";");
						} else {
							writer.write("0" + " ");
							count++;
						}
					}
				}
			}
			// ��ӡaeq ��ʽԼ��,��5����
			count = 0;
			for (i = 0; i < N; i++) {
				for (j = 0; j < M; j++) {
					if (i == 4) {
						writer.write("1" + " ");
						count++;
					} else {
						if (count == N * M - 1) {
							writer.write("0" + ";");
						} else {
							writer.write("0" + " ");
							count++;
						}
					}
				}
			}
			// ��ӡaeq ��ʽԼ��,��6����
			count = 0;
			for (i = 0; i < N; i++) {
				for (j = 0; j < M; j++) {
					if (i == 5) {
						writer.write("1" + " ");
						count++;
					} else {
						if (count == N * M - 1) {
							writer.write("0" + ";");
						} else {
							writer.write("0" + " ");
							count++;
						}
					}
				}
			}
			// ��ӡaeq ��ʽԼ��,��7����
			count = 0;
			for (i = 0; i < N; i++) {
				for (j = 0; j < M; j++) {
					if (i == 6) {
						writer.write("1" + " ");
						count++;
					} else {
						if (count == N * M - 1) {
							writer.write("0" + ";");
						} else {
							writer.write("0" + " ");
							count++;
						}
					}
				}
			}

			// ��ӡaeq ��ʽԼ��,��8����
			count = 0;
			for (i = 0; i < N; i++) {
				for (j = 0; j < M; j++) {
					if (i == 7) {
						writer.write("1" + " ");
						count++;
					} else {
						if (count == N * M - 1) {
							writer.write("0" + ";");
						} else {
							writer.write("0" + " ");
							count++;
						}
					}
				}
			}
			// ��ӡaeq ��ʽԼ��,��9����
			count = 0;
			for (i = 0; i < N; i++) {
				for (j = 0; j < M; j++) {
					if (i == 8) {
						writer.write("1" + " ");
						count++;
					} else {
						if (count == N * M - 1) {
							writer.write("0" + ";");
						} else {
							writer.write("0" + " ");
							count++;
						}
					}
				}
			}

			// ��ӡaeq ��ʽԼ��,��10����
			count = 0;
			for (i = 0; i < N; i++) {
				for (j = 0; j < M; j++) {
					if (i == 9) {
						if (count == N * M - 1) {
							writer.write("1" + "];");
						} else {
							writer.write("1" + " ");
							count++;
						}
					} else {
						writer.write("0" + " ");
						count++;
					}
				}
			}

			writer.write("\n");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void outputaeq5(int N, int M, int count, FileWriter writer) {
		try {
			// ��ӡaeq ��ʽԼ��,��1����
			count = 0;
			int i, j;
			for (i = 0; i < N; i++) {
				for (j = 0; j < M; j++) {
					if (i == 0) {
						if (count == 0) {
							writer.write("aeq = [" + "1" + " ");
							count++;
						} else {
							writer.write("1" + " ");
							count++;
						}
					} else {
						if (count == N * M - 1) {
							writer.write("0" + ";");
						} else {
							writer.write("0" + " ");
							count++;
						}
					}
				}
			}

			// ��ӡaeq ��ʽԼ��,��2����
			count = 0;
			for (i = 0; i < N; i++) {
				for (j = 0; j < M; j++) {
					if (i == 1) {
						writer.write("1" + " ");
						count++;
					} else {
						if (count == N * M - 1) {
							writer.write("0" + ";");
						} else {
							writer.write("0" + " ");
							count++;
						}
					}
				}
			}
			// ��ӡaeq ��ʽԼ��,��3����
			count = 0;
			for (i = 0; i < N; i++) {
				for (j = 0; j < M; j++) {
					if (i == 2) {
						writer.write("1" + " ");
						count++;
					} else {
						if (count == N * M - 1) {
							writer.write("0" + ";");
						} else {
							writer.write("0" + " ");
							count++;
						}
					}
				}
			}
			// ��ӡaeq ��ʽԼ��,��4����
			count = 0;
			for (i = 0; i < N; i++) {
				for (j = 0; j < M; j++) {
					if (i == 3) {
						writer.write("1" + " ");
						count++;
					} else {
						if (count == N * M - 1) {
							writer.write("0" + ";");
						} else {
							writer.write("0" + " ");
							count++;
						}
					}
				}
			}

			// ��ӡaeq ��ʽԼ��,��5����
			count = 0;
			for (i = 0; i < N; i++) {
				for (j = 0; j < M; j++) {
					if (i == 4) {
						if (count == N * M - 1) {
							writer.write("1" + "];");
						} else {
							writer.write("1" + " ");
							count++;
						}
					} else {
						writer.write("0" + " ");
						count++;
					}
				}
			}

			writer.write("\n");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void formatMatlabBySelected(BufferedReader readerres,
			BufferedReader readerprice, BufferedReader readercovres,
			BufferedReader readercovprice, FileWriter writerComputeTime,
			FileWriter writerUtiltityValue, FileWriter writer_const) {

		try {
			final int N = GlobalCoV.serviceclass, M = (int) (GlobalCoV.servicecandidates * GlobalCoV.coefficientavariation);// �������ÿ��������ĺ�ѡ����
			// �����ݴ����������
			float serviceres[][] = new float[N][M];
			float serviceprice[][] = new float[N][M];
			float servicecovres[][] = new float[N][M];
			float servicecovprice[][] = new float[N][M];

			int i = 0, j = 0;// i��ʾ�����࣬j��ʾÿ������������ĺ�ѡ����

			float currentres, currentprice;

			int count = 0;
			String string = null;
			String[] str = new String[M];

			// ����ʼֵ

			while ((string = readerres.readLine()) != null) {
				str = string.split(" ");
				for (j = 0; j < M; j++) {
					currentres = Float.parseFloat(str[j]);
					serviceres[i][j] = currentres;// Ϊ����Լ������C�ģ�Լ���������ƽ��ֵ
				}
				i++;// ������+1
			}

			i = 0;// ������������¹�Ϊ0
			while ((string = readerprice.readLine()) != null) {
				str = string.split(" ");
				for (j = 0; j < M; j++) {
					currentprice = Float.parseFloat(str[j]);
					serviceprice[i][j] = currentprice;// Ϊ����Լ������C�ģ�Լ���������ƽ��ֵ
				}
				i++;// ������+1
			}

			i = 0;// ������������¹�Ϊ0
			while ((string = readercovres.readLine()) != null) {
				str = string.split(" ");
				for (j = 0; j < M; j++) {
					servicecovres[i][j] = Float.parseFloat(str[j]);
				}
				i++;// ������+1
				j = 0;// j���¼���

			}

			i = 0;// ������������¹�Ϊ0
			while ((string = readercovprice.readLine()) != null) {
				str = string.split(" ");
				for (j = 0; j < M; j++) {
					servicecovprice[i][j] = Float.parseFloat(str[j]);
				}
				i++;// ������+1
				j = 0;// j���¼���
			}

			DecimalFormat formateFormat = new DecimalFormat("0.000000");
			aggregationmaxres = Float.parseFloat(formateFormat
					.format(aggregationmaxres));
			aggregationminres = Float.parseFloat(formateFormat
					.format(aggregationminres));
			aggregationmaxprice = Float.parseFloat(formateFormat
					.format(aggregationmaxprice));
			aggregationminprice = Float.parseFloat(formateFormat
					.format(aggregationminprice));
			constraintsumres = Float.parseFloat(formateFormat
					.format(constraintsumres));
			constraintsumprice = Float.parseFloat(formateFormat
					.format(constraintsumprice));

			// ��ӡ��������ʱ���ʽ
			writerComputeTime.write("clc" + "\n");
			writerComputeTime.write("t1=clock" + "\n");

			// ��ӡf
			count = 0;
			for (i = 0; i < N; i++) {
				for (j = 0; j < M; j++) {
					if (count == 0) {
						writerComputeTime
								.write("f = ["
										+ formateFormat
												.format((wres
														* serviceres[i][j])
														/ (aggregationmaxres - aggregationminres)
														+ (wprice
																* serviceprice[i][j])
														/ (aggregationmaxprice - aggregationminprice))
										+ ";");

						writerUtiltityValue
								.write("f = ["
										+ formateFormat
												.format((wres
														* serviceres[i][j])
														/ (aggregationmaxres - aggregationminres)
														+ (wprice
																* serviceprice[i][j])
														/ (aggregationmaxprice - aggregationminprice))
										+ ";");
					} else if (count == N * M - 1) {
						writerComputeTime
								.write(formateFormat
										.format((wres * serviceres[i][j])
												/ (aggregationmaxres - aggregationminres)
												+ (wprice * serviceprice[i][j])
												/ (aggregationmaxprice - aggregationminprice))
										+ "];" + "\n");
						writerUtiltityValue
								.write(formateFormat
										.format((wres * serviceres[i][j])
												/ (aggregationmaxres - aggregationminres)
												+ (wprice * serviceprice[i][j])
												/ (aggregationmaxprice - aggregationminprice))
										+ "];" + "\n");
					} else {
						writerComputeTime
								.write(formateFormat
										.format((wres * serviceres[i][j])
												/ (aggregationmaxres - aggregationminres)
												+ (wprice * serviceprice[i][j])
												/ (aggregationmaxprice - aggregationminprice))
										+ ";");
						writerUtiltityValue
								.write(formateFormat
										.format((wres * serviceres[i][j])
												/ (aggregationmaxres - aggregationminres)
												+ (wprice * serviceprice[i][j])
												/ (aggregationmaxprice - aggregationminprice))
										+ ";");
					}

					count++;

				}
			}

			// ��ӡ����ʽԼ�� a,��һ����
			count = 0;
			for (i = 0; i < N; i++) {
				for (j = 0; j < M; j++) {
					if (count == 0) {
						writerComputeTime.write("a = ["
								+ String.valueOf(serviceres[i][j]) + " ");
						writerUtiltityValue.write("a = ["
								+ String.valueOf(serviceres[i][j]) + " ");
						count++;
					} else if (count == N * M - 1) {
						writerComputeTime.write(String
								.valueOf(serviceres[i][j]) + ";");// �˴�ע��
						writerUtiltityValue.write(String
								.valueOf(serviceres[i][j]) + ";");
					} else {
						writerComputeTime.write(String
								.valueOf(serviceres[i][j]) + " ");
						writerUtiltityValue.write(String
								.valueOf(serviceres[i][j]) + " ");
						count++;
					}
				}
			}

			count = 0; // ��ӡ����ʽԼ�� a,�ڶ�����
			for (i = 0; i < N; i++) {
				for (j = 0; j < M; j++) {
					if (count == N * M - 1) {
						writerComputeTime.write(String
								.valueOf(serviceprice[i][j]) + "];" + "\n");
						writerUtiltityValue.write(String
								.valueOf(serviceprice[i][j]) + "];" + "\n");
					} else {
						writerComputeTime.write(String
								.valueOf(serviceprice[i][j]) + " ");
						writerUtiltityValue.write(String
								.valueOf(serviceprice[i][j]) + " ");
						count++;
					}
				}
			}

			writerComputeTime.write("b = [" + String.valueOf(constraintsumres)
					+ ";");
			writerComputeTime.write(String.valueOf(constraintsumprice) + "];"
					+ "\n");
			writerUtiltityValue.write("b = ["
					+ String.valueOf(constraintsumres) + ";");
			writerUtiltityValue.write(String.valueOf(constraintsumprice) + "];"
					+ "\n");

			// ��ӡ��ʽԼ��aeq
//			outputaeq5(N, M, count, writerComputeTime);
//			outputaeq5(N, M, count, writerUtiltityValue);
//			// ��ӡbeq ��ʽԼ��
//			writerComputeTime.write("beq = [1;1;1;1;1];" + "\n");
//			writerUtiltityValue.write("beq = [1;1;1;1;1];" + "\n");

			outputaeq10(N, M, count, writerComputeTime);
			outputaeq10(N, M, count, writerUtiltityValue);
			//
			writerComputeTime.write("beq = [1;1;1;1;1;1;1;1;1;1];"+"\n");
			writerUtiltityValue.write("beq = [1;1;1;1;1;1;1;1;1;1];"+"\n");

			// ��ӡ�������
			writerComputeTime.write("[xm,fv] = bintprog(f,a,b,aeq,beq);");
			writerComputeTime.write("\n");
			writerUtiltityValue.write("[xm,fv] = bintprog(f,a,b,aeq,beq)");
			writerUtiltityValue.write("\n");
			//
			writerComputeTime.write("disp(['����ʱ��',num2str(etime(clock,t1))]);");

			writerComputeTime.flush();
			writerComputeTime.close();
			writerUtiltityValue.flush();
			writerUtiltityValue.close();

			DecimalFormat format = new DecimalFormat("0.0000");

			Constantcoefficients = (aggregationmaxres * wres)
					/ (aggregationmaxres - aggregationminres)
					+ (aggregationmaxprice * wprice)
					/ (aggregationmaxprice - aggregationminprice);

			System.out.println("ѡ�����ľۺ���Ӧʱ�����ֵ:" + aggregationmaxres);
			System.out.println("ѡ�����ľۺ���Ӧʱ����Сֵ:" + aggregationminres);
			System.out.println("ѡ�����ľۺϼ۸����ֵ:" + aggregationmaxprice);
			System.out.println("ѡ�����ľۺϼ۸���Сֵ:" + aggregationminprice);

			System.out.println("��Ӧʱ���Լ������:" + constraintsumres);
			System.out.println("�۸��Լ������:" + constraintsumprice);
			System.out.println("��ϵ��:" + format.format(Constantcoefficients));

			writer_const.write("--------------------------------------------"
					+ "\n");
			writer_const.write("Wres=" + wres + "\n");
			writer_const.write("Wprice=" + wprice + "\n");
			writer_const.write("��ѡ�������: data=" + GlobalCoV.servicecandidates
					+ "\n");

			writer_const.write("ѡ�����ľۺ���Ӧʱ�����ֵ:" + aggregationmaxres + "\n");
			writer_const.write("ѡ�����ľۺ���Ӧʱ����Сֵ:" + aggregationminres + "\n");
			writer_const.write("ѡ�����ľۺϼ۸����ֵ:" + aggregationmaxprice + "\n");
			writer_const.write("ѡ�����ľۺϼ۸���Сֵ:" + aggregationminprice + "\n");

			writer_const.write("��Ӧʱ���Լ������:" + constraintsumres + "\n");
			writer_const.write("�۸��Լ������:" + constraintsumprice + "\n");
			writer_const.write("��ϵ��:" + format.format(Constantcoefficients));
			writer_const.flush();
			writer_const.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
