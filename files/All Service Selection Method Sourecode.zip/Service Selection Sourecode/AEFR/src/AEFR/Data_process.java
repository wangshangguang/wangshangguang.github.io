package AEFR;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Data_process {

	private Qosparameter arrQosparameters[] = new Qosparameter[AEFR.servicecandidates];// �ܹ��ĺ�ѡ�������

	public static double constraintsumres = 0.0;
	public static double constraintsumprice = 0.0;

	public static double aggregationmaxres = 0.0;// �ۺ������Ӧʱ��,���
	public static double aggregationminres = 0.0;

	public static double aggregationmaxprice = 0.0;// �ۺ����������,����Сֵ(n����������С�����ֵ)
	public static double aggregationminprice = 0.0;// �ۺ���С������,����Сֵ(n����������С����Сֵ)

	public Data_process() {// ��ʼ�������Qosparameter����,��ֵΪnull,�ᱨ��ָ���쳣
		for (int j = 0; j < AEFR.servicecandidates; j++)
			arrQosparameters[j] = new Qosparameter();
	}

	// ���ݴ�����������Ҫ��ɸ��������������ռ���
	public void serviceDataProcess(BufferedReader readerres,
			BufferedReader readerprice) throws IOException {

		// Ϊ�������ѡ�������Ĵ�������ֵ [����ƽ���� q(s)]
		double averageres = 0.0;//
		double averageprice = 0.0;
		double sumres = 0.0;// ÿ������ ��ʷ��¼ ���
		double sumprice = 0.0;

		// Ϊ�������ѡ����������Եı���ϵ��ֵ����ɿ��ԣ�
		double covres = 0.0;
		double covprice = 0.0;
		double standardres = 0.0;
		double standardprice = 0.0;

		// Ϊ�������ѡ����ı���ϵ��ֵ�����ˣ�
		double averageutility = 0.0;
		double standardutility = 0.0;
		double cov = 0.0;
		double sumutility = 0.0;

		double maxres = 0.0, minres = 1.0;
		double maxprice = 0.0, minprice = 1.0;

		// ��ѡ�����ÿ��QoS��������ת��Ϊһ�������QoSЧ��ֵ
		double[] qosUtility = new double[AEFR.servicehistoricalcounts];
		for (int i = 0; i < AEFR.servicehistoricalcounts; i++)
			qosUtility[i] = 0.0;

		String[] strres = new String[AEFR.servicehistoricalcounts];
		String[] strprice = new String[AEFR.servicehistoricalcounts];
		double[] datares = new double[AEFR.servicehistoricalcounts];
		double[] dataprice = new double[AEFR.servicehistoricalcounts];

		String stringres;
		String stringprice;
		int cnt = 0;// ��ѡ����ĸ���

		while ((stringres = readerres.readLine()) != null
				&& (stringprice = readerprice.readLine()) != null) {

			strres = stringres.split(" ");
			strprice = stringprice.split(" ");

			for (int i = 0; i < AEFR.servicehistoricalcounts; i++) {
				datares[i] = Double.parseDouble(strres[i]);
				dataprice[i] = Double.parseDouble(strprice[i]);

				if (datares[i] > maxres)
					maxres = datares[i];
				if (datares[i] < minres)
					minres = datares[i];

				if (dataprice[i] > maxprice)
					maxprice = dataprice[i];
				if (dataprice[i] < minprice)
					minprice = dataprice[i];

				sumres = sumres + datares[i];
				sumprice = sumprice + dataprice[i];
			}

			for (int i = 0; i < AEFR.servicehistoricalcounts; i++) {
				qosUtility[i] = AEFR.wres * (maxres - datares[i])
						/ (maxres - minres) + AEFR.wprice
						* (maxprice - dataprice[i]) / (maxprice - minprice);
				sumutility = sumutility + qosUtility[i];
			}

			averageres = sumres / AEFR.servicehistoricalcounts;
			averageprice = sumprice / AEFR.servicehistoricalcounts;
			averageutility = sumutility / AEFR.servicehistoricalcounts;

			for (int j = 0; j < AEFR.servicehistoricalcounts; j++) {
				standardres = standardres
						+ Math.pow((averageres - datares[j]), 2);
				standardprice = standardprice
						+ Math.pow((averageprice - dataprice[j]), 2);
				standardutility = standardutility
						+ Math.pow((averageutility - qosUtility[j]), 2);
			}

			standardres = Math.sqrt(standardres
					/ (AEFR.servicehistoricalcounts - 1));
			standardprice = Math.sqrt(standardprice
					/ (AEFR.servicehistoricalcounts - 1));
			standardutility = Math.sqrt(standardutility
					/ (AEFR.servicehistoricalcounts - 1));

			cov = standardutility / averageutility;
			covres = standardres / averageres;
			covprice = standardprice / averageprice;

			arrQosparameters[cnt].setLineNumber(cnt + 1);
			arrQosparameters[cnt].setAverageres(averageres);
			arrQosparameters[cnt].setAverageprice(averageprice);
			arrQosparameters[cnt].setCovres(covres);
			arrQosparameters[cnt].setCovprice(covprice);
			arrQosparameters[cnt].setCov(cov);

			cnt++;
			
			averageres = 0.0;//
			averageprice = 0.0;
			sumres = 0.0;// ÿ������ ��ʷ��¼ ���
			sumprice = 0.0;

			// Ϊ�������ѡ����������Եı���ϵ��ֵ����ɿ��ԣ�
			covres = 0.0;
			covprice = 0.0;
			standardres = 0.0;
			standardprice = 0.0;

			// Ϊ�������ѡ����ı���ϵ��ֵ�����ˣ�
			averageutility = 0.0;
			standardutility = 0.0;
			cov = 0.0;
			sumutility = 0.0;

			maxres = 0.0; minres = 1.0;
			maxprice = 0.0; minprice = 1.0;

			for (int i = 0; i < AEFR.servicehistoricalcounts; i++)
				qosUtility[i] = 0.0;
		}

	}// ���ݴ�����������

	public void dataOperate(FileWriter writerres, FileWriter writerprice,
			FileWriter writercovres, FileWriter writercovprice)
			throws IOException {

		List<Qosparameter> list = new ArrayList<Qosparameter>();

		for (int i = 0; i < AEFR.servicecandidates; i++) {
			list.add(arrQosparameters[i]);
		}

		Collections.sort(list);// ��������

		// Ϊ����ȫ��Լ������constraints
		double sumwholeres = 0.0;
		double sumwholeprice = 0.0;

		// Ϊ���������С Q �� CV
		double globalmaxres = 0.0, globalminres = 1.0;
		double globalmaxprice = 0.0, globalminprice = 1.0;

		double globalmaxcovres = 0.0, globalmincovres = 1000.0;
		double globalmaxcovprice = 0.0, globalmincovprice = 1000.0;

		DecimalFormat format = new DecimalFormat("0.000000");

		for (int i = 0; i < (int) (AEFR.servicecandidates * AEFR.coefficientavariation); i++) {

			Qosparameter qosparameter = list.get(i);

			if (qosparameter.getAverageres() > globalmaxres) {
				globalmaxres = qosparameter.getAverageres();
			}
			if (qosparameter.getAverageres() < globalminres) {
				globalminres = qosparameter.getAverageres();
			}
			if (qosparameter.getAverageprice() > globalmaxprice) {
				globalmaxprice = qosparameter.getAverageprice();
			}
			if (qosparameter.getAverageprice() < globalminprice) {
				globalminprice = qosparameter.getAverageprice();
			}

			if (qosparameter.getCovres() > globalmaxcovres) {
				globalmaxcovres = qosparameter.getCovres();
			}
			if (qosparameter.getCovres() < globalmincovres) {
				globalmincovres = qosparameter.getCovres();
			}
			if (qosparameter.getCovprice() > globalmaxcovprice) {
				globalmaxcovprice = qosparameter.getCovprice();
			}
			if (qosparameter.getCovprice() < globalmincovprice) {
				globalmincovprice = qosparameter.getCovprice();
			}

		}

		System.out.println(globalmaxcovres);
		System.out.println(globalmincovres);
		System.out.println(globalmaxcovprice);
		System.out.println(globalmincovprice);

		// ���Ĺ�ʽ����Ϊ�Ǿ�̬������������ѭ�����ã��ۼ�
		aggregationmaxres = aggregationmaxres + globalmaxres * globalmaxcovres;
		aggregationminres = aggregationminres + globalminres * globalmincovres;

		aggregationmaxprice = aggregationmaxprice + globalmaxprice
				* globalmaxcovprice;
		aggregationminprice = aggregationminprice + globalminprice
				* globalmincovprice;

		for (int i = 0; i < AEFR.servicecandidates; i++) {
			Qosparameter qosparameter = list.get(i);
			sumwholeres = sumwholeres + qosparameter.getAverageres();
			sumwholeprice = sumwholeprice + qosparameter.getAverageprice();
		}
		
		constraintsumres = constraintsumres + sumwholeres
				/ AEFR.servicecandidates;
		constraintsumprice = constraintsumprice + sumwholeprice
				/ AEFR.servicecandidates;

		for (int i = 0; i < (int) (AEFR.servicecandidates * AEFR.coefficientavariation); i++) {
			Qosparameter qosparameter = list.get(i);

			if (i == (int) (AEFR.servicecandidates * AEFR.coefficientavariation) - 1) {
				writerres.write(format.format(qosparameter.getAverageres())
						+ "\n");
				writerprice.write(format.format(qosparameter.getAverageprice())
						+ "\n");
				writercovres.write(format.format(qosparameter.getCovres())
						+ "\n");
				writercovprice.write(format.format(qosparameter.getCovprice())
						+ "\n");
			} else {

				writerres.write(format.format(qosparameter.getAverageres())
						+ " ");
				writerprice.write(format.format(qosparameter.getAverageprice())
						+ " ");
				writercovres.write(format.format(qosparameter.getCovres())
						+ " ");
				writercovprice.write(format.format(qosparameter.getCovprice())
						+ " ");
			}
		}

		list.removeAll(list);

		writerres.flush();
		writerres.close();
		writerprice.flush();
		writerprice.close();
		writercovres.flush();
		writercovres.close();
		writercovprice.flush();
		writercovprice.close();

	}

}
