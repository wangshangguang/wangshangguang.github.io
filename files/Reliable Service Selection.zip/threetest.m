apsotime=0;
mip1time=0;
mip2time=0;
for i=1:50
%     test1;
% apsotime=time1+apsotime;
test2;
 mip1time=time2+mip1time;
%   test3;
%   mip2time=time3+mip2time;

end

% %%%%%%%%%%��ͬ��ѡ���������ʵ��
% L=50;threetest;
% L=100;threetest;
% L=150;threetest;
% L=200;threetest;
% L=250;threetest;
% L=300;threetest;
% L=350;threetest;
% L=400;threetest;
% L=450;threetest;
% L=500;threetest;
% L=600;threetest;
% L=700;threetest;
% L=800;threetest;
% L=900;threetest;
% L=1000;threetest;
% L=1500;threetest;
% L=2000;threetest;
% L=2500;threetest;
% L=3000;threetest;
% L=3500;threetest;
% L=4000;threetest;
% L=4500;threetest;
% L=5000;threetest


% %%%%%%%%%%��ͬ�����������ʵ��
% D=5;threetest;
% D=10;threetest;
% D=15;threetest;
% D=20;threetest;
% D=25;threetest;
% D=30;threetest;
% D=35;threetest;
% D=40;threetest;
% D=45;threetest;
% D=50;threetest;
% D=60;threetest;
% D=70;threetest;
% D=80;threetest;
% D=90;threetest;
% D=100;threetest;
% D=150;threetest;
% D=200;threetest;
% D=250;threetest;
% D=300;threetest;
% D=350threetest;
% D=400;threetest;
% D=450;threetest;
% D=500;threetest

