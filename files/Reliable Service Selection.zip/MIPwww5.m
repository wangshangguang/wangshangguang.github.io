%%%%%����������3��MIP�������бȽ�
% D������
%%% L ��ѡ����
%%% allM  ȫ������
%MԼ������
%%%Sqos��ԭʼ���ݼ���

clear max;
  
%   D=5;


   L1=d; 

a=binvar(1,L1);%%0-1���� x����
b=binvar(1,L1);
c=binvar(1,L1);
d=binvar(1,L1);
e=binvar(1,L1);
a1=binvar(1,L1);%%0-1���� x����
b1=binvar(1,L1);
c1=binvar(1,L1);
d1=binvar(1,L1);
e1=binvar(1,L1);
a2=binvar(1,L1);%%0-1���� x����15
b2=binvar(1,L1);
c2=binvar(1,L1);
d2=binvar(1,L1);
e2=binvar(1,L1);
a3=binvar(1,L1);%%0-1���� x����20
b3=binvar(1,L1);
c3=binvar(1,L1);
d3=binvar(1,L1);
e3=binvar(1,L1);
a4=binvar(1,L1);%%0-1���� x����25
b4=binvar(1,L1);
c4=binvar(1,L1);
d4=binvar(1,L1);
e4=binvar(1,L1);
a5=binvar(1,L1);%%0-1���� x����30
b5=binvar(1,L1);
c5=binvar(1,L1);
d5=binvar(1,L1);
e5=binvar(1,L1);
a6=binvar(1,L1);%%0-1���� x����35
b6=binvar(1,L1);
c6=binvar(1,L1);
d6=binvar(1,L1);
e6=binvar(1,L1);
a7=binvar(1,L1);%%0-1���� x����40
b7=binvar(1,L1);
c7=binvar(1,L1);
d7=binvar(1,L1);
e7=binvar(1,L1);
a8=binvar(1,L1);%%0-1���� x����45
b8=binvar(1,L1);
c8=binvar(1,L1);
d8=binvar(1,L1);
e8=binvar(1,L1);
a9=binvar(1,L1);%%0-1���� x����45
b9=binvar(1,L1);
c9=binvar(1,L1);
d9=binvar(1,L1);
e9=binvar(1,L1);
y=0;
for all=1:M  %%%%�����Ժ���
y1=a*SP(:,all,1)+b*SP(:,all,2)+c*SP(:,all,3)+d*SP(:,all,4)+e*SP(:,all,5);
y2=a1*SP(:,all,1)+b1*SP(:,all,2)+c1*SP(:,all,3)+d1*SP(:,all,4)+e1*SP(:,all,5);%10
y3=a2*SP(:,all,1)+b2*SP(:,all,2)+c2*SP(:,all,3)+d2*SP(:,all,4)+e2*SP(:,all,5);
y4=a3*SP(:,all,1)+b3*SP(:,all,2)+c3*SP(:,all,3)+d3*SP(:,all,4)+e3*SP(:,all,5);
y5=a4*SP(:,all,1)+b4*SP(:,all,2)+c4*SP(:,all,3)+d4*SP(:,all,4)+e4*SP(:,all,5);
y6=a5*SP(:,all,1)+b5*SP(:,all,2)+c5*SP(:,all,3)+d5*SP(:,all,4)+e5*SP(:,all,5);
y7=a6*SP(:,all,1)+b6*SP(:,all,2)+c6*SP(:,all,3)+d6*SP(:,all,4)+e6*SP(:,all,5);
y8=a7*SP(:,all,1)+b7*SP(:,all,2)+c7*SP(:,all,3)+d7*SP(:,all,4)+e7*SP(:,all,5);
y9=a8*SP(:,all,1)+b8*SP(:,all,2)+c8*SP(:,all,3)+d8*SP(:,all,4)+e8*SP(:,all,5);
y10=a9*SP(:,all,1)+b9*SP(:,all,2)+c9*SP(:,all,3)+d9*SP(:,all,4)+e9*SP(:,all,5);
y=y+y1+y2+y3+y4+y5+y6+y7+y8+y9+y10;
end
  
f=y;
F=set((a*ones(L1,1))==1)+set((b*ones(L1,1))==1)+set((c*ones(L1,1))==1)+set((d*ones(L1,1))==1)+set((e*ones(L1,1))==1);
F=F+set((a1*ones(L1,1))==1)+set((b1*ones(L1,1))==1)+set((c1*ones(L1,1))==1)+set((d1*ones(L1,1))==1)+set((e1*ones(L1,1))==1);
F=F+set((a2*ones(L1,1))==1)+set((b2*ones(L1,1))==1)+set((c2*ones(L1,1))==1)+set((d2*ones(L1,1))==1)+set((e2*ones(L1,1))==1);
F=F+set((a3*ones(L1,1))==1)+set((b3*ones(L1,1))==1)+set((c3*ones(L1,1))==1)+set((d3*ones(L1,1))==1)+set((e3*ones(L1,1))==1);
 F=F+set((a4*ones(L1,1))==1)+set((b4*ones(L1,1))==1)+set((c4*ones(L1,1))==1)+set((d4*ones(L1,1))==1)+set((e4*ones(L1,1))==1);
F=F+set((a5*ones(L1,1))==1)+set((b5*ones(L1,1))==1)+set((c5*ones(L1,1))==1)+set((d5*ones(L1,1))==1)+set((e5*ones(L1,1))==1);
 F=F+set((a6*ones(L1,1))==1)+set((b6*ones(L1,1))==1)+set((c6*ones(L1,1))==1)+set((d6*ones(L1,1))==1)+set((e6*ones(L1,1))==1);
 F=F+set((a7*ones(L1,1))==1)+set((b7*ones(L1,1))==1)+set((c7*ones(L1,1))==1)+set((d7*ones(L1,1))==1)+set((e7*ones(L1,1))==1); 
F=F+set((a8*ones(L1,1))==1)+set((b8*ones(L1,1))==1)+set((c8*ones(L1,1))==1)+set((d8*ones(L1,1))==1)+set((e8*ones(L1,1))==1);
F=F+set((a9*ones(L1,1))==1)+set((b9*ones(L1,1))==1)+set((c9*ones(L1,1))==1)+set((d9*ones(L1,1))==1)+set((e9*ones(L1,1))==1);
solvesdp(F,f,sdpsettings('verbose',0,'warning',0));%%%%%MIP���
 


x=find(double(a));%%%%���λ��0-1����5
y=find(double(b));
z=find(double(c));
w=find(double(d));
u=find(double(e));

x1=find(double(a));%%%%���λ��0-1����10
y1=find(double(b));
z1=find(double(c));
w1=find(double(d));
u1=find(double(e));
x2=find(double(a));%%%%���λ��0-1����15
y2=find(double(b));
z2=find(double(c));
w2=find(double(d));
u2=find(double(e));
x3=find(double(a));%%%%���λ��0-1����20
y3=find(double(b));
z3=find(double(c));
w3=find(double(d));
u3=find(double(e));
x4=find(double(a));%%%%���λ��0-1����25
y4=find(double(b));
z4=find(double(c));
w4=find(double(d));
u4=find(double(e));
x5=find(double(a));%%%%���λ��0-1����30
y5=find(double(b));
z5=find(double(c));
w5=find(double(d));
u5=find(double(e));
x6=find(double(a));%%%%���λ��0-1����35
y6=find(double(b));
z6=find(double(c));
w6=find(double(d));
u6=find(double(e));
x7=find(double(a));%%%%���λ��0-1����
y7=find(double(b));
z7=find(double(c));
w7=find(double(d));
u7=find(double(e));
x8=find(double(a));%%%%���λ��0-1����50
y8=find(double(b));
z8=find(double(c));
w8=find(double(d));
u8=find(double(e));
x9=find(double(a));%%%%���λ��0-1����50
y9=find(double(b));
z9=find(double(c));
w9=find(double(d));
u9=find(double(e));

QQQ=[x,y,z,w,u,x1,y1,z1,w1,u1,x2,y2,z2,w2,u2,x3,y3,z3,w3,u3,x4,y4,z4,w4,u4,x5,y5,z5,w5,u5,x6,y6,z6,w6,u6,x7,y7,z7,w7,u7,x8,y8,z8,w8,u8,x9,y9,z9,w9,u9];%%%%����ѡ����



%%%%%S�Ǳ�����ݼ�
%%%%%
% allM=9;%%%���ݼ�ԭʼ����
clear max;
clear QMAX;
clear QMAX1;
clear QMIN;
clear QMIN1;

QMAX=max(Sqos);
QMAX=reshape(QMAX,allM,D);
QMAX1=QMAX';
QMAX=max(QMAX1);
%%%%%%%%%%%QOS��ÿ�����Ե���Сֵ
QMIN=min(Sqos);
QMIN=reshape(QMIN,allM,D);
QMIN1=QMIN';
QMIN=min(QMIN1);
%%%%****************************************
clear qos;
index=1;
sqos=0;
global mip2qosresult;
mip2qosresult=0;
for i=1:D
        for m=1:M
            if QQQ(i)==1
               wsx=0;
            else
                wsx=S(QQQ(i)-1,m,i);               
            end
        [index1]=find(wsx<Sqos(:,m,i)&Sqos(:,m,i)<=S(QQQ(i),m,i));
        
        if numel(index1)>index
            index=index1;
        end
        end
    
    for all=1:allM
        qos=max(((QMAX1(i,all)-Sqos(index,all,i))/(QMAX(all)-QMIN(all))));
        sqos=qos+sqos;%%%���յ��������Ч�ú���ֵ
    end
    mip2qosresult=mip2qosresult+sqos;
end
global time3;
time3 = etime(clock, T3)
