package EntityClass;

public class VM {
  int id;
  double req_MIPS;
  double req_mem;
  int vmUtilizationCurve;//��������������ʵı仯�������͵ı�־λ����������ǰԤ���
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public double getReq_MIPS() {
	return req_MIPS;
}
public void setReq_MIPS(double req_MIPS) {
	this.req_MIPS = req_MIPS;
}
public double getReq_mem() {
	return req_mem;
}
public void setReq_mem(double req_mem) {
	this.req_mem = req_mem;
}
public int getVmUtilizationCurve() {
	return vmUtilizationCurve;
}
public void setVmUtilizationCurve(int vmUtilizationCurve) {
	this.vmUtilizationCurve = vmUtilizationCurve;
}
public VM(int id,double req_MIPS,double req_mem){
	this.id=id;
	this.req_MIPS=req_MIPS;
	this.req_mem=req_mem;	
}
public VM(){
	this.id=-1;
	this.req_MIPS=0;
	this.req_mem=0;	
}
public Object clone(){        
	VM o=null;
	try {          
		o=(VM)super.clone();  
		}catch(CloneNotSupportedException e) {   
			System.out.println(e.toString()); 
		}       
	return o;   
}
}

