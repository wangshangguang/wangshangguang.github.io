package EntityClass;
import java.util.ArrayList;
import java.util.List;

public class PM {
  int id;
  double MIPS;
  int mem;
  List<VM> vmList=new ArrayList<VM>();//�����������õ�������б�
  

public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}

public double getMIPS() {
	return MIPS;
}
public void setMIPS(double mIPS) {
	MIPS = mIPS;
}
public int getMem() {
	return mem;
}
public void setMem(int mem) {
	this.mem = mem;
}
public List<VM> getVmList() {
	return vmList;
}
public void setVmList(List<VM> vmList) {
	this.vmList = vmList;
}
public PM(int id,double MIPS,int mem){
	this.id=id;
	this.MIPS=MIPS;
	this.mem=mem;
	this.vmList=null;
}
public PM(){
	this.id=-1;
	this.MIPS=0;
	this.mem=0;	
	this.vmList=null;
}
}

