/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package org.cloudbus.cloudsim.CKP.datacenter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.cloudbus.cloudsim.checkpoint.DCNetworkVisitor;
import org.cloudbus.cloudsim.checkpoint.RecordToLogger;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEvent;
import org.cloudbus.cloudsim.core.predicates.PredicateType;

/**
 * This class allows to simulate Root switch which connects Datacenter to external network. It
 * interacts with other switches in order to exchange packets.
 * 
 * Please refer to following publication for more details:
 * 
 * Saurabh Kumar Garg and Rajkumar Buyya, NetworkCloudSim: Modelling Parallel Applications in Cloud
 * Simulations, Proceedings of the 4th IEEE/ACM International Conference on Utility and Cloud
 * Computing (UCC 2011, IEEE CS Press, USA), Melbourne, Australia, December 5-7, 2011.
 * 
 * @author Saurabh Kumar Garg
 * @since CloudSim Toolkit 3.0
 */
public class RootSwitch extends Switch {
	private NetworkStorageHost storageCenter;
	
	private double bandwidthToStorageCenter;	

	private Map<Integer, List<NetworkPacket>> packetToStorageCenter;

	/**
	 * Constructor for Root Switch We have to specify switches that are connected to its downlink
	 * ports, and corresponding bandwidths
	 * 
	 * @param name Name of the switch
	 * @param level At which level switch is with respect to hosts.
	 * @param dc Pointer to Datacenter
	 */
	public RootSwitch(String name, int level, NetworkDatacenter dc, int worldX, int worldY) {
		super(name, level, dc, worldX, worldY);
		downlinkswitchpktlist = new HashMap<Integer, List<NetworkPacket>>();
		downlinkswitches = new ArrayList<Switch>();
		downlinkbandwidth = NetworkConstants.BandWidthAggRoot;
		latency = NetworkConstants.SwitchingDelayEdge;
		numport = NetworkConstants.RootSwitchPort;
		
		bandwidthToStorageCenter = NetworkConstants.BandWidthAggRoot;
		packetToStorageCenter = new HashMap<Integer, List<NetworkPacket>>();
	}
	
	@Override
	public void processEvent(SimEvent ev) {
		// RecordToLogger.logger.info(CloudSim.clock()+"[Broker]: event received:"+ev.getTag());
		switch (ev.getTag()) {
		// Resource characteristics request
			case CloudSimTags.Network_Event_UP:
				// process the packet from down switch or host
				processpacket_up(ev);
				break;
			case CloudSimTags.Network_Event_DOWN:
				// process the packet from uplink
				processpacket_down(ev);
				break;
			case CloudSimTags.Network_Event_send:
				processpacketforward(ev);
				break;
			// other unknown tags are processed by this method
			default:
				super.processEvent(ev);
				break;
		}
	}

	/**
	 * Send Packet to switch connected through a downlink port
	 * 
	 * @param ev Event/packet to process
	 */
	@Override
	protected void processpacket_up(SimEvent ev) {
		// packet coming from down level router.
		// has to send up
		// check which switch to forward to
		// add packet in the switch list

		NetworkPacket hspkt = (NetworkPacket) ev.getData();
		int recvVMid = hspkt.pkt.virtualrecvid;
		CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.Network_Event_send));
		schedule(getId(), 0, CloudSimTags.Network_Event_send);
		

		if(hspkt.recieverhostid == storageCenter.getId()){
			List<NetworkPacket> pktlist = packetToStorageCenter.get(hspkt.recieverhostid);
			if (pktlist == null) {
				pktlist = new ArrayList<NetworkPacket>();
				packetToStorageCenter.put(hspkt.recieverhostid, pktlist);
			}
			pktlist.add(hspkt);
			return;
		}
		
		// get id of edge router		
		NetworkDatacenterCharacteristics characteristics = (NetworkDatacenterCharacteristics)dc.getCharacteristics();		
		NetworkHost host = (NetworkHost)CloudSim.getEntity(hspkt.recieverhostid);
		int edgeswitchid = host.sw.getId();
		// search which aggregate switch has it
		int aggSwtichid = -1;
		
		for (Switch sw : downlinkswitches) {
			for (Switch edge : sw.downlinkswitches) {
				if (edge.getId() == edgeswitchid) {
					aggSwtichid = sw.getId();
					break;
				}
			}
		}
		if (aggSwtichid < 0) {
			RecordToLogger.logger.error(" No destination for this packet");
		} else {
			List<NetworkPacket> pktlist = downlinkswitchpktlist.get(aggSwtichid);
			if (pktlist == null) {
				pktlist = new ArrayList<NetworkPacket>();
				downlinkswitchpktlist.put(aggSwtichid, pktlist);
			}
			pktlist.add(hspkt);
		}
	}
	
	/**
	 * Send Packet to switch connected through a downlink port
	 * 
	 * @param ev Event/packet to process
	 */

	@Override
	protected void processpacket_down(SimEvent ev) {
		// packet coming from storage center.
		// has to send downward
		// check which switch to forward to
		// add packet in the switch list
		// add packet in the host list

		NetworkPacket hspkt = (NetworkPacket) ev.getData();
		int recvVMid = hspkt.pkt.virtualrecvid;
		CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.Network_Event_send));
		schedule(getId(), 0, CloudSimTags.Network_Event_send);
		// get id of edge router
		NetworkDatacenterCharacteristics characteristics = (NetworkDatacenterCharacteristics)dc.getCharacteristics();
//		int edgeswitchid = characteristics.VmToSwitchid.get(recvVMid);
		NetworkHost host = (NetworkHost)CloudSim.getEntity(hspkt.recieverhostid);
		int edgeswitchid = host.sw.getId();
		// search which aggregate switch has it
		int aggSwtichid = -1;
		
		for (Switch sw : downlinkswitches) {
			for (Switch edge : sw.downlinkswitches) {
				if (edge.getId() == edgeswitchid) {
					aggSwtichid = sw.getId();
					break;
				}
			}
		}
		if (aggSwtichid < 0) {
			RecordToLogger.logger.error(" No destination for this packet");
		} else {
			List<NetworkPacket> pktlist = downlinkswitchpktlist.get(aggSwtichid);
			if (pktlist == null) {
				pktlist = new ArrayList<NetworkPacket>();
				downlinkswitchpktlist.put(aggSwtichid, pktlist);
			}
			pktlist.add(hspkt);
		}
		
	}
	
	protected void processpacketforward(SimEvent ev) {
		// search for the host and packets..send to them

		if (downlinkswitchpktlist != null) {
			for (Entry<Integer, List<NetworkPacket>> es : downlinkswitchpktlist.entrySet()) {
				int tosend = es.getKey();
				List<NetworkPacket> hspktlist = es.getValue();
				if (!hspktlist.isEmpty()) {
//					double avband = downlinkbandwidth / hspktlist.size();
					double avband = downlinkbandwidth ;
					Iterator<NetworkPacket> it = hspktlist.iterator();
					while (it.hasNext()) {
						NetworkPacket hspkt = it.next();
						double delay = hspkt.pkt.data.getSize() / avband + NetworkConstants.SwitchingDelayRoot;
						NetworkConstants.totle_delay_time+=delay;
						this.send(tosend, delay, CloudSimTags.Network_Event_DOWN, hspkt);
//						System.out.println(this.getName()+"send packet"+CloudSim.clock());
						hasReceviedCKPPacketSize = hasReceviedCKPPacketSize + hspkt.pkt.data.getSize();
						
						if(hspkt.pkt.type == NetworkConstants.RECOVERY_CLOUDLIT)
							hspkt.arriveTime.add(this);
					}
					hspktlist.clear();
				}
			}
		}
		if (packetToStorageCenter != null) {
			for (Entry<Integer, List<NetworkPacket>> es : packetToStorageCenter.entrySet()) {
				int tosend = es.getKey();
				List<NetworkPacket> hspktlist = es.getValue();
				if (!hspktlist.isEmpty()) {
//					double avband = bandwidthToStorageCenter / hspktlist.size();
					double avband = downlinkbandwidth ;
					Iterator<NetworkPacket> it = hspktlist.iterator();
					while (it.hasNext()) {
						NetworkPacket hspkt = it.next();
						double delay = hspkt.pkt.data.getSize() / avband + NetworkConstants.SwitchingDelayRootToStorageCenter;
						NetworkConstants.totle_delay_time+=delay;
						this.send(tosend, delay, CloudSimTags.Network_Event_UP, hspkt);
						
						hasReceviedCKPPacketSize = hasReceviedCKPPacketSize + hspkt.pkt.data.getSize();
						
						if(hspkt.pkt.type == NetworkConstants.RECOVERY_CLOUDLIT)
							hspkt.arriveTime.add(this);
					}
					hspktlist.clear();
				}
			}
		}
	}
	

	public Map<Integer, List<NetworkPacket>> getPacketToStorageCenter() {
		return packetToStorageCenter;
	}

	public void setPacketToStorageCenter(
			Map<Integer, List<NetworkPacket>> packetToStorageCenter) {
		this.packetToStorageCenter = packetToStorageCenter;
	}
	
	public NetworkStorageHost getStorageCenter() {
		return storageCenter;
	}

	public void setStorageCenter(NetworkStorageHost storageCenter) {
		this.storageCenter = storageCenter;
	}
	
	public List<NetworkHost> getHostFromOtherPad(NetworkHost host){
		ArrayList<NetworkHost> hosts = new ArrayList<NetworkHost>();
		for(int i = 0; i < downlinkswitches.size(); i++){
			if(host.sw.uplinkswitches.contains(downlinkswitches.get(i)))
				continue;
			AggregateSwitch es = (AggregateSwitch)downlinkswitches.get(i);
			hosts.addAll(es.getAllHostBelow());
		}
		return hosts;
	}
	
	@Override
	public void accept(DCNetworkVisitor visitor, Object data) {
		visitor.visit(this, data);
		
	}


}
