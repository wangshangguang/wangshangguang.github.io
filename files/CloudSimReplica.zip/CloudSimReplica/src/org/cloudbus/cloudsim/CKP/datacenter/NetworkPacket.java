/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package org.cloudbus.cloudsim.CKP.datacenter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * NewtorkPacket represents the packet which travel from one server to another. Each packet contains
 * ids of the sender VM and receiver VM, time at which it is send and received, type and virtual ids
 * of tasks, which are communicating.
 * 
 * Please refer to following publication for more details:
 * 
 * Saurabh Kumar Garg and Rajkumar Buyya, NetworkCloudSim: Modelling Parallel Applications in Cloud
 * Simulations, Proceedings of the 4th IEEE/ACM International Conference on Utility and Cloud
 * Computing (UCC 2011, IEEE CS Press, USA), Melbourne, Australia, December 5-7, 2011.
 * 
 * @author Saurabh Kumar Garg
 * @since CloudSim Toolkit 1.0
 */
public class NetworkPacket {

	public HostPacket pkt;

	public 	int senderhostid;

	public 	int recieverhostid;

	public 	int sendervmid;

	public 	int recievervmid;

//	public 	int cloudletid;

	public 	double stime;// time when sent

	public 	double rtime;// time when received
	
	public List<Switch> arriveTime = new ArrayList<Switch>();

	public NetworkPacket(HostPacket pkt) {
		this.pkt = pkt;
		sendervmid = pkt.virtualsendid;
		recievervmid = pkt.virtualrecvid;
		senderhostid = pkt.sender;
		recieverhostid = pkt.reciever;
		stime = pkt.sendtime;
	}

}
