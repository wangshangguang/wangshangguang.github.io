package org.cloudbus.cloudsim.CKP.datacenter;

public class Config {
	//0 non checkpoint 1: non-delta checkpoint 2: detlta checkpoint 3: app checkpoint
	public static int  CheckpointStyle = 0;
	
	public static int portNum = 32;
	
	public static boolean isFocus=true;
	

}
