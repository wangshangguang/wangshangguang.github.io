/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package org.cloudbus.cloudsim.CKP.datacenter;

/**
 * HostPacket represents the packet that travels through the virtual network with a Host. It
 * contains information about cloudlets which are communicating
 * 
 * Please refer to following publication for more details:
 * 
 * Saurabh Kumar Garg and Rajkumar Buyya, NetworkCloudSim: Modelling Parallel Applications in Cloud
 * Simulations, Proceedings of the 4th IEEE/ACM International Conference on Utility and Cloud
 * Computing (UCC 2011, IEEE CS Press, USA), Melbourne, Australia, December 5-7, 2011.
 * 
 * @author Saurabh Kumar Garg
 * @since CloudSim Toolkit 1.0
 */
public class HostPacket {
	public int type;
	
	public int sender;	

	public int reciever;

	public int virtualrecvid;

	public int virtualsendid;
	
	public int cloudletid;

	public Data data;

	public double sendtime;

	double recievetime;

	public HostPacket(
			int type,
			int sender,
			int reciever,
			int vsnd,
			int vrvd,
			int cloudletid,
			double sendtime,
			double recievetime,
			Data data
			) {
		super();
		this.type = type;
		this.sender = sender;
		this.reciever = reciever;
		this.data = data;
		this.sendtime = sendtime;
		this.recievetime = recievetime;
		this.cloudletid=cloudletid;
		virtualrecvid = vrvd;
		virtualsendid = vsnd;
	}

}
