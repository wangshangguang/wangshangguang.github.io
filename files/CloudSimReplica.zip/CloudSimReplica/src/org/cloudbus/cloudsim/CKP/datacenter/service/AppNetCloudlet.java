package org.cloudbus.cloudsim.CKP.datacenter.service;

import java.util.ArrayList;
import java.util.List;

import org.cloudbus.cloudsim.CKP.datacenter.NetworkVm;

public class AppNetCloudlet {
	public int appId;
	public int userID;
	public int type;
	public double baseSystemSize;
	public double diskSize;
	public List<NetworkVm> mainVmList;
	public List<NetworkVm> subVmList;
	
	private List<NetworkCloudlet> cloudletList;
	

	public AppNetCloudlet(int appId , int userID, double baseSystemSize,double diskSize) {
		this.appId = appId;
		this.userID = userID;
		this.baseSystemSize = baseSystemSize;
		this.diskSize = diskSize;
		cloudletList = new ArrayList<NetworkCloudlet>();
		mainVmList=new ArrayList<NetworkVm>();
		subVmList=new ArrayList<NetworkVm>();
	}

	public List<NetworkCloudlet> getCloudletList() {
		return cloudletList;
	}

	public void setCloudletList(List<NetworkCloudlet> cloudletList) {
		this.cloudletList = cloudletList;
	}
	
	public void addCloudlet( NetworkCloudlet cloudlet) {
		this.cloudletList.add(cloudlet);
	}

	public List<NetworkVm> getMainVmList() {
		return mainVmList;
	}

	public void setMainVmList(List<NetworkVm> mainVmList) {
		this.mainVmList = mainVmList;
	}

	public List<NetworkVm> getSubVmList() {
		return subVmList;
	}

	public void setSubVmList(List<NetworkVm> subVmList) {
		this.subVmList = subVmList;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}
	

}
