package org.cloudbus.cloudsim.CKP.datacenter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;

import org.cloudbus.cloudsim.CKP.datacenter.service.AppNetCloudlet;
import org.cloudbus.cloudsim.CKP.datacenter.service.NetworkCloudlet;
import org.cloudbus.cloudsim.checkpoint.AppCheckpoint;
import org.cloudbus.cloudsim.checkpoint.CloudletCheckpoint;
import org.cloudbus.cloudsim.checkpoint.DCNetworkVisitor;
import org.cloudbus.cloudsim.checkpoint.RecordToLogger;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEvent;
import org.cloudbus.cloudsim.core.predicates.PredicateType;
import org.cloudbus.cloudsim.replication.SmallCloudletStorage;

public class NetworkStorageHost extends DataCenterNode {
	public Map<Integer,EdgeSwitch> storageEdgeSwitch=new HashMap<Integer,EdgeSwitch>();
	
	public Map<NetworkResCloudlet, CloudletCheckpoint> cloudletCheckpointCenter = new HashMap<NetworkResCloudlet, CloudletCheckpoint>();
	
	public Map<AppNetCloudlet, AppCheckpoint> appCheckpointCenter = new HashMap<AppNetCloudlet, AppCheckpoint>();
	
	public List<NetworkPacket> packetTosend = new ArrayList<NetworkPacket> ();

	public List<NetworkPacket> packetrecieved = new ArrayList<NetworkPacket> ();

	public List<DataCenterLink> downlinks = new ArrayList<DataCenterLink> ();

	public List<RootSwitch> downlinkswitches;

	public double downlinkbandwidth;

	public double latency;

	public NetworkDatacenter dc;

	public double switching_delay;
	
	public Map<Integer, List<NetworkPacket>> downlinkswitchpktlist;

	public NetworkStorageHost(String name, NetworkDatacenter dc, int worldX, int worldY) {
		super(name, worldX, worldY);		

		this.dc = dc;
		
		packetTosend = new ArrayList<NetworkPacket> ();

		packetrecieved = new ArrayList<NetworkPacket> ();

		downlinks = new ArrayList<DataCenterLink> ();

		downlinkswitches = new ArrayList<RootSwitch> ();

		downlinkbandwidth = NetworkConstants.BandWidthAggRoot;

		latency = NetworkConstants.SwitchingDelayEdge;
		
		storageEdgeSwitch =new HashMap<Integer,EdgeSwitch>();
		
		downlinkswitchpktlist = new HashMap<Integer, List<NetworkPacket>>();
	}
	
	@Override
	public void processEvent(SimEvent ev) {
		// RecordToLogger.logger.info(CloudSim.clock()+"[Broker]: event received:"+ev.getTag());
		switch (ev.getTag()) {
		// Resource characteristics request
			case CloudSimTags.Network_Event_UP:
			// process the packet from down switch or host
				processpacket(ev);
				break;
			case CloudSimTags.Network_Event_send:
				processpacketforward(ev);
				break;
			case CloudSimTags.RECOVERY_CLOUDLET_POINT_SEDN:
				recoveryCloudletPointSend(ev);
				break;
			case CloudSimTags.RECOVERY_APP_POINT_SEDN:
				recoveryAppPointSend(ev);
				break;
			case CloudSimTags.RESTART_CLOULET:
				restartCloulet(ev);
				break;
			case CloudSimTags.FETCH_APP_CHECKPOINT:
				appPointFetchAck(ev);
				break;
			// other unknown tags are processed by this method
			default:
				break;
		}
	}
	
	
	protected void processpacket(SimEvent ev){
		NetworkPacket hspkt = (NetworkPacket) ev.getData();
//		int recvVMid = hspkt.pkt.virtualrecvid;
		hspkt.pkt.recievetime = CloudSim.clock();
		CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.Network_Event_send));
		schedule(getId(), 0, CloudSimTags.Network_Event_send);
//		System.out.println("checkpoint"+CloudSim.clock());
//yang	
		HostPacket pkt=hspkt.pkt;
		if(pkt.type==NetworkConstants.GET_CLOUDLET_INFO){
			int type=NetworkConstants.RETURN_CLOUDLET_INFO;
			int sender=this.getId();
			
//			int port_id=host.sw.getWorldY()/Config.portNum/2;
//			EdgeSwitch sw=this.getStorageEdgeSwitch().get(port_id);
//			Set<Integer> host_id_set=sw.hostlist.keySet();
//			Iterator<Integer> it=host_id_set.iterator();
//			int recever_id=(Integer)it.next();
			int recever_id=hspkt.senderhostid;
			int virrece_id=hspkt.sendervmid;
			int virsend_id=-1;
			int cloudletid=pkt.cloudletid;
			SmallCloudletStorage newdata=new SmallCloudletStorage(300);
			HostPacket newPKT=new HostPacket(type,sender,recever_id,virsend_id,virrece_id,cloudletid,0,0,newdata);
			NetworkPacket npkt = new NetworkPacket(newPKT);
			
			List<NetworkPacket> pktlist = downlinkswitchpktlist.get(downlinkswitches.get(0).getId());
			if (pktlist == null) {
				pktlist = new ArrayList<NetworkPacket>();
			}
			pktlist.add(npkt);
			downlinkswitchpktlist.put(downlinkswitches.get(0).getId(), pktlist);
		}
		if(hspkt.pkt.data instanceof CloudletCheckpoint){
			CloudletCheckpoint ckp = (CloudletCheckpoint)hspkt.pkt.data;
			if(ckp.getType() == NetworkConstants.SYSTEM_CHECKPOINT){
				this.cloudletCheckpointCenter.put(ckp.getResCloudlet(), ckp);
				RecordToLogger.logger.debug(this.getName() + "receive system checkpoint of cloulet " + ckp.getResCloudlet().getCloudlet().getCloudletId()+" "+CloudSim.clock());
			}
			else{
				if(	this.cloudletCheckpointCenter.containsKey(ckp.getResCloudlet())){					
					ckp.setSize(this.cloudletCheckpointCenter.get(ckp.getResCloudlet()).getSize());
					
					this.cloudletCheckpointCenter.put(ckp.getResCloudlet(), ckp);					
					
					RecordToLogger.logger.debug(this.getName() + "receive delta checkpoint of cloulet " + ckp.getResCloudlet().getCloudlet().getCloudletId()+" "+ckp.getFinishedSoFar()+" "+CloudSim.clock());
				}
				else{
					NetworkCloudlet cloudlet = (NetworkCloudlet)ckp.getResCloudlet().getCloudlet();
					cloudlet.hasCloudletSystemImage = false;
					cloudlet.lastFinishedSoFar = 0;
				}
			}
//			System.out.println("checkpoint from: "+ckp.getResCloudlet().getCloudletId());
		}
		else if(hspkt.pkt.data instanceof AppCheckpoint){
			AppCheckpoint ckp = (AppCheckpoint)hspkt.pkt.data;
			this.appCheckpointCenter.put(ckp.getAppCloudlet(), ckp);
			RecordToLogger.logger.debug(this.getName() + "receive app checkpoint of cloulet" + ckp.getAppCloudlet().appId+" "+CloudSim.clock());
		}
		
		packetrecieved.add(hspkt);
		
	}
	
	protected void processpacketforward(SimEvent ev) {
		// search for the host and packets..send to them
		if (downlinkswitchpktlist != null) {
			for (Entry<Integer, List<NetworkPacket>> es : downlinkswitchpktlist.entrySet()) {
				int tosend = es.getKey();
				List<NetworkPacket> hspktlist = es.getValue();
				if (!hspktlist.isEmpty()) {
					double avband = downlinkbandwidth / hspktlist.size();
					Iterator<NetworkPacket> it = hspktlist.iterator();
					while (it.hasNext()) {
						NetworkPacket hspkt = it.next();
						double delay = hspkt.pkt.data.getSize() / avband + NetworkConstants.SwitchingDelayRootToStorageCenter;
						this.send(tosend, delay, CloudSimTags.Network_Event_DOWN, hspkt);
//						System.out.println(this.getName()+"send packet"+CloudSim.clock());
					}
					hspktlist.clear();
				}
			}
		}
	}
	
	protected void recoveryCloudletPointSend(SimEvent ev){
		NetworkResCloudlet nrcl = (NetworkResCloudlet)ev.getData();
		
		CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.Network_Event_send));
		schedule(getId(), 0, CloudSimTags.Network_Event_send);
		
		long finishedSoFar = 0;
		if(cloudletCheckpointCenter.containsKey(nrcl)){
			finishedSoFar = cloudletCheckpointCenter.get(nrcl).getFinishedSoFar();

			RecordToLogger.logger.debug(this.getName()+"|"+nrcl.getCloudletId()+" move to "+nrcl.getVm().getHost().getId()+" restart from "+finishedSoFar);

		}
//		System.out.println(this.getName()+"|"+nrcl.getCloudletId()+" move to "+nrcl.getVm().getHost().getId()+" restart from "+finishedSoFar);
	
		CloudletCheckpoint ckp = new CloudletCheckpoint(nrcl,NetworkConstants.SYSTEM_CHECKPOINT,finishedSoFar, 1024);
		HostPacket pkt = new HostPacket(
				NetworkConstants.RECOVERY_CLOUDLIT,
				this.getId(),
				nrcl.getVm().getHost().getId(),
				-1, 
				nrcl.getVm().getId(),
				nrcl.getCloudletId(),
				CloudSim.clock(),
				-1,
				ckp);
		NetworkPacket npkt = new NetworkPacket(pkt);
		
		List<NetworkPacket> pktlist = downlinkswitchpktlist.get(downlinkswitches.get(0).getId());
		if (pktlist == null) {
			pktlist = new ArrayList<NetworkPacket>();
		}
		pktlist.add(npkt);
		downlinkswitchpktlist.put(downlinkswitches.get(0).getId(), pktlist);
	}
	
	protected void recoveryAppPointSend(SimEvent ev){
		NetworkResCloudlet nrcl = (NetworkResCloudlet)ev.getData();
		NetworkCloudlet nc = (NetworkCloudlet)nrcl.getCloudlet();
		
		CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.Network_Event_send));
		schedule(getId(), 0, CloudSimTags.Network_Event_send);
		
		long finishedSoFar = 0;
		if(appCheckpointCenter.containsKey(nc.belongToApp)){
			finishedSoFar = appCheckpointCenter.get(nc.belongToApp).getFinishedSoFar();
//			System.out.println(nrcl.getCloudletId()+" move to "+nrcl.getVm().getHost().getId()+" restart from "+finishedSoFar);
		}
		
		AppCheckpoint ckp = new AppCheckpoint(nc.belongToApp,finishedSoFar, 2048);
		ckp.setActiveCloudlet(nrcl);
		HostPacket pkt = new HostPacket(
				NetworkConstants.RECOVERY_CLOUDLIT,
				this.getId(),
				nrcl.getVm().getHost().getId(),
				-1, 
				nrcl.getVm().getId(),
				nrcl.getCloudletId(),
				CloudSim.clock(),
				-1,
				ckp);
		NetworkPacket npkt = new NetworkPacket(pkt);
		
		List<NetworkPacket> pktlist = downlinkswitchpktlist.get(downlinkswitches.get(0).getId());
		if (pktlist == null) {
			pktlist = new ArrayList<NetworkPacket>();
			downlinkswitchpktlist.put(downlinkswitches.get(0).getId(), pktlist);
		}
		pktlist.add(npkt);
	}
	
	protected void appPointFetchAck(SimEvent ev){
		AppNetCloudlet acl = (AppNetCloudlet)ev.getData();
		
		if(!appCheckpointCenter.containsKey(acl))
			return;
		
		CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.Network_Event_send));
		schedule(getId(), 0, CloudSimTags.Network_Event_send);
		
		long finishedSoFar = 0;
		finishedSoFar = appCheckpointCenter.get(acl).getFinishedSoFar();
//		System.out.println(nrcl.getCloudletId()+" move to "+nrcl.getVm().getHost().getId()+" restart from "+finishedSoFar);
	
		
		AppCheckpoint ckp = new AppCheckpoint(acl,finishedSoFar, 1024);
		HostPacket pkt = new HostPacket(
				NetworkConstants.STORE_CHECKPOINT,
				this.getId(),
				ev.getSource(),
				-1, 
				-1,
				acl.appId,
				CloudSim.clock(),
				-1,
				ckp);
		NetworkPacket npkt = new NetworkPacket(pkt);
		
		List<NetworkPacket> pktlist = downlinkswitchpktlist.get(downlinkswitches.get(0).getId());
		if (pktlist == null) {
			pktlist = new ArrayList<NetworkPacket>();
			downlinkswitchpktlist.put(downlinkswitches.get(0).getId(), pktlist);
		}
		pktlist.add(npkt);
	}
	
	protected void restartCloulet(SimEvent ev){
		NetworkResCloudlet nrcl = (NetworkResCloudlet)ev.getData();
		NetworkCloudlet nc = (NetworkCloudlet)nrcl.getCloudlet();
		
		
		CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.Network_Event_send));
		schedule(getId(), 0, CloudSimTags.Network_Event_send);
		
		RecordToLogger.logger.debug(this.getName() + "|cloudlet" + nc.getCloudletId() + " will be restarted");
		
		long finishedSoFar = 0;
		
		AppCheckpoint ckp = new AppCheckpoint(nc.belongToApp, finishedSoFar, nc.belongToApp.baseSystemSize);
		ckp.setActiveCloudlet(nrcl);
		
		HostPacket pkt = new HostPacket(
				NetworkConstants.RECOVERY_CLOUDLIT,
				this.getId(),
				nrcl.getVm().getHost().getId(),
				-1, 
				nrcl.getVm().getId(),
				nrcl.getCloudletId(),
				CloudSim.clock(),
				-1,
				ckp);
		NetworkPacket npkt = new NetworkPacket(pkt);
		
		List<NetworkPacket> pktlist = downlinkswitchpktlist.get(downlinkswitches.get(0).getId());
		if (pktlist == null) {
			pktlist = new ArrayList<NetworkPacket>();
			downlinkswitchpktlist.put(downlinkswitches.get(0).getId(), pktlist);
		}
		pktlist.add(npkt);
	}

	@Override
	public void accept(DCNetworkVisitor visitor, Object data) {
		// TODO Auto-generated method stub
		
	}

	public Map<Integer, EdgeSwitch> getStorageEdgeSwitch() {
		return storageEdgeSwitch;
	}

	public void setStorageEdgeSwitch(Map<Integer, EdgeSwitch> storageEdgeSwitch) {
		this.storageEdgeSwitch = storageEdgeSwitch;
	}
	

}
