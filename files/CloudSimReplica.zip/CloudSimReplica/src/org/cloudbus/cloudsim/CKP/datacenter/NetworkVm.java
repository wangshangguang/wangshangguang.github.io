/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package org.cloudbus.cloudsim.CKP.datacenter;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.cloudbus.cloudsim.CloudletScheduler;
import org.cloudbus.cloudsim.ResCloudlet;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.CKP.datacenter.service.NetworkCloudlet;
import org.cloudbus.cloudsim.core.CloudSim;

/**
 * NetworkVm class extends Vm to support simulation of networked datacenters. It executes actions
 * related to management of packets (send and receive).
 * 
 * Please refer to following publication for more details:
 * 
 * Saurabh Kumar Garg and Rajkumar Buyya, NetworkCloudSim: Modelling Parallel Applications in Cloud
 * Simulations, Proceedings of the 4th IEEE/ACM International Conference on Utility and Cloud
 * Computing (UCC 2011, IEEE CS Press, USA), Melbourne, Australia, December 5-7, 2011.
 * 
 * @author Saurabh Kumar Garg
 * @since CloudSim Toolkit 3.0
 */
public class NetworkVm extends Vm implements Comparable<Object> {
	private NetworkHost host;
	private  List<Double> utilizationHistory = new LinkedList<Double>();
	
	public boolean isFailed=false;
	public static final int HISTORY_LENGTH = 30;
	/** The previous time. */
	private double previousTime;

	/** The scheduling interval. */
	private double schedulingInterval;
	
	public NetworkVm(
			String name,
			int userId,
			double mips,
			int pesNumber,
			int ram,
			long bw,
			long size,
			String vmm,
			CloudletScheduler cloudletScheduler,
			int type) {
		super(name,userId, mips, pesNumber, ram, bw, size, vmm, cloudletScheduler);
		setSchedulingInterval(schedulingInterval);
		cloudletlist = new ArrayList<NetworkCloudlet>();
		setType(type);
		this.setApp_type(-1);
	}

	public ArrayList<NetworkCloudlet> cloudletlist;

	public int type;          //������������ͣ��Ƿ�Ϊ���������  0 ��ʾ�Ǳ�������� 1 ��ʾ��������� -1 ��ʾδʹ�õ������

	public int app_type;      //����������ķ�������
	
	public ArrayList<HostPacket> recvPktlist;

	public double memory;

	public boolean flagfree;// if true it is free

	public double finishtime;

	public boolean isFree() {
		return flagfree;
	}

	public NetworkHost getHost() {
		return host;
	}
	public void setType(int type){
		this.type=type;
	}
	public int getType(){
		return type;
	}

	public void setHost(NetworkHost host) {
		this.host = host;
	}


	@Override
	public int compareTo(Object arg0) {
		NetworkVm hs = (NetworkVm) arg0;
		if (hs.finishtime > finishtime) {
			return -1;
		}
		if (hs.finishtime < finishtime) {
			return 1;
		}
		return 0;
	}
	
//	public double getUtilizationMad() {
//		double mad = 0;
//		if (!getUtilizationHistory().isEmpty()) {
//			int n = HISTORY_LENGTH;
//			if (HISTORY_LENGTH > getUtilizationHistory().size()) {
//				n = getUtilizationHistory().size();
//			}
//			double median = MathUtil.median(getUtilizationHistory());
//			List<Double> deviationSum = null ;
//			for (int i = 0; i < n; i++) {
//				deviationSum.add(Math.abs(median - getUtilizationHistory().get(i)));
//			}
//			mad = MathUtil.median(deviationSum);
//		}
//		return mad;
//	}

	/**
	 * Gets the utilization mean in percents.
	 * 
	 * @return the utilization mean in MIPS
	 */
	public double getUtilizationMean() {
		double mean = 0;
		if (!getUtilizationHistory().isEmpty()) {
			int n = HISTORY_LENGTH;
			if (HISTORY_LENGTH > getUtilizationHistory().size()) {
				n = getUtilizationHistory().size();
			}
			for (int i = 0; i < n; i++) {
				mean += getUtilizationHistory().get(i);
			}
			mean /= n;
		}
		return mean * getMips();
	}

	/**
	 * Gets the utilization variance in MIPS.
	 * 
	 * @return the utilization variance in MIPS
	 */
	public double getUtilizationVariance() {
		double mean = getUtilizationMean();
		double variance = 0;
		if (!getUtilizationHistory().isEmpty()) {
			int n = HISTORY_LENGTH;
			if (HISTORY_LENGTH > getUtilizationHistory().size()) {
				n = getUtilizationHistory().size();
			}
			for (int i = 0; i < n; i++) {
				double tmp = getUtilizationHistory().get(i) * getMips() - mean;
				variance += tmp * tmp;
			}
			variance /= n;
		}
		return variance;
	}
	
	@Override
	public double updateVmProcessing(final double currentTime, final List<Double> mipsShare) {
		double time = super.updateVmProcessing(currentTime, mipsShare);
		if (currentTime > getPreviousTime() && (currentTime - 0.1) % getSchedulingInterval() == 0) {
			double utilization = getTotalUtilizationOfCpu(getCloudletScheduler().getPreviousTime());
			if (CloudSim.clock() != 0 || utilization != 0) {
				addUtilizationHistoryValue(utilization);
			}
			setPreviousTime(currentTime);
		}
		return time;
	}
	public void addUtilizationHistoryValue(final double utilization) {
		getUtilizationHistory().add(0, utilization);
		if (getUtilizationHistory().size() > HISTORY_LENGTH) {
			getUtilizationHistory().remove(HISTORY_LENGTH);
		}
	}
	protected List<Double> getUtilizationHistory() {
		return utilizationHistory;
	}
	public double getPreviousTime() {
		return previousTime;
	}

	/**
	 * Sets the previous time.
	 * 
	 * @param previousTime the new previous time
	 */
	public void setPreviousTime(final double previousTime) {
		this.previousTime = previousTime;
	}

	/**
	 * Gets the scheduling interval.
	 * 
	 * @return the schedulingInterval
	 */
	public double getSchedulingInterval() {
		return schedulingInterval;
	}

	/**
	 * Sets the scheduling interval.
	 * 
	 * @param schedulingInterval the schedulingInterval to set
	 */
	protected void setSchedulingInterval(final double schedulingInterval) {
		this.schedulingInterval = schedulingInterval;
	}

	public void setFailed(boolean flag) {
		this.isFailed=flag;
		// TODO Auto-generated method stub
		
	}
	public boolean isFailed(){
		return isFailed;
	}
	
	public int getApp_type() {
		return app_type;
	}

	public void setApp_type(int app_type) {
		this.app_type = app_type;
	}

	public void updateVmsProcessingBeforeFailure(double clock) {
		
		NetworkCloudletSpaceSharedScheduler scheduler = (NetworkCloudletSpaceSharedScheduler)this.getCloudletScheduler();
		for (ResCloudlet rcl : scheduler.getCloudletExecList()){
				NetworkResCloudlet nrcl = (NetworkResCloudlet)rcl;
				nrcl.setPreviousTime(CloudSim.clock());
		
		// TODO Auto-generated method stub
		}
	}
}
