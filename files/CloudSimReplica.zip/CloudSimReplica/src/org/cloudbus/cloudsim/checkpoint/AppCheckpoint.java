package org.cloudbus.cloudsim.checkpoint;

import org.cloudbus.cloudsim.CKP.datacenter.Data;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkResCloudlet;
import org.cloudbus.cloudsim.CKP.datacenter.service.AppNetCloudlet;
import org.cloudbus.cloudsim.CKP.datacenter.service.NetworkCloudlet;
import org.cloudbus.cloudsim.network.datacenter.AppCloudlet;

public class AppCheckpoint extends Data{
	private long finishedSoFar;
	
	private AppNetCloudlet appCloudlet;
	
	private NetworkResCloudlet activeCloudlet;

	public AppCheckpoint(AppNetCloudlet appCloudlet, long finishedSoFar, double size) {
		super(size);
		this.appCloudlet = appCloudlet;
		this.finishedSoFar = finishedSoFar;
	}

	public long getFinishedSoFar() {
		return finishedSoFar;
	}

	public void setFinishedSoFar(long finishedSoFar) {
		this.finishedSoFar = finishedSoFar;
	}

	public AppNetCloudlet getAppCloudlet() {
		return appCloudlet;
	}

	public void setAppCloudlet(AppNetCloudlet appCloudlet) {
		this.appCloudlet = appCloudlet;
	}
	

	public NetworkResCloudlet getActiveCloudlet() {
		return activeCloudlet;
	}

	public void setActiveCloudlet(NetworkResCloudlet activeCloudlet) {
		this.activeCloudlet = activeCloudlet;
	}


}
