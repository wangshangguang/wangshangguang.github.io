package org.cloudbus.cloudsim.checkpoint;

import org.apache.log4j.Logger;

public class RecordToLogger {
	public static Logger logger = Logger.getLogger(RecordToLogger.class.getName());

}
