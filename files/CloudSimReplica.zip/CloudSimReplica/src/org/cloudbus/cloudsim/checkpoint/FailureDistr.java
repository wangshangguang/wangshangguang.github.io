package org.cloudbus.cloudsim.checkpoint;

public interface FailureDistr {
	
	public double reliabilityCalculation(double lastFailureTime, double currentTime);

}
