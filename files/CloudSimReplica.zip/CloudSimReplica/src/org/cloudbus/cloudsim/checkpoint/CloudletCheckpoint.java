package org.cloudbus.cloudsim.checkpoint;

import org.cloudbus.cloudsim.CKP.datacenter.Data;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkResCloudlet;



public class CloudletCheckpoint extends Data {
	private int type;

	private long finishedSoFar;
	
	private NetworkResCloudlet resCloudlet;
	
	public CloudletCheckpoint(NetworkResCloudlet resCloudlet, int type, long finishedSoFar,double size){
		super(size);
		this.finishedSoFar = finishedSoFar;
		this.resCloudlet = resCloudlet;
		this.type = type;
		
	}
	
	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public long getFinishedSoFar() {
		return finishedSoFar;
	}

	public void setFinishedSoFar(long finishedSoFar) {
		this.finishedSoFar = finishedSoFar;
	}

	public NetworkResCloudlet getResCloudlet() {
		return resCloudlet;
	}

	public void setResCloudlet(NetworkResCloudlet resCloudlet) {
		this.resCloudlet = resCloudlet;
	}


}
