package org.cloudbus.cloudsim.checkpoint;

import org.cloudbus.cloudsim.CKP.datacenter.NetworkDatacenter;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkDatacenterCharacteristics;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkHost;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkResCloudlet;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkStorageHost;
import org.cloudbus.cloudsim.CKP.datacenter.service.NetworkCloudlet;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEvent;

public class ReplicaInvoker extends RecoveryInvoker {
	protected NetworkDatacenter datacenter;
	
	public ReplicaInvoker(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	public NetworkDatacenter getDatacenter() {
		return datacenter;
	}

	public void setDatacenter(NetworkDatacenter datacenter) {
		this.datacenter = datacenter;
	}

	@Override
	public void recoveryInvoke(NetworkResCloudlet nrcl, NetworkHost targetHost) {
		NetworkCloudlet cloudlet = (NetworkCloudlet)nrcl.getCloudlet();	
		NetworkDatacenterCharacteristics chara = (NetworkDatacenterCharacteristics)datacenter.getCharacteristics();
		NetworkStorageHost storageCenter = chara.getDatacenternetwork().getStorageCenter();
		
			cloudlet.hasCloudletSystemImage = false;
			cloudlet.lastFinishedSoFar = 0;
			nrcl.setCloudletFinishedSoFar(0);
			send(storageCenter.getId(), 0, CloudSimTags.RESTART_CLOULET, nrcl);	
		
	}

	@Override
	public void startEntity() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void processEvent(SimEvent ev) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void shutdownEntity() {
		// TODO Auto-generated method stub
		
	}
	


}
