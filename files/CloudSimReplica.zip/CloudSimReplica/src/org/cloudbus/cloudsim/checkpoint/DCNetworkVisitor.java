package org.cloudbus.cloudsim.checkpoint;

import org.cloudbus.cloudsim.CKP.datacenter.AggregateSwitch;
import org.cloudbus.cloudsim.CKP.datacenter.DCNetwork;
import org.cloudbus.cloudsim.CKP.datacenter.DataCenterLink;
import org.cloudbus.cloudsim.CKP.datacenter.DataCenterNode;
import org.cloudbus.cloudsim.CKP.datacenter.EdgeSwitch;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkHost;
import org.cloudbus.cloudsim.CKP.datacenter.RootSwitch;


public interface DCNetworkVisitor {
	
	public void visit(DataCenterNode n, Object data);
	
	public void visit(DataCenterLink e, Object data);
	
	public void visit(DCNetwork g, Object data);
	
	public void visit(RootSwitch n, Object data);
	
	public void visit(AggregateSwitch n, Object data);
	
	public void visit(EdgeSwitch n, Object data);
	
	public void visit(NetworkHost n, Object data);
	

}
