package org.cloudbus.cloudsim.checkpoint;

import java.util.Random;


public class ExponentialFailureDistr implements FailureDistr {
	
	/** The mean. */
	private final double mean;
	
	private final Random numGen;

	public ExponentialFailureDistr(double mean) {
		numGen = new Random(System.currentTimeMillis());
		this.mean = mean;
	}

	@Override
	public double reliabilityCalculation(double lastFailureTime, double currentTime) {
		// TODO Auto-generated method stub
		return Math.pow(Math.E, -mean*(currentTime - lastFailureTime));
	}
	
	public double sample() {
		return -mean * Math.log(numGen.nextDouble());
	}

}
