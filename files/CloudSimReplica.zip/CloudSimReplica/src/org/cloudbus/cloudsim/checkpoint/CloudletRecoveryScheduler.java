package org.cloudbus.cloudsim.checkpoint;

import org.cloudbus.cloudsim.CKP.datacenter.NetworkDatacenter;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkHost;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkVm;




public abstract class  CloudletRecoveryScheduler  {
	private NetworkDatacenter datacenter;
	private String name;


	public CloudletRecoveryScheduler(String name){
		setName(name);
	}
	
	public NetworkDatacenter getDatacenter() {
		return datacenter;
	}

	public void setDatacenter(NetworkDatacenter datacenter) {
		this.datacenter = datacenter;
	}
	public  abstract void recovery(NetworkHost host);

	public abstract void vmrecovery(NetworkVm vm) ;
	
	protected String getName() {
		return name;
	}

	protected void setName(String name) {
		this.name = name;
	}

	
	
}