/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package org.cloudbus.cloudsim.checkpoint.centralexample;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.StringTokenizer;

import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelFull;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkConstants;
import org.cloudbus.cloudsim.CKP.datacenter.service.AppNetCloudlet;
import org.cloudbus.cloudsim.CKP.datacenter.service.NetworkCloudlet;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.distributions.UniformDistr;

/**
 * This class is just an file-reader for the special brite-format! the brite-file is structured as
 * followed: Node-section: NodeID, xpos, ypos, indegree, outdegree, ASid, type(router/AS)
 * Edge-section: EdgeID, fromNode, toNode, euclideanLength, linkDelay, linkBandwith, AS_from, AS_to,
 * type
 * 
 * @author Thomas Hohnstein
 * @since CloudSim Toolkit 1.0
 */
public class WorkloadReader {

	/**
	 * this method just reads the file and creates an TopologicalGraph object
	 * 
	 * @param filename name of the file to read
	 * @return created TopologicalGraph
	 * @throws IOException
	 */
	public static ArrayList<AppNetCloudlet> readWorkLoadFile(String filename, int userId,ArrayList<AppNetCloudlet> apps) throws IOException {

		// lets read the file
		FileReader fr = new FileReader(filename);
		BufferedReader br = new BufferedReader(fr);

		String nextLine = null;
		
		long length = 0;
		long fileSize = 0;
		long outputSize = 0;
		long memory = 0;
		int pesNumber = 0;
		long deadline=0;
		int appid=-1;
		UtilizationModel utilizationModelCPU = null;
		UtilizationModel utilizationModelRAM = null;
		UtilizationModel utilizationModelBW = null;
		double totalLength = 0;
		int count=0;
		
		UniformDistr uniformDistrDiskSize = new UniformDistr(500, 502, System.currentTimeMillis());

		while ((nextLine = br.readLine()) != null) {
//			if(nextLine.startsWith("//") || nextLine.startsWith("%%") || nextLine.trim().equals(""))
//				continue;			
			

				StringTokenizer tokenizer = new StringTokenizer(nextLine);
				
				for (int actualParam = 0; tokenizer.hasMoreElements() && actualParam < 10; actualParam++) {
					String token = tokenizer.nextToken();
					switch (actualParam) {
						case 0:	
							length = Long.valueOf(token);
							break;	
						case 1:	
							pesNumber = Integer.valueOf(token);
							break;	
						case 2:	
							fileSize = Long.valueOf(token);
							break;
						case 3:	
							outputSize = Long.valueOf(token);
							break;
						case 4:	
							memory = Long.valueOf(token);
							break;
						case 5:	
							utilizationModelCPU = generateUtilizationModel(token);
							break;
						case 6:	
							utilizationModelRAM =  generateUtilizationModel(token);
							break;
						case 7:
							utilizationModelBW =  generateUtilizationModel(token);
							break;
						case 8:
							deadline=Long.valueOf(token);
							break;
						case 9:
							appid=Integer.valueOf(token);
							break;
					}
				}
				AppNetCloudlet tmpapp=null;
				for(AppNetCloudlet app:apps){
					if(appid==app.appId){
						tmpapp=app;
						break;
					}
				}
				if(tmpapp==null){
					tmpapp = new AppNetCloudlet(appid, 0, 769+5.3+1.6+512,uniformDistrDiskSize.sample());
					apps.add(tmpapp);
				}		 
				NetworkCloudlet  cloudlet = new NetworkCloudlet(NetworkConstants.currentCloudletId,
						length,
						pesNumber,
						fileSize,
						outputSize,
						memory,
						appid,
						utilizationModelCPU,
						utilizationModelRAM,
						utilizationModelBW,
						tmpapp);
				tmpapp.addCloudlet(cloudlet);
				count++;
				cloudlet.setUserId(tmpapp.userID);
				NetworkConstants.currentCloudletId++;
				
				totalLength = totalLength + length;
				
				
		}
		
		
		br.close();
//		System.out.println("total length: "+totalLength);
//		System.out.println("add cloudlet "+count);
		CreateNextReadTextPoolC(filename);
		return apps;
	}
	
	private static void CreateNextReadTextPoolA( String filename){
		try {
			FileWriter fw = new FileWriter(filename);
			BufferedWriter bw=new BufferedWriter(fw);

			for(int i=0;i<50;i++){
				UniformDistr ufrnd = new UniformDistr(1, 1000, (long)CloudSim.clock());
				int tag=(int) ufrnd.sample();
				int length=0;
				if(tag<362){
					UniformDistr ufrnd1 = new UniformDistr(60, 90);
					length=(int)ufrnd1.sample();
				}
				else if(tag<511){
					UniformDistr ufrnd1 = new UniformDistr(90, 120);
					length=(int)ufrnd1.sample();
				}	
				else if(tag<582){
					UniformDistr ufrnd1 = new UniformDistr(120, 150);
					length=(int)ufrnd1.sample();
				}
				else if(tag<643){
					UniformDistr ufrnd1 = new UniformDistr(150, 180);
					length=(int)ufrnd1.sample();
				}
				else if(tag<694){
					UniformDistr ufrnd1 = new UniformDistr(180, 210);
					length=(int)ufrnd1.sample();
				}
				else if(tag<737){
					UniformDistr ufrnd1 = new UniformDistr(210, 240);
					length=(int)ufrnd1.sample();
				}
				else if(tag<774){
					UniformDistr ufrnd1 = new UniformDistr(240, 270);
					length=(int)ufrnd1.sample();
				}
				else if(tag<806){
					UniformDistr ufrnd1 = new UniformDistr(270, 300);
					length=(int)ufrnd1.sample();
				}
				else if(tag<833){
					UniformDistr ufrnd1 = new UniformDistr(300, 330);
					length=(int)ufrnd1.sample();
				}
				else if(tag<857){
					UniformDistr ufrnd1 = new UniformDistr(330, 360);
					length=(int)ufrnd1.sample();
				}
				else if(tag<879){
					UniformDistr ufrnd1 = new UniformDistr(360, 390);
					length=(int)ufrnd1.sample();
				}
				else if(tag<1000){
					UniformDistr ufrnd1 = new UniformDistr(390, 600);
					length=(int)ufrnd1.sample();
				}
				int deadline=(int)((int)length*3);
				UniformDistr ufrnd2 = new UniformDistr(0, 511);
				int appid =(int)ufrnd2.sample();
				bw.write(length*100+" 1 300 300 512 1 1 full "+deadline+'\t'+appid+"\n");
			}
			bw.flush();
			fw.close();
			bw.close();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private static void CreateNextReadTextPoolC( String filename){
		try {
			FileWriter fw = new FileWriter(filename);
			BufferedWriter bw=new BufferedWriter(fw);

			for(int i=0;i<50;i++){
				UniformDistr ufrnd = new UniformDistr(1, 1000, (long)CloudSim.clock());
				int tag=(int) ufrnd.sample();
				int length=0;
				if(tag<243){
					UniformDistr ufrnd1 = new UniformDistr(60, 90);
					length=(int)ufrnd1.sample();
				}
				else if(tag<402){
					UniformDistr ufrnd1 = new UniformDistr(90, 120);
					length=(int)ufrnd1.sample();
				}	
				else if(tag<509){
					UniformDistr ufrnd1 = new UniformDistr(120, 150);
					length=(int)ufrnd1.sample();
				}
				else if(tag<586){
					UniformDistr ufrnd1 = new UniformDistr(150, 180);
					length=(int)ufrnd1.sample();
				}
				else if(tag<648){
					UniformDistr ufrnd1 = new UniformDistr(180, 210);
					length=(int)ufrnd1.sample();
				}
				else if(tag<696){
					UniformDistr ufrnd1 = new UniformDistr(210, 240);
					length=(int)ufrnd1.sample();
				}
				else if(tag<736){
					UniformDistr ufrnd1 = new UniformDistr(240, 270);
					length=(int)ufrnd1.sample();
				}
				else if(tag<771){
					UniformDistr ufrnd1 = new UniformDistr(270, 300);
					length=(int)ufrnd1.sample();
				}
				else if(tag<814){
					UniformDistr ufrnd1 = new UniformDistr(300, 330);
					length=(int)ufrnd1.sample();
				}
				else if(tag<842){
					UniformDistr ufrnd1 = new UniformDistr(330, 360);
					length=(int)ufrnd1.sample();
				}
				else if(tag<866){
					UniformDistr ufrnd1 = new UniformDistr(360, 390);
					length=(int)ufrnd1.sample();
				}
				else if(tag<1000){
					UniformDistr ufrnd1 = new UniformDistr(390, 600);
					length=(int)ufrnd1.sample();
				}
				int deadline=(int)((int)length*3);
				UniformDistr ufrnd2 = new UniformDistr(0, 511);
				int appid =(int)ufrnd2.sample();
				bw.write(length*100+" 1 300 300 512 1 1 full "+deadline+'\t'+appid+"\n");
			}
			bw.flush();
			fw.close();
			bw.close();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private static void CreateNextReadText( String filename){
		try {
			FileWriter fw = new FileWriter(filename);
			BufferedWriter bw=new BufferedWriter(fw);

			for(int i=0;i<50;i++){
				UniformDistr ufrnd = new UniformDistr(1, 1000, (long)CloudSim.clock());
				int tag=(int) ufrnd.sample();
				int length=0;
				if(tag<267){
					UniformDistr ufrnd1 = new UniformDistr(60, 90);
					length=(int)ufrnd1.sample();
				}
				else if(tag<418){
					UniformDistr ufrnd1 = new UniformDistr(90, 120);
					length=(int)ufrnd1.sample();
				}	
				else if(tag<549){
					UniformDistr ufrnd1 = new UniformDistr(120, 150);
					length=(int)ufrnd1.sample();
				}
				else if(tag<655){
					UniformDistr ufrnd1 = new UniformDistr(150, 180);
					length=(int)ufrnd1.sample();
				}
				else if(tag<728){
					UniformDistr ufrnd1 = new UniformDistr(180, 210);
					length=(int)ufrnd1.sample();
				}
				else if(tag<767){
					UniformDistr ufrnd1 = new UniformDistr(210, 240);
					length=(int)ufrnd1.sample();
				}
				else if(tag<800){
					UniformDistr ufrnd1 = new UniformDistr(240, 270);
					length=(int)ufrnd1.sample();
				}
				else if(tag<827){
					UniformDistr ufrnd1 = new UniformDistr(270, 300);
					length=(int)ufrnd1.sample();
				}
				else if(tag<864){
					UniformDistr ufrnd1 = new UniformDistr(300, 330);
					length=(int)ufrnd1.sample();
				}
				else if(tag<885){
					UniformDistr ufrnd1 = new UniformDistr(330, 360);
					length=(int)ufrnd1.sample();
				}
				else if(tag<903){
					UniformDistr ufrnd1 = new UniformDistr(360, 390);
					length=(int)ufrnd1.sample();
				}
				else if(tag<1000){
					UniformDistr ufrnd1 = new UniformDistr(390, 600);
					length=(int)ufrnd1.sample();
				}
				int deadline=(int)((int)length*3);
				UniformDistr ufrnd2 = new UniformDistr(0, 511);
				int appid =(int)ufrnd2.sample();
				bw.write(length*100+" 1 300 300 512 1 1 full "+deadline+'\t'+appid+"\n");
			}
			bw.flush();
			fw.close();
			bw.close();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static UtilizationModel generateUtilizationModel(String token){
		if(token.equals("full"))
			return  new UtilizationModelFull();
		return new UtilizationModelFull();
	}

}
