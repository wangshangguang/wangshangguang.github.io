package org.cloudbus.cloudsim;

/**
 * 
 * Defines common constants, used throughout cloudsim.
 * 
 * @author nikolay.grozev
 *
 */
public final class Consts {

    /**
     * Suppreses intantiation.
     */
    private Consts(){}
//yang  1000000->1    
    public static int MILLION = 1;
}
