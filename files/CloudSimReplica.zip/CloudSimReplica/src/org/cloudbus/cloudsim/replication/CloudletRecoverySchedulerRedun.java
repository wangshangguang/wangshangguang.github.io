package org.cloudbus.cloudsim.replication;


import java.util.List;
import java.util.Random;

import org.cloudbus.cloudsim.ResCloudlet;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.CKP.datacenter.AggregateSwitch;
import org.cloudbus.cloudsim.CKP.datacenter.Config;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkCloudletSpaceSharedScheduler;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkDatacenter;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkHost;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkResCloudlet;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkVm;
import org.cloudbus.cloudsim.CKP.datacenter.RootSwitch;
import org.cloudbus.cloudsim.CKP.datacenter.service.AppNetCloudlet;
import org.cloudbus.cloudsim.CKP.datacenter.service.NetworkCloudlet;
import org.cloudbus.cloudsim.checkpoint.CloudletRecoveryScheduler;
import org.cloudbus.cloudsim.checkpoint.RecordToLogger;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;

public class CloudletRecoverySchedulerRedun  extends CloudletRecoveryScheduler{
	private NetworkDatacenter datacenter;
	
	public CloudletRecoverySchedulerRedun(String name){
		super(name);
	}
	
	public NetworkDatacenter getDatacenter() {
		return datacenter;
	}

	public void setDatacenter(NetworkDatacenter datacenter) {
		this.datacenter = datacenter;
	}


	public void recovery(NetworkHost host){
		
		setDatacenter((NetworkDatacenter)host.getDatacenter());
		RecordToLogger.logger.info(this.getName() + "| host " + host.getId()+" fail");
		
		host.updateVmsProcessingBeforeFailure(CloudSim.clock());
		
		host.allocatedCKPStorage = 0;
		
		List<Vm> vms = host.getVmList();
		for(int i = 0 ; i < vms.size(); i++){
			NetworkVm  nvm = (NetworkVm)vms.get(i);
			int type=nvm.getType();
			
			NetworkCloudletSpaceSharedScheduler oldscheduler = 
					(NetworkCloudletSpaceSharedScheduler)nvm.getCloudletScheduler();
//			VmAllocationPolicy vmallocationpolicy=getDatacenter().getVmAllocationPolicy();
//			int userId=nvm.getUserId();
//			int vmid = nvm.getId()+50;
//			int mips = 5;
//			long size = 100000; // image size (MB)
//			int ram = 512; // vm memory (MB)
//			long bw = 1000;
//			int pesNumber = NetworkConstants.HOST_PEs / NetworkConstants.maxhostVM;
//			String vmm = "Xen"; // VMM name
//			int type=nvm.getType();
//			NetworkCloudletSpaceSharedScheduler newscheduler = new NetworkCloudletSpaceSharedScheduler();
//			NetworkVm vm = new NetworkVm(
//					vmid,
//					userId,
//					mips,
//					pesNumber,
//					ram,
//					bw,
//					size,
//					vmm,
//					newscheduler,type);
//			// add the VM to the vmList
//			vmallocationpolicy.allocateHostForVm(vm);
//			newscheduler.setVm(vm);
//			NetDatacenterBroker broker=(NetDatacenterBroker)CloudSim.getEntity(215);
//			broker.getVmList().add(vm);
//			broker.getVmsToDatacentersMap().put(vmid, datacenter.getId());
//			broker.getVmsCreatedList().add(VmList.getById(broker.getVmList(), vmid));
//			host=vm.getHost();
//			host.getVmList().add(vm);

			List<NetworkHost> hosts = nvm.getHost().sw.getHostFromTheSameSubnet(host);				
			AggregateSwitch as = (AggregateSwitch)host.sw.uplinkswitches.get(0);
			RootSwitch rs = (RootSwitch)as.uplinkswitches.get(0);
			List<NetworkHost> hosts1 = as.getHostFromOtherSubnet(host);
			List<NetworkHost> hosts2 = rs.getHostFromOtherPad(host);
			hosts.addAll(hosts1);
			hosts.addAll(hosts2);
			for(int j=0;j<hosts.size();j++){
				if(hosts.get(j).isFailed())
					hosts.remove(hosts.get(j));
			}
			NetworkVm targetvm=null;
			mark:
			for(int j=0;j<hosts.size();j++){
				NetworkHost tmphost=(NetworkHost)hosts.get(j);
				for(int k=0;k<tmphost.getVmList().size();k++){
					targetvm=(NetworkVm) tmphost.getVmList().get(k);
					if(targetvm.type==-1)
						continue;
					NetworkCloudletSpaceSharedScheduler nowscheduler = 
							(NetworkCloudletSpaceSharedScheduler)targetvm.getCloudletScheduler();
					if(targetvm.type==type&&nowscheduler.getCloudletWaitingList().size()<15){
						 break mark;
					}
				}
			}	
			mark1:
			for(int j=0;j<hosts.size();j++){
				NetworkHost tmphost=(NetworkHost)hosts.get(j);
				for(int k=0;k<tmphost.getVmList().size();k++){
					targetvm=(NetworkVm) tmphost.getVmList().get(k);
					if(targetvm.type==-1){
						targetvm.setType(nvm.type);
						break mark1;
						}						 
					}
			}
			
			if(oldscheduler.getCloudletExecList().size()!=0){
				for(ResCloudlet tmpcl:oldscheduler.getCloudletExecList())
					oldscheduler.getCloudletWaitingList().add(tmpcl);
			}
			if(oldscheduler.getCloudletWaitingList().size()!=0){
				for (int j=0;j<oldscheduler.getCloudletWaitingList().size();j++) {

					ResCloudlet rcl=oldscheduler.getCloudletWaitingList().get(j);
					NetworkResCloudlet nrcl = (NetworkResCloudlet)rcl;
					NetworkCloudlet cl = (NetworkCloudlet)nrcl.getCloudlet();				
					

					cl.lastSuspendTime = CloudSim.clock();
					RecordToLogger.logger.debug(this.getName() + "|" + cl.getCloudletId()+" should restart!");				
					NetworkHost targetHost = targetvm.getHost();
					
					nrcl.getCloudletState().restart();
					nrcl.setVm(targetvm);
			
					RecordToLogger.logger.info(this.getName() + "|" +cl.getCloudletId()+" move to host:"+ nrcl.getVm().getHost().getId()+" vm:"+nrcl.getVm().getId());

				
	//				int vm_id=oldscheduler.pktinfo.get(nrcl.getCloudletId());
	//				oldscheduler.pktinfo.remove(nrcl.getCloudletId());
					int[] newdata=new int[4];
					newdata[0]=nrcl.getCloudletId();
					newdata[1]=targetvm.getId();
					newdata[2]=targetHost.getId();
	//				newdata[3]=vm_id;
	//				RecordToLogger.logger.info(" cloudlet: "+cl.getCloudletId()+" vm id: "+vm_id);
	//				getDatacenter().dealCloudletRecover(newdata);
					
	//				ncs.getCloudletExecList().add(nrcl);									
	
				
					getDatacenter().getStorageindex().recoveryInvoke(nrcl, targetHost);
			
			
				}
			}
			oldscheduler.getCloudletExecList().clear();
			oldscheduler.getCloudletWaitingList().clear();
		}
		
		
	}

	public void vmrecovery(NetworkVm vm){
		NetworkHost host=vm.getHost();
		setDatacenter((NetworkDatacenter)host.getDatacenter());

		RecordToLogger.logger.info(this.getName() + "| vm " + vm.getId()+" fail");
		
		vm.updateVmsProcessingBeforeFailure(CloudSim.clock());
		
		NetworkVm targetvm=null;
		NetworkCloudletSpaceSharedScheduler oldscheduler = 
						(NetworkCloudletSpaceSharedScheduler)vm.getCloudletScheduler();


		if(oldscheduler.getCloudletExecList().size()!=0){
			for(ResCloudlet tmpcl:oldscheduler.getCloudletExecList())
				oldscheduler.getCloudletWaitingList().add(tmpcl);
		}
		if(oldscheduler.getCloudletWaitingList().size()!=0){
			NetworkResCloudlet  tmpnrcl = (NetworkResCloudlet)
					oldscheduler.getCloudletWaitingList().get(0);
			NetworkCloudlet tmpcl = (NetworkCloudlet)tmpnrcl.getCloudlet();
			AppNetCloudlet tmpapp=tmpcl.belongToApp;
			List<NetworkVm> sub_vm=tmpapp.getSubVmList();
			Random rand=new Random();
			int vm_index=rand.nextInt(sub_vm.size());
			targetvm=sub_vm.get(vm_index);
			targetvm.setType(1); 
			
			for (int j=0;j<oldscheduler.getCloudletWaitingList().size();j++) {
				NetworkResCloudlet  nrcl = (NetworkResCloudlet)
						oldscheduler.getCloudletWaitingList().get(j);
				NetworkCloudlet cl = (NetworkCloudlet)nrcl.getCloudlet();
				cl.lastSuspendTime = CloudSim.clock();
				RecordToLogger.logger.debug(this.getName() + "|" + cl.getCloudletId()+" should restart!");				
				
				nrcl.setVm(targetvm);
				nrcl.getCloudletState().restart();
			
				RecordToLogger.logger.info(this.getName() + "|" +cl.getCloudletId()+" move to host:"+ nrcl.getVm().getHost().getId()+" vm:"+nrcl.getVm().getId());
				NetworkHost targetHost=targetvm.getHost(); 	
				
				List<NetworkHost> hosts = vm.getHost().sw.getHostFromTheSameSubnet(host);				
				AggregateSwitch as = (AggregateSwitch)host.sw.uplinkswitches.get(0);
				hosts.addAll(as.getHostFromOtherSubnet(host));
	
				if(Config.isFocus)
					getDatacenter().schedule(host.getId(), 0,CloudSimTags.RECEIVE_STORE_INFO, cl);
				else 
					getDatacenter().schedule(host.getId(), 0,CloudSimTags.VM_DOWN_SEND_RECOVER_INFO , nrcl);
				
				
				getDatacenter().getStorageindex().recoveryInvoke(nrcl, targetHost);
		
		
			}
		}	
		oldscheduler.getCloudletExecList().clear();
		oldscheduler.getCloudletWaitingList().clear();
	}

	

}
