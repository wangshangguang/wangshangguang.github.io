package org.cloudbus.cloudsim.replication;

import org.cloudbus.cloudsim.CKP.datacenter.Data;
import org.cloudbus.cloudsim.CKP.datacenter.service.NetworkCloudlet;

public class SmallCloudletStorage extends Data{
	public SmallCloudletStorage(double size){
		super(size);
	}
	public NetworkCloudlet cloudlet;
	
	public NetworkCloudlet getCloudlet() {
		return cloudlet;
	}
	public void setCloudlet(NetworkCloudlet cloudlet) {
		this.cloudlet = cloudlet;
	}

}
