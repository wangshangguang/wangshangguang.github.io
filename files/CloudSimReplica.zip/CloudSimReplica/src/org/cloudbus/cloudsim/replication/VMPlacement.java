package org.cloudbus.cloudsim.replication;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.cloudbus.cloudsim.CKP.datacenter.AggregateSwitch;
import org.cloudbus.cloudsim.CKP.datacenter.Config;
import org.cloudbus.cloudsim.CKP.datacenter.EdgeSwitch;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkConstants;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkHost;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkVm;
import org.cloudbus.cloudsim.CKP.datacenter.Switch;
import org.cloudbus.cloudsim.core.CloudSim;

public class VMPlacement {

	public static void randPos(){

			Random rand=new Random();;
			int first_main_num=30;
			int first_backup_num=10;
		
		for(int j=0;j<NetworkConstants.app_count;j++){
			int portnum=Config.portNum;  			
			int port_id1=rand.nextInt(portnum)*portnum/2;
			AggregateSwitch aggsw=(AggregateSwitch)CloudSim.getEntity("aggregateswitch_1_"+port_id1);
			allocationVm(aggsw,first_main_num,first_backup_num,j);																											
		}
	}		

	public static void allocationVm(AggregateSwitch aggswitch , int main_num, int backup_num,int appType){
		Random rand = new Random();
		List<Switch> swlist=aggswitch.downlinkswitches;		
		
		List<NetworkHost> hostList  = new ArrayList<NetworkHost>();			
		for(Switch sw:swlist){
			EdgeSwitch esw=(EdgeSwitch)sw;

			if(esw.isStorageNode()){
				continue;
			}

			hostList.addAll(esw.hostlist.values());
		}

		int hostTotleNumber = hostList.size();
		while(main_num>0){
			int randHostId = rand.nextInt(hostTotleNumber);
			NetworkHost host = hostList.get(randHostId);
			NetworkVm vm=(NetworkVm)host.getVmList().get(0);
			if(vm.getType()!=-1)
				continue;
			for(int i=0;i<host.getVmList().size();i++){
				vm=(NetworkVm)host.getVmList().get(0);
				vm.setApp_type(appType);
				// 1 main; 0  backup;  -1 free
				vm.setType(1);	
			}																								
			main_num--;					
		}

		while(backup_num>0){
			int randHostId = rand.nextInt(hostTotleNumber);
			NetworkHost host = hostList.get(randHostId);
			NetworkVm vm=(NetworkVm)host.getVmList().get(0);
			if(vm.getType()!=-1)
				continue;
			for(int i=0;i<host.getVmList().size();i++){
				vm=(NetworkVm)host.getVmList().get(0);
				vm.setApp_type(appType);

				vm.setType(0);	
			}																				
			backup_num--;					
		}
	}
}
