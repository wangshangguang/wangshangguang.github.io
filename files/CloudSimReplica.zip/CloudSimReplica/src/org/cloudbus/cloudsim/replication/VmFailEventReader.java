package org.cloudbus.cloudsim.replication;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

/**
 * This class is just an file-reader for the special brite-format! the brite-file is structured as
 * followed: Node-section: NodeID, xpos, ypos, indegree, outdegree, ASid, type(router/AS)
 * Edge-section: EdgeID, fromNode, toNode, euclideanLength, linkDelay, linkBandwith, AS_from, AS_to,
 * type
 * 
 * @author Thomas Hohnstein
 * @since CloudSim Toolkit 1.0
 */
public class VmFailEventReader {

	/**
	 * this method just reads the file and creates an TopologicalGraph object
	 * 
	 * @param filename name of the file to read
	 * @return created TopologicalGraph
	 * @throws IOException
	 */
	public static void readFailureEventFile(String filename, VmDestroyer destroyer) throws IOException {

		// lets read the file
		FileReader fr = new FileReader(filename);
		BufferedReader br = new BufferedReader(fr);
		String nextLine = null;

		
		int hostid,vmid;
		String eventType;
		double timeOfOccurrence;
		String failureType;
		String failureParameter;
		double mean;
		double shape,scale;
		
		int failureFrequency;
		double lastFailureTime;

		while ((nextLine = br.readLine()) != null) {
			if(nextLine.startsWith("//"))
				continue;
			
			StringTokenizer tokenizer = new StringTokenizer(nextLine);
			
			if(tokenizer.hasMoreElements()){
				vmid = Integer.valueOf(tokenizer.nextToken());
				hostid = Integer.valueOf(tokenizer.nextToken());
				
//				failureFrequency = Integer.valueOf(tokenizer.nextToken());
				lastFailureTime = Double.valueOf(tokenizer.nextToken());
				failureType = tokenizer.nextToken();
				failureParameter = tokenizer.nextToken();

				while(tokenizer.hasMoreElements()){
					eventType = tokenizer.nextToken();
					timeOfOccurrence = Double.valueOf(tokenizer.nextToken());
					if(eventType.equals("F")){
						destroyer.addFailureEvent(hostid,vmid, timeOfOccurrence);
					}
					else{
						//destroyer.addRepairEvent(hostid, vmid,timeOfOccurrence);
					}
				}
			}
		}
		br.close();
	}

}

