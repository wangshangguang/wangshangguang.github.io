package org.cloudbus.cloudsim.replication;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.VmSchedulerTimeShared;
import org.cloudbus.cloudsim.CKP.datacenter.AggregateSwitch;
import org.cloudbus.cloudsim.CKP.datacenter.Config;
import org.cloudbus.cloudsim.CKP.datacenter.DCNetwork;
import org.cloudbus.cloudsim.CKP.datacenter.DataCenterLink;
import org.cloudbus.cloudsim.CKP.datacenter.EdgeSwitch;
import org.cloudbus.cloudsim.CKP.datacenter.NetDatacenterBroker;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkCloudletSpaceSharedScheduler;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkConstants;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkDatacenter;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkDatacenterCharacteristics;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkHost;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkStorageHost;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkVm;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkVmAllocationPolicy;
import org.cloudbus.cloudsim.CKP.datacenter.RootSwitch;
import org.cloudbus.cloudsim.checkpoint.DatacenterDestroyer;
import org.cloudbus.cloudsim.checkpoint.ReplicaInvoker;
import org.cloudbus.cloudsim.checkpoint.PrintResult;
import org.cloudbus.cloudsim.checkpoint.RecordToLogger;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;


public class Example {

	/**
	 * @param args
	 */
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RecordToLogger.logger.info("Starting CloudSim ...");
		
		Config.CheckpointStyle = 0;
		Config.isFocus=true;
		
		try {
			int num_user = 1; // number of cloud users
			Calendar calendar = Calendar.getInstance();
			boolean trace_flag = false; // mean trace events

			// Initialize the CloudSim library
			CloudSim.init(num_user, calendar, trace_flag);

			// Second step: Create Datacenters
			// Datacenters are the resource providers in CloudSim. We need at
			// list one of them to run a CloudSim simulation
			NetworkDatacenter datacenter0 = createDatacenter("Datacenter_0", Config.portNum);

			// Third step: Create Broker
			NetDatacenterBroker broker = createBroker();
			broker.setLinkDC(datacenter0);
			// broker.setLinkDC(datacenter0);
			// Fifth step: Create one Cloudlet

			List<NetworkVm> vmlist = CreateVMs(broker);
		
			// submit vm list to the broker

			broker.submitVmList(vmlist);
			
			// Sixth step: Starts the simulation
			CloudSim.startSimulation();

			CloudSim.stopSimulation();

			// Final step: Print results when simulation is over			
			PrintResult.printResult(datacenter0, broker);
			RecordToLogger.logger.info("CloudSim Example finished!");
		} catch (Exception e) {
			e.printStackTrace();
			RecordToLogger.logger.error("Unwanted errors happen");
		}

	}
	
	/**
	 * Creates the datacenter.
	 * 
	 * @param name
	 *            the name
	 * 
	 * @return the datacenter
	 * @throws IOException 
	 */
	private static NetworkDatacenter createDatacenter(String name, int portNum) throws IOException {
		DCNetwork dcn = new DCNetwork();	
		
		
		int rootSwitchNum = (portNum/2)*(portNum/2);
		
		int aggregateSwitchNum = portNum*(portNum/2);
		
		int edgeSwitchNum = portNum*(portNum/2);
		
		int hostNum = (portNum*portNum*portNum)/4;
		
		List<NetworkHost> hostList = new ArrayList<NetworkHost>();
		int mips = 20;
		int ram = 4096; // host memory (MB)
		long storage = 100000000; // host storage
		int bw = 10000;
		int x = 3;
		int hostNumPerPad = (portNum*portNum)/4;
		for (int y = 0; y < hostNum; y++) {
			List<Pe> peList = new ArrayList<Pe>();
			peList.add(new Pe(0, new PeProvisionerSimple(mips))); // need to
			NetworkHost host = new NetworkHost(
					"host_"+x+"_"+y,
					new RamProvisionerSimple(ram),
					new BwProvisionerSimple(bw),
					storage,
					peList,
					new VmSchedulerTimeShared(peList),
					x,y,
					y/hostNumPerPad);
			hostList.add(host); // This is our machine
			dcn.getHostList().add(host);
			dcn.getNodeList().add(host);
			
		}

		
		String arch = "x86"; // system architecture
		String os = "Linux"; // operating system
		String vmm = "Xen";
		double time_zone = 10.0; // time zone this resource located
		double cost = 3.0; // the cost of using processing in this resource
		double costPerMem = 0.05; // the cost of using memory in this resource
		double costPerStorage = 0.001; // the cost of using storage in this resource
		double costPerBw = 0.0; // the cost of using bw in this resource
		LinkedList<Storage> storageList = new LinkedList<Storage>(); // we are

		NetworkDatacenterCharacteristics characteristics = new NetworkDatacenterCharacteristics(
				arch,
				os,
				vmm,
				hostList,
				time_zone,
				cost,
				costPerMem,
				costPerStorage,
				costPerBw);

		NetworkDatacenter datacenter = null;
		try {
			datacenter = new NetworkDatacenter(
					name,
					characteristics,
					new NetworkVmAllocationPolicy(hostList),
					storageList,
					0,
					new CloudletRecoverySchedulerRedun("SmallCloudletRecoveryScheduler"),
					new ReplicaInvoker("StorageIndex"),
					new DatacenterDestroyer("DatacenterDestroyer"));

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		String storageCenterName = "storagecenter_"+-1+"_"+0;
		NetworkStorageHost storageCenter = new NetworkStorageHost(storageCenterName,datacenter,-1,0);

		x = 2;
		for(int y = 0; y < edgeSwitchNum; y++){
			EdgeSwitch edgeSwitch = new EdgeSwitch("edgeswitch_"+x+"_"+y,
					2,
					datacenter,
					x,y);
			dcn.getEdgeSwitchList().add(edgeSwitch);
			dcn.getNodeList().add(edgeSwitch);
//			System.out.println("edgeswitch_"+x+"_"+y);
			for(int k = 0; k< portNum/2;k++){
				NetworkHost  host = (NetworkHost)CloudSim.getEntity("host_"+3+"_"+(y*(portNum/2)+k));
				DataCenterLink link =new DataCenterLink(
						edgeSwitch.getId(),
						host.getId(),
								0,NetworkConstants.BandWidthEdgeHost);
				dcn.getLinkList().add(link);
				
				edgeSwitch.hostlist.put(host.getId(), host);
				edgeSwitch.getDownlinks().add(link);
				host.sw = edgeSwitch;
				host.inlink = link;

				
			}
//yang
			if((y%(portNum/2))==(portNum/2-1)){
				edgeSwitch.setStorageNode(true);
				storageCenter.storageEdgeSwitch.put(y/(portNum/2), edgeSwitch);
			}
		}

		x = 1;
		for(int y = 0; y < aggregateSwitchNum; y++){
			AggregateSwitch aggregateSwitch = new AggregateSwitch("aggregateswitch_"+x+"_"+y,
					2,
					datacenter,
					x,y
					);
			dcn.getAggregateSwitchList().add(aggregateSwitch);
			dcn.getNodeList().add(aggregateSwitch);
			for(int k = 0; k< portNum/2;k++){
				EdgeSwitch edgeSwitch = (EdgeSwitch)CloudSim.getEntity("edgeswitch_"+2+"_"+((y/(portNum/2))*(portNum/2)+k));
//				System.out.println((y/(portNum/2))*(portNum/2)+"edgeswitch_"+2+"_"+(((y)/(portNum/2))*(portNum/2)+k));
				
				DataCenterLink link = new DataCenterLink(
						aggregateSwitch.getId(),
						edgeSwitch.getId(),
								0,NetworkConstants.BandWidthEdgeAgg);
				dcn.getLinkList().add(link);
				
				aggregateSwitch.downlinkswitches.add(edgeSwitch);
				aggregateSwitch.getDownlinks().add(link);
				edgeSwitch.uplinkswitches.add(aggregateSwitch);
				edgeSwitch.getUplinks().add(link);
			}
		}
		

		
		x = 0;
		for(int y = 0; y < rootSwitchNum; y++){
			RootSwitch rootSwitch = new RootSwitch("rootswitch_"+x+"_"+y,
					2,
					datacenter,
					x,y);
			dcn.getRootSwitchList().add(rootSwitch);
			dcn.getNodeList().add(rootSwitch);
			
			DataCenterLink linkToStorageCenter = new DataCenterLink(
					storageCenter.getId(),
					rootSwitch.getId(),
							0,NetworkConstants.BandWidthRootStorageCenter);
			storageCenter.downlinkswitches.add(rootSwitch);
			storageCenter.downlinks.add(linkToStorageCenter);
			rootSwitch.setStorageCenter(storageCenter);
			rootSwitch.getUplinks().add(linkToStorageCenter);
			
			for(int k = 0; k< portNum;k++){
				AggregateSwitch aggregateSwitch = (AggregateSwitch)CloudSim.getEntity("aggregateswitch_"+1+"_"+(k*(portNum/2)+(y+1)%(portNum/2)));
//				System.out.println("aggregateswitch_"+1+"_"+(k*(portNum/2)+(y)%(portNum/2)));
				DataCenterLink link = new DataCenterLink(
						rootSwitch.getId(),
						aggregateSwitch.getId(),
								0,NetworkConstants.BandWidthAggRoot);
				dcn.getLinkList().add(link);
				
				rootSwitch.downlinkswitches.add(aggregateSwitch);
				rootSwitch.getDownlinks().add(link);
				aggregateSwitch.uplinkswitches.add(rootSwitch);
				aggregateSwitch.getUplinks().add(link);
			}
		}		
		
		dcn.setStorageCenter(storageCenter);
		characteristics.setDatacenternetwork(dcn);
		
		VmDestroyer vmDestroyer=new VmDestroyer("vmdestroyer");
		datacenter.setVmDestroyer(vmDestroyer);
		vmDestroyer.setDatacenter(datacenter);

		return datacenter;
	}

	// We strongly encourage users to develop their own broker policies, to
	// submit vms and cloudlets according
	// to the specific rules of the simulated scenario
	/**
	 * Creates the broker.
	 * 
	 * @return the datacenter broker
	 */
	private static NetDatacenterBroker createBroker() {
		NetDatacenterBroker broker = null;
		try {
			broker = new NetDatacenterBroker("Broker");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return broker;
	}
	
	private static List<NetworkVm> CreateVMs(NetDatacenterBroker broker) {
		// two VMs per host
		int numVM = broker.linkDC.getHostList().size() * NetworkConstants.maxhostVM;
		int datacenterbrokerId=broker.getId();
		List<NetworkVm> vmlist=new ArrayList<NetworkVm>();
		int type=-1;
		for (int i = 0; i < numVM; i++) {
			String name="vm_"+i;
			int mips = 1;
			long size = 100000; // image size (MB)
			int ram = 1024; // vm memory (MB)
			long bw = 1000;
			int pesNumber = NetworkConstants.HOST_PEs / NetworkConstants.maxhostVM;
			String vmm = "Xen"; // VMM name
			// create VM
			NetworkCloudletSpaceSharedScheduler scheduler = new NetworkCloudletSpaceSharedScheduler();
			NetworkVm vm = new NetworkVm(
					name,
					datacenterbrokerId,
					mips,
					pesNumber,
					ram,
					bw,
					size,
					vmm,
					scheduler,type);
			vmlist.add(vm);
			int vmid=vm.getId();			
			scheduler.setVm(vm);
			broker.linkDC.processVmCreateNetwork(vm);
			broker.getVmsToDatacentersMap().put(vmid, broker.linkDC.getId());
			vm.setType(type);		
		}

		VMPlacement.randPos();		
		return vmlist;		
	}
	
}
