package org.cloudbus.cloudsim.replication;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.cloudbus.cloudsim.CKP.datacenter.NetworkDatacenter;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkVm;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEntity;
import org.cloudbus.cloudsim.core.SimEvent;

public class VmDestroyer extends SimEntity {
	private NetworkDatacenter datacenter;
	
	private List<NetworkVm> weakVm = new ArrayList<NetworkVm>();
	
	private List<NetworkVm> strongVm = new ArrayList<NetworkVm>();
	
	private List<NetworkVm> failedVm = new ArrayList<NetworkVm>();
	
	private List<NetworkVm> runningVm = new ArrayList<NetworkVm>();
	
	private Map<Integer, Double> VmDownEvents = new  HashMap<Integer, Double>();
	
	private Map<Integer, Double> VmUpEvents = new  HashMap<Integer, Double>();
	
	private Map<Integer,Integer> VmToHost =new HashMap<Integer,Integer>();

	public VmDestroyer(String name) {
		super(name);
		
	}
	
	public void init(){
//		NetworkDatacenterCharacteristics characteristics = (NetworkDatacenterCharacteristics)datacenter.getCharacteristics();
		
	
	}

	@Override
	public void startEntity() {
		Iterator iter = VmDownEvents.entrySet().iterator();
		while (iter.hasNext()){
			Map.Entry entry = (Map.Entry) iter.next();
			int Vmid = (Integer)entry.getKey();
			double time = (Double)entry.getValue();
//			int hostid=(Integer)VmToHost.get(Vmid);
			send(getId(), time, CloudSimTags.Vm_DOWN, Vmid);
//			System.out.println(Vmid +"////"+time);
		}
		iter = VmUpEvents.entrySet().iterator();
		while (iter.hasNext()){
			Map.Entry entry = (Map.Entry) iter.next();
			int Vmid = (Integer)entry.getKey();
			double time = (Double)entry.getValue();
	//		int hostid=(Integer)VmToHost.get(Vmid);
			send(getId(), time, CloudSimTags.Vm_REAPIR, Vmid);
		}

	}

	@Override
	public void processEvent(SimEvent ev) {
		switch (ev.getTag()) {
		// Resource characteristics request
			case CloudSimTags.Vm_DOWN:
				VmDown(ev);
				break;
			// Resource characteristics answer
			case CloudSimTags.Vm_REAPIR:
				VmRepair(ev);
				break;

			// other unknown tags are processed by this method
			default:
				break;
		}

	}
	
	public void VmRepair(SimEvent ev){
		int data = (Integer)ev.getData();
		int vmid=data;
		NetworkVm vm=(NetworkVm)CloudSim.getEntity(vmid);
		vm.setFailed(false);

	}
	
	public void VmDown(SimEvent ev){
		int data = (Integer)ev.getData();
		int vmid=data;
		NetworkVm vm=(NetworkVm)CloudSim.getEntity(vmid);

		vm.setFailed(true);
		datacenter.getRecoveryScheduler().vmrecovery(vm);

	}
	
	public void addRepairEvent(int hostid,int Vmid, double time){
		this.VmUpEvents.put(Vmid, time);
//		this.VmToHost.put(Vmid, hostid);
	}
	
	public void addFailureEvent(int hostid,int Vmid, double time){
		this.VmDownEvents.put(Vmid, time);
//		this.VmToHost.put(Vmid, hostid);
	}

	@Override
	public void shutdownEntity() {
		// TODO Auto-generated method stub

	}
	
	public NetworkDatacenter getDatacenter() {
		return datacenter;
	}

	public void setDatacenter(NetworkDatacenter datacenter) {
		this.datacenter = datacenter;
	}

}

