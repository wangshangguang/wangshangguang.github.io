package org.cloudbus.cloudsim.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Fileinput {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file=new File("./test.txt");
		try {
			if (file.exists()) {
                file.delete();
            }
            
             file.createNewFile();
            
            FileWriter writer = new FileWriter(file,true);
            
          
         
            writer.write("11111111safdf11111111111");
            writer.flush();
            writer.close();
        } catch (IOException ex) {
            
            ex.printStackTrace();
        }
      
	}

}
