# coding=gbk
#-------------------------------------------------------------------------------
# Name:            XCS_PbmEnvironment.py
# Purpose:         Extend the original XCS version to a Common version
# Original Author: Martin V. Butz (in Java 1.0) - translated to python by Jose Antonio Martin H. <jamartin@dia.fi.upm.es>
# Copyright:       (c) Arthur Lee 2010
# Created:         04/27/2010
# Licence:         <GPL>
# Modified by:     Arthur Lee 04/27/2010 (sm4llb0y@gmail.com)
# Updated:         04/27/2010
# Status:          alpha v.2.0
# Description:     This class implements the Common Classification Problem
#                  It loads an dataset containing strings with attribute and class values, determines if a classification
#                  was correct, and which payoff is provided. 
#-------------------------------------------------------------------------------
#!/usr/bin/env python

#Import modules
from XCS_Environment import *
from XCS_Constants import *
import random
import sys

class PbmEnvironment(Environment):
    '''���⻷����ʼ��'''
    def __init__(self, inFileString, testFileString, nrActions, reward):
        """ Initialize environment objects. """

        self.headerList = []
        self.attributeLengthList = []
        self.datasetList = []
        self.numAttributes = 0  # Saves the number of attributes in the input file.
        self.numSamples = 0
        self.classPosition = 0
        self.currentState = []
        self.currentClass = None
        self.dataCount = 0
        self.correct = False
        self.reset = False
        self.formatedDataset = []
        self.attributeCombos = 2 #the attribute style numbers 0,1
        XCSConstants.setEConstants(self.attributeCombos)

        self.maxPayoff = reward
        self.nrActions = nrActions
        self.testFileString = testFileString

        # Calls a method to open the training file and initialize the environment according to that data.
        self.makeEnvironment(inFileString)
        #***********************************************************************
    '''��ȡѵ�����ݼ���formatedDataset��'''
    def makeEnvironment(self,dataset):
        #*******************Initial file handling**********************************************************
        try:
            f = open(dataset, 'r')
            self.attributeLengthList = f.readline().rstrip('\n').split('\t') #first line is the attribute length
            self.headerList = f.readline().rstrip('\n').split('\t')   #strip off first row , Second line is header name
            for line in f:
                lineList = line.strip('\n').split('\t')# the encoding of example rule: 0000 00 10 11 2
                self.datasetList.append(lineList)
            f.close()
            self.numAttributes = len(self.headerList) - 1 # subtract 1 to account for the class column
            self.classPosition = len(self.headerList) - 1    # Could be altered to look for "class" header
            self.numSamples = len(self.datasetList)
            #self.segmentSize = self.numSamples/self.divisions

        except IOError, (errno, strerror):
            print ("Could not Read File!")
            print ("I/O error(%s): %s" % (errno, strerror))
            raise
        except ValueError:
            print ("Could not convert data to an integer.")
            raise
        except:
            print ("Unexpected error:", sys.exc_info()[0])
            raise

        # Build empty matrix for formated data [sample][att]
        for i in range(self.numSamples):  # for each column - one for the attribute data and one for the class
            self.formatedDataset.append([])
        for i in range(self.numSamples):
            self.formatedDataset[i] = [' ', ' ']

        # Fill in the matrix built above with the binary attribute encoding and the binary class value
        for line in range(len(self.datasetList)):
            codeList = []
            for att in range(self.numAttributes):
                codeList += list(self.datasetList[line][att])

            self.formatedDataset[line][0] = codeList
            self.formatedDataset[line][1] = self.datasetList[line][self.classPosition]

        from random import shuffle
        shuffle(self.formatedDataset)

        self.currentState = self.formatedDataset[self.dataCount][0]
        self.currentClass = self.formatedDataset[self.dataCount][1]
    
    '''��ȡ�������ݼ�'''
    def switchToTesting(self):
        """ Makes the data set of focus the testing data, as opposed to the training data. """

        self.datasetList = []
        self.dataCount = 0
        self.formatedDataset = []
        self.makeEnvironment(self.testFileString)

    
    def resetDataCount(self):
        """ Resets the iteration count through the current data set. """
        self.dataCount = 0

    
    '''ȡ��һ�����Ի���ѵ����¼'''
    def resetState(self):
        """  Changes the state to the next sample input.  Once all of the data has been explored, the order is shuffled and it is explored again. """

        if self.dataCount < (self.numSamples):
            # get the next data point in self.formatedDatasets
            self.currentState = self.formatedDataset[self.dataCount][0]
            self.currentClass = self.formatedDataset[self.dataCount][1]
            self.dataCount += 1
        else:   # This is done so that the training order varies with each epoch.
            self.dataCount = 0
            from random import shuffle
            shuffle(self.formatedDataset)

    	self.reset=False
    	return self.currentState

    '''ִ�ж���'''
    def executeAction(self,action):
        """ Check to see if action prediction is a correct classification.  Use some new self.currentAction to hold on to present environmental action
        Executes the action and determines the reward.
        @param action Specifies the classification. """

        reward = 0
        if action == int(self.currentClass):
            reward = self.maxPayoff
            self.correct = True
        else:
            reward = 0
            self.correct = False

        self.reset = True
        return reward

#-------------------------------------------------------------------------------Methods which might be fine for any type of environment.

    def wasCorrect(self):
        """ Returns true if the last executed action was a correct classification."""
        return self.correct


    def doReset(self):
        """ Returns true after the current problem was classified."""
        return self.reset


    def getMaxPayoff(self):
        """ Returns the maximal payoff possible in the current multiplexer problem.
        The maximal payoff is determined out of the payoff type. If the payoff type 1000/0 is selected
        this function will return 1000, otherwise the maximal value depends on the problem size. """
        return self.maxPayoff


    def getNrActions(self):
        """ Returns the number of possible actions.
        in the Multiplexer problem there are two classifications possible. """
        return self.nrActions


    def getNrSamples(self):
        """ Returns the number of samples in the dataset being examined. """
        return self.numSamples


    def getCurrentState(self):
        """ Returns -a copy- of the current problem state. """
        return self.currentState[:]


    def getHeaderList(self):
        """ Returns the file header text as a list of elements. """
        return self.headerList


    def getAttributeLengthList(self):
        """ Returns the number of possible attribute encodings.  Very specific to this type of environment. """
        return self.attributeLengthList
    