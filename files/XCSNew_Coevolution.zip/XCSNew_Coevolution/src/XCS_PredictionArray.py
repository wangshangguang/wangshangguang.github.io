# coding=gbk
#-------------------------------------------------------------------------------
# Name:            XCS_PredictionArray.py
# Purpose:         Translation of the XCS system to Python
# Original Author: Martin V. Butz (in Java 1.0) - translated to python by Jose Antonio Martin H. <jamartin@dia.fi.upm.es>
# Copyright:       (c) Jose Antonio Martin H. 2007
# Created:         01/16/2007
# Licence:         <GPL>
# Modified by:     Ryan Urbanowicz 01/18/2009 (ryanurbanowicz@gmail.com) 
# Updated:         08/10/2009
# Status:          FUNCTIONAL * FINAL * v.1.0
# Description:     This class generates a prediction array of the provided set.
#                The prediction array is generated according to Wilson's Classifier Fitness Based on Accuracy (Evolutionary Computation Journal, 1995).
#                Moreover, this class provides all methods to handle selection in the prediction array, essentially, to select the
#                best action, a present random action or an action by roulette wheel selection.
#-------------------------------------------------------------------------------               
#!/usr/bin/env python

#Import modules
from XCS_Constants import *
from XCS_ClassifierSet import *
import sys
import random

class XCSPredictionArray:
    def __init__(self, set, size):
        """ Constructs the prediction array according to the current set and the possible number of actions. 
        @param set The classifier set out of which a prediction array is formed (normally the match set).
        @param size The number of entries in the prediction array (should be set to the number of possible actions in the problem) """
    	self.pa = [0.0 for i in range(size)] #The prediction array.
    	self.nr = [0.0 for i in range(size)] #The sum of the fitness of classifiers that represent each entry in the prediction array.

        for cl in set.clSet: # check each classifier in the set (different actions)
    	    #print cl.getPrediction()," ",cl.getFitness(),"\n"
            #print 'perror is', cl.getPredictionError()
            self.pa[cl.getAction()] += (cl.getPrediction()*cl.getFitness())   # Fitness weighted average of predictions 1/20/09 Made slight change to coding
    	    self.nr[cl.getAction()] += cl.getFitness()

    	for i in range(size):
    	    if self.nr[i]!=0:
    		  self.pa[i] = self.pa[i]/self.nr[i]
    	    else:
    		  self.pa[i]=0.0  # if an action is not represented than it's prediction is set to zero.

        
    def getBestValue(self):
        """ Returns the highest value in the prediction array. """
        return max(self.pa)
    
        
    def getValue(self, i):
        """ Returns the value of the specified entry in the prediction array. """
    	if i>=0 and i<len(self.pa):
    	    return self.pa[i]
    	return -1.0


    ##*************** Action selection functions ****************
    def randomActionWinner(self):
        """ Selects an action randomly. The function assures that the chosen action is represented by at least one classifier. """
    	ret=0
    	while True:
    	    ret = int(random.random()*len(self.pa)) 
    	    if self.nr[ret]!=0:
    	        break
    	return ret
    

    def bestActionWinner(self):
        """ Selects the action in the prediction array with the best value.
         *MODIFIED so that in the case of a tie between actions - an action is selected randomly between the tied highest actions. """
        highVal = 0.0
        for i in self.pa:
            if i > highVal:
                highVal = i
        bestIndexList = []
        for i in range(len(self.pa)):
            if self.pa[i] == highVal:
                bestIndexList.append(i)
        return random.choice(bestIndexList)

        
    def rouletteActionWinner(self):
        """ Selects an action in the prediction array by roulette wheel selection. """
    	bidSum = sum(self.pa) * XCSConstants.random()
    	bidC=0.0
    	i = 0
    	while bidC<bidSum:
    	    bidC = bidC + self.pa[i]
            i = i + 1
        return i

