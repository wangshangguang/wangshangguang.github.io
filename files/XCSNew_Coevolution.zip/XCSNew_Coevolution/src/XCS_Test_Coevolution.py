# coding=gbk
#-------------------------------------------------------------------------------
# Name:            XCS_Test.py
# Purpose:         Translation of the XCS system to Python
# Original Author: Martin V. Butz (in Java 1.0) - translated to python by Jose Antonio Martin H. <jamartin@dia.fi.upm.es>
# Copyright:       (c) Jose Antonio Martin H. 2007
# Created:         01/16/2007
# Licence:         <GPL>
# Modified by:     Ryan Urbanowicz 01/18/2009 (ryanurbanowicz@gmail.com) 
# Updated:         08/10/2009
# Status:          FUNCTIONAL * FINAL * v.1.0
# Description:     A testing replacement for XCS_Main.py to run XCS from Eclipse.
#-------------------------------------------------------------------------------
#!/usr/bin/env python

#Import modules
from XCS import *
from XCS_PbmEnvironment import *
from XCS_PbmEnvironmentIni import *

def Decimal2Binary(dec_num):
    """ Return the binary representation of dec_num """
    if dec_num == 0: return ''
    head, tail = divmod(dec_num, 2)
    return Decimal2Binary(head) + str(tail)

def Decimal2BinaryUsingLength(dec_num, length):
    binaryStr = Decimal2Binary(dec_num)
    if len(binaryStr) < length:
        return '0'*(length-len(binaryStr))+binaryStr
    return binaryStr

def main():
    #RUN PARAMETERS
    graphPerformance = False
    '''�趨ѵ�����ݼ�&�������ݼ�'''
    countSimilar = 4
    trainData_u = "F:\\Works\\Program\\Python\\XCSNew_Coevolution\\src\\dataset_train_final_u"
    testData_u = "F:\\Works\\Program\\Python\\XCSNew_Coevolution\\src\\dataset_test_final_u"
    
    outProg = "GH_XCS_ProgressTrack"
    outPop = "GH_XCS_PopulationOut"
    '''������'''
    nrActions = 5
    '''�ر�'''
    reward = 1000
    CVpartitions = 10
    '''ѭ������'''
    iterInput = '2000'
    #trackCycles = 'Default' # set tracking cycles to number of data samples - trackCycles = 100
    '''ÿ���ٴμ���һ�¾�ȷ��''' 
    trackCycles = 100
    '''��Ⱥ��С'''
    pop = 2000
    sub = 0
    select = 0
    
    #Figure out the iteration stops for evaluation, and the max iterations.
    iterList = iterInput.split('.')
    for i in range(len(iterList)):
        iterList[i] = int(iterList[i])
    lastIter = iterList[len(iterList)-1]
    
    xcsList = []
    for i in range(countSimilar):
        print "start train u",i
        #Sets up up algorithm to be run.
        '''�������⻷�����Լ�XCS����'''
        e_u = PbmEnvironment(trainData_u+str(i)+".txt",testData_u+str(i)+".txt",nrActions,reward)
        sampleSize = e_u.getNrSamples()
        xcs_u = XCS(e_u, outProg, outPop, CVpartitions, graphPerformance)
        
        #Set some XCS parameters.
        if trackCycles == 'Default':
            xcs_u.setTrackingIterations(sampleSize)
        else:
            xcs_u.setTrackingIterations(trackCycles)
        xcs_u.setNumberOfTrials(lastIter,iterList)
        xcs_u.setPopulationSize(pop)
        xcs_u.setSubsumption(sub)
        xcs_u.setSelection(select)     
    
        #Run the XCS Algorithm  
        '''ִ�в���'''
        xcs_u.onlyTrain = True
        xcs_u.runXCS()
        
        print "train u",i," complete"
        xcsList.append(xcs_u)
    
    
    
    '''����u1��u2ѵ����ɣ�������������Э�����u2��classifier��Ⱥ�ĳ�ʼ��'''
    e_u = PbmEnvironmentIni(nrActions)
    for i in range(4):
        for j in range(4):
            for l in range(16):
                for m in range(16):
                    currentState = []
                    currentState += list(Decimal2BinaryUsingLength(i, 2))
                    currentState += list(Decimal2BinaryUsingLength(j, 2))
                    currentState += list(Decimal2BinaryUsingLength(l, 4))
                    currentState += list(Decimal2BinaryUsingLength(m, 4))
                    actionVoteList = [0 for c in range(nrActions)]
                    predictionList = [0.0 for c in range(nrActions)]
                    for c in range(countSimilar):
                        action, prediction = xcsList[c].getActionAndRewardByState(currentState)
                        if action != -1:
                            actionVoteList[action] += 1
                            predictionList[action] += prediction
                    maxNum = max(actionVoteList)
                    '''����һ�������Ҫ��ͬ��������Ϊ�ǹ�ͬ��ƫ�ù���ǰ�û�ʹ��'''
                    if maxNum > int(countSimilar/2):
                        for c in range(nrActions):
                            if actionVoteList[c] == maxNum:
                                e_u.insertRecord(currentState, c, predictionList[c]/float(actionVoteList[c]))
                                break
                    
                    
    
    sampleSize = e_u.getNrSamples()
    
    xcs_u = XCS(e_u, outProg, outPop, CVpartitions, graphPerformance)
    
    #Set some XCS parameters.
    if trackCycles == 'Default':
        xcs_u.setTrackingIterations(sampleSize)
    else:
        xcs_u.setTrackingIterations(trackCycles)
    xcs_u.setNumberOfTrials(lastIter,iterList)
    xcs_u.setPopulationSize(pop)
    xcs_u.setSubsumption(sub)
    xcs_u.setSelection(select)    
    
    xcs_u.onlyTrain = True
    xcs_u.runXCS()
    
    '''�������û��Ĺ�������꣬�ڽ�������'''
    e_u2 = PbmEnvironment(trainData_u+str(countSimilar)+".txt",testData_u+str(countSimilar)+".txt",nrActions,reward)
    xcs_u.env = e_u2
    
    xcs_u.onlyTrain = False
    xcs_u.runXCS()
    
if __name__ == '__main__':
    main()
