# coding=gbk
#-------------------------------------------------------------------------------
# Name:            XCS.py
# Purpose:         Translation of the XCS system to Python
# Original Author: Jose Antonio Martin H. <jamartin@dia.fi.upm.es>
# Copyright:       (c) Jose Antonio Martin H. 2007
# Created:         01/16/2007
# Licence:         <GPL>
# Modified by:     Ryan Urbanowicz 01/28/2009 (ryanurbanowicz@gmail.com) 
# Updated:         08/07/2009
# Status:          FUNCTIONAL * FINAL * v.1.0
# Description:     XCS algorithm - Initializes the algorithm - Major purpose of modifications allow specification of parameters from command line, as well externally controlled cross validation.
#                  This class is the XCS itself. It stores the population and the posed problem.
#                  The class provides methods for the main learning cycles in XCS distinguishing between
#                  single-step and multi-step problems as well as exploration vs. exploitation trials.
#                  Moreover, it handles the performance evaluation.
#-------------------------------------------------------------------------------
#!/usr/bin/env python

#Import modules
import time
from XCS_Environment import *
from XCS_ClassifierSet import *
from XCS_Constants import *
from XCS_PredictionArray import *
#from pylab import * #Used for the graphing method
import copy

    
class XCS:      
    def __init__(self, e, outFileString, popOutFileString, CVparts, graphPerform):
        """ Constructs the XCS system.  """
        self.env=e
        self.evaluationEnv = None
        #specify output file
        self.outFile = outFileString
        
        #specify population output file
        self.popFile = popOutFileString
        
        #initialize XCS
        self.pop=None
        #self.bitLength = bitLength
        self.trainAccuracy  = 0
        self.trainTotalError  = 0 
        self.testAccuracy  = 0
        self.testTotalError  = 0    
             
        #Used for cross validation cycles
        self.CVpartitions = CVparts
        
        # Track learning time
        self.startLearningTime = 0
        self.endLearningTime = 0
        self.evalTime = 0
        
        self.performanceTrackList = [[0],[0],[0],[0],[0],[0]]
        self.graphPerform = graphPerform
        
        self.startTime = None
        
        self.onlyTrain = False
        
    def setNumberOfTrials(self, trials, iterList):
        """ Resets the maximal number of learning iterations in an LCS run."""
        self.maxProblems = trials
        self.iterStops = iterList


    def setTrackingIterations(self, cycles):
        """ Resets the paramenters for how often progress tracking is reset and sent to the output file."""
        self.expCy = int(cycles)
        self.expCyMath = float(cycles)
            
            
    def setPopulationSize(self, popsize):
        """ Resets the max population size."""
        self.maxPopSize = int(popsize)
        
        
    def setSubsumption(self, subsumption):    
        """ Turns on or off, the subsumption mechanisms (in both GA and Action set)."""
        self.doGASubsumption = subsumption
        self.doActionSetSubsumption = subsumption
        
        
    def setSelection(self, selection): 
        """Resets the selection type to be used in the GA - either (0)roulette, or (1)tournament."""
        self.selectionType = selection
                
    '''����XCS'''            
    def runXCS(self):
        """ Runs the posed problem with XCS.
        The function essentially initializes the output File and then runs the experiments. """
        
        try:
            pW = open(self.outFile+'.txt','w')     
        except IOError, (errno, strerror):
            print ("I/O error(%s): %s" % (errno, strerror))
            raise
        
        self.startTime = time.time()
        '''���ܽ��ִ��һ����������'''
        self.doSingleStepExperiment(pW)
        print "LCS Training and Evaluation Complete!"
        
        try:
            pW.close()
        except IOError, (errno, strerror):
            print ("I/O error(%s): %s" % (errno, strerror))
            raise    
            
    '''ִ��һ����������'''        
    def doSingleStepExperiment(self,pW):
        """ Specifies the steps to run the XCS algorithm once through. The method name Experiment is a remnant of how it was originally implemented. """
        # Initialize Population
        '''���ɲ��ҳ�ʼ����Ⱥ'''
        self.pop = XClassifierSet(self.env.getNrActions())
        
        # Initialize Objects 
        explore=0
        bestCorrectPos = 0
        correct  = [0.0 for i in range(self.expCy)] #tracks performance (accuracy of prediction) - collects findings in clusters of 50 data points (same for error)
        sysError = [0.0 for i in range(self.expCy)] #tracks error in reward prediction
        exploreProbC = 0  #Explore problem count - tracks the number of LCS cycles        
        
        pW.write("Explore_Iteration\tPerformance\tError\tGenerality\tWeightedGenerality\tMacroPopSize\n")
        self.startLearningTime = time.time()    #TIMER STARTS
        
        '''ֻҪû��ֹͣ������һֱѭ��'''
        while exploreProbC < self.maxProblems:
            explore = (explore+1)%2
            state = self.env.resetState()    #refers to current input data from environment
            
            '''һ��ļ���ִ��exploitһ��ļ���ִ��explora'''
            if explore==1:
                self.doOneSingleStepProblemExplore(state, exploreProbC)
            else: # exploit
                self.doOneSingleStepProblemExploit(state, exploreProbC, correct, sysError)

            '''ÿ�ε����ھ�������ǰ�ľ�ȷ��'''
            if (exploreProbC%self.expCy)==(self.expCy-1) and explore==0 and exploreProbC>0:  #evaluate performance every 50 explorations 
                self.pop.CSAnalysis(self.env) 
                self.writePerformance(pW, correct, sysError, exploreProbC+1, self.pop.getGenerality(), self.pop.getWeightGenerality()) 
                    
            exploreProbC = exploreProbC + explore   # only increments every other run(during explore phases)
            
            # MAJOR EVALUATIONS - has to be completely non-disruptive of learning cycles / environment
            # copy environment
            self.evaluationEnv = copy.copy(self.env)
            if self.evaluationEnv is self.env:
                print "Environment Object Error"
            tempTimeA = 0
            tempTimeB = 0
            
            '''ֻ�����ִ����ɲŻ����������������'''
            if exploreProbC+1 in self.iterStops and explore == 0 and not self.onlyTrain:
                self.endLearningTime = time.time()
                tempTimeA = time.time() 
                try:  
                    popW = open(self.popFile + '.'+ str(exploreProbC+1)+'.txt','w')   #New for pop output - now have to open one for each iteration setting
                except IOError, (errno, strerror):
                    print ("I/O error(%s): %s" % (errno, strerror))
                    raise
                
                #Run Evaluation
                trainEval = []
                testEval = []
                if self.CVpartitions > 1: #run CV partitions  
                    # Run a complete classification evaluation and have the prediction accuracy saved where the popW is printed.
                    '''�ֱ����ѵ�����ݼ��ľ�ȷ�ȺͲ������ݼ��ľ�ȷ��'''
                    trainEval = self.doPopEvaluation()  
                    self.evaluationEnv.switchToTesting()   
                    testEval = self.doPopEvaluation()  
                else:
                    trainEval = self.doPopEvaluation() 
                    testEval = [0.0,0.0,0.0]   

                learnSec = self.endLearningTime - self.startLearningTime - self.evalTime
                self.pop.CSAnalysis(self.evaluationEnv)   # Measures some population characateristics - e.g Generality
                self.pop.printCSEvaluation(popW, trainEval, testEval, learnSec, self.evaluationEnv, self.CVpartitions)
                        
                try:
                    popW.close()  
                except IOError, (errno, strerror):
                    print ("I/O error(%s): %s" % (errno, strerror))
                    raise     
                #TIME TRACKER        
                tempTimeB = time.time() 
                self.evalTime += tempTimeB - tempTimeA      
                     
    
    '''����exploration'''
    def doOneSingleStepProblemExplore(self,state, counter):
        """ Executes one main learning loop for a single step problem.
        * @param state The actual problem instance.
        * @param counter The number of problems observed so far in exploration. """
        
        self.pop.onlyMatch = False
        matchSet        = XClassifierSet(state, self.pop, counter, self.env.getNrActions(), self.maxPopSize)
        predictionArray = XCSPredictionArray(matchSet, self.env.getNrActions())
        
        '''���ѡ��action'''
        actionWinner    = predictionArray.randomActionWinner()  #is this the best way to learn during explore phases? (maybe - this way we can begin to punish bad classifiers for guessing wrong( more exploration)
        
        actionSet       = XClassifierSet(matchSet, actionWinner)
        reward          = self.env.executeAction(actionWinner)
        actionSet.updateSet(0.0, reward, self.doActionSetSubsumption)
        '''ִ���Ŵ�����'''
        actionSet.runGA(counter, state, self.env.getNrActions(), self.maxPopSize, self.doGASubsumption, self.selectionType)

    '''ִ��exploitation'''
    def doOneSingleStepProblemExploit(self, state, counter, correct, sysError):
        """ Executes one main performance evaluation loop for a single step problem.
        * @param state The actual problem instance.
        * @param counter The number of problems observed so far in exploration.
        * @param correct The array stores the last fifty correct/wrong exploitation classifications.
        * @param sysError The array stores the last fifty predicted-received reward differences. """
        #NOTE: action set not needed during exploit phase!!
        
        self.pop.onlyMatch = False
        matchSet        = XClassifierSet(state, self.pop, counter, self.env.getNrActions(), self.maxPopSize)
        predictionArray = XCSPredictionArray(matchSet, self.env.getNrActions())
        
        '''ѡ������action'''
        actionWinner    = predictionArray.bestActionWinner()
        
        reward          = self.env.executeAction(actionWinner)
    
        if self.env.wasCorrect():
            correct[counter%self.expCy]=1
        else:
            correct[counter%self.expCy]=0
            
        sysError[counter%self.expCy] = abs(reward - predictionArray.getBestValue())
    
    def getActionAndRewardByState(self, state):
        counter = time.time()
        
        self.pop.onlyMatch = True
        matchSet        = XClassifierSet(state, self.pop, counter, self.env.getNrActions(), self.maxPopSize)
        
        if len(matchSet.clSet) == 0:
            return -1,0
        
        predictionArray = XCSPredictionArray(matchSet, self.env.getNrActions())
        '''ѡ������action'''
        action = predictionArray.bestActionWinner()
        reward = predictionArray.getBestValue()
        return action, reward

    def doPopEvaluation(self):
        """ Obtains a complete classification evaluation of the specified data set."""
        #Set up for the Evaluation
        dataPoints = self.evaluationEnv.getNrSamples()  #represents the number of iterations
        self.evaluationEnv.resetDataCount()
        correct  = [0.0 for i in range(dataPoints)] #tracks performance (accuracy of prediction) - collects findings in clusters of 50 data points (same for error)
        sysError = [0.0 for i in range(dataPoints)] #tracks error in reward prediction
        noMatch = [0.0 for i in range(dataPoints)]
        
        for each in range(dataPoints):
            state = self.evaluationEnv.resetState()    #refers to current input data from environment
            # NOTE: the below will still allow covering to occur - in which case accurate classification with be 50/50 - and not bias either way.
            special = "EvalSet"
            matchSet = XClassifierSet(special, state, self.pop) #An alternative matchset object that does not implement covering - may return an empty match set or a set with only one action

            if matchSet.getSize() == 0:
                noMatch[each%dataPoints]=1
            else:
                noMatch[each%dataPoints]=0

            predictionArray = XCSPredictionArray(matchSet, self.evaluationEnv.getNrActions())
            actionWinner    = predictionArray.bestActionWinner()
            reward          = self.evaluationEnv.executeAction(actionWinner)
    
            if self.evaluationEnv.wasCorrect():
                correct[each%dataPoints]=1
            else:
                correct[each%dataPoints]=0
            
            sysError[each%self.expCy] = abs(reward - predictionArray.getBestValue())   
            
        print str(sum(correct)) + ' out of '+ str(dataPoints)+' correctly classified.'     #Debugging
        
        # A temporary list to store the accuracy and Total error calculated from the above evaluation
        resultList = [sum(correct)/float(dataPoints), sum(sysError)/float(dataPoints), sum(noMatch)/float(dataPoints)]   
        return resultList
        
 
    """##########---- Output ----##########"""
    def writePerformance(self, pW, performance, sysError, exploreProbC, generality, weightGenerality):
        """ Writes the performance of the XCS to the specified file.
        * The function writes time performance systemError actualPopulationSizeInMacroClassifiers.
        * Performance and system error are averaged over the last fifty trials.
        * @param pW The reference where to write the performance.
        * @param performance The performance in the last fifty exploration trials.
        * @param sysError The system error in the last fifty exploration trials.
        * @param exploreProbC The number of exploration trials executed so far. """

        perf  = sum(performance)/self.expCyMath
        serr  = sum(sysError)/self.expCyMath
        pop = self.pop.getSize()
        convergeTime = time.time()-self.startTime
        
        pW.write(str(exploreProbC) + "\t" + str(perf) + "\t" + str(serr) + "\t" + str(generality) + "\t" + str(weightGenerality) + "\t" + str(pop) + "\n")
        print ("Probe: " + str(exploreProbC) + "\t Performance: " + str(perf) + "\t Generality: " + str(generality) + "\t WeightedGenerality: " + str(weightGenerality) + "\t Error: " + str(serr) + "\t PopSize: " + str(self.pop.getSize())+ "\t ConvergeTime: " + str(convergeTime))

        if self.graphPerform:
            self.performanceTrackList[0].append(exploreProbC)
            self.performanceTrackList[1].append(perf)
            self.performanceTrackList[2].append(serr/float(self.env.maxPayoff))
            self.performanceTrackList[3].append(generality)  
            self.performanceTrackList[4].append(weightGenerality)          
            self.performanceTrackList[5].append(pop/float(self.maxPopSize))            
            self.graphPerformance()
        
#            
#    def graphPerformance(self):
#        """ Graphs performance attributes in real time. """
#        ion()   # Turn on interactive mode for interactive graphing
#        line1 = plot(self.performanceTrackList[0], self.performanceTrackList[1],'g-')
#        line2 = plot(self.performanceTrackList[0], self.performanceTrackList[2],'r-')
#        line3 = plot(self.performanceTrackList[0], self.performanceTrackList[3],'b-')
#        line4 = plot(self.performanceTrackList[0], self.performanceTrackList[4],'c-')
#        line5 = plot(self.performanceTrackList[0], self.performanceTrackList[5],'y-')
#        #axis([0, self.maxProblems, 0, 1])
#        legend((line1,line2,line3,line4,line5),('Prediction Accuracy','Error(/'+str(self.env.maxPayoff)+')','Generality','WeightedGenerality','PopSize(/'+str(self.maxPopSize)+')'),loc=4)
#        xlabel('Training Iterations')
#        title('LCS Performance Tracking')
#        grid(True)

