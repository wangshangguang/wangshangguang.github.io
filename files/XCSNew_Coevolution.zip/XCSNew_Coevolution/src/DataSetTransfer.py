#! /usr/bin/python

# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__ = "4rthur"
__date__ = "$2010-4-27 16:49:30$"

import sys

if __name__ == "__main__":
    try:
        f = open('test.txt', 'r')
        attributeLengthLine = f.readline() #first line is the attribute length
        headerLine = f.readline()
        headerList = headerLine.rstrip('\n').split('\t')   #strip off first row , Second line is header name
        datasetList = []
        for line in f:
            lineList = line.strip('\n').split('\t')# the encoding of example rule: 0000 00 10 11 2
            datasetList.append(lineList)
        f.close()
        for i in range(len(datasetList)):
            for j in range(len(headerList)-1):
                if datasetList[i][j] == '0':
                    datasetList[i][j] = '00'
                elif datasetList[i][j] == '1':
                    datasetList[i][j] = '01'
                elif datasetList[i][j] == '2':
                    datasetList[i][j] = '10'
                else:
                    print 'error'
        
        of = open('test_1.txt', 'a')
        of.write(attributeLengthLine)
        of.write(headerLine)
        for i in range(len(datasetList)):
            of.write('\t'.join(datasetList[i]) + '\n')
        of.close()
    except IOError, (errno, strerror):
        print ("Could not Read File!")
        print ("I/O error(%s): %s" % (errno, strerror))
        raise
    except ValueError:
        print ("Could not convert data to an integer.")
        raise
    except:
        print ("Unexpected error:", sys.exc_info()[0])
        raise
