# coding=gbk
#-------------------------------------------------------------------------------
# Name:            XCS_Main.py
# Purpose:         Translation of the XCS system to Python
# Original Author: Martin V. Butz (in Java 1.0) - translated to python by Jose Antonio Martin H. <jamartin@dia.fi.upm.es>
# Copyright:       (c) Jose Antonio Martin H. 2007
# Created:         01/16/2007
# Licence:         <GPL>
# Modified by:     Ryan Urbanowicz 01/20/2009 (ryanurbanowicz@gmail.com) 
# Updated:         08/07/2009
# Status:          FUNCTIONAL * FINAL * v.1.0
# Description:     Command line Main method for running the XCS algorithm.  
#                  Handles inputs, builds the environment, and runs the XCS algorithm
#-------------------------------------------------------------------------------
#!/usr/bin/env python

#Import modules
from XCS import *
from XCS_GHEnvironment import *
import sys
import time
argv = sys.argv

helpstr = """
Parameters:
    1:  Specify the environment - 'gh'
    2:  Training Dataset - '/SomePath/SomeTrainfile.txt'
    3:  Testing Dataset - '/SomePath/SomeTestfile.txt'
    4:  Output Filename (Learning Progress Tracking) - '/SomePath/SomeProgressName'
    5:  Output Filename (Final Pop Evaluation) - '/SomePath/SomeFinalPopName'
    6:  Coding Length - '1', '2', or '3'
    7:  Reward/Payoff - '1000'
    8:  Dataset Partitions for CV - '10'
    9:  Performance Tracking Cycles - '50'
    10: Learning iterations - '100000.500000.1000000'
    11: Maximum Population Size - '1000'
    12: Subsumption Setting - '0' or '1'
    13: Selection Method - '0' (roulete wheel) or '1' (tournament) 
    
Command Line Run Example:
psuedo code: python ./XCS_Main.py environment TrainData TestData OutProgName outPopName CodeBits Reward CVPartitions TrackingCycles LearningIterations MaxPop Subsumption Selection
actual code: python ./XCS_Main.py gh /SomePath/SomeTrainfile.txt /SomePath/SomeTestfile.txt /SomePath/SomeProgressName /SomePath/SomeFinalPopName 2 1000 10 50 1000000 1000 0 0

"""

graphPerformance = False # Built in graphing ability, currently not functional, but mechanism is in place. NOT MEANT TO BE USED ON CLUSTER.
numArgs = len(argv)
print "Arguments: " + str(numArgs)
if numArgs == 14:
    if argv[1]=='gh':
        print ("Format Training data: "+argv[2]+"  using a "+argv[6]+" bit coding scheme.")
        
        #Sets up up algorithm to be run.
        e = Environment()
        e = GHEnvironment(str(argv[2]), str(argv[3]), int(argv[6]), int(argv[7]))
        sampleSize = e.getNrSamples()
        xcs = XCS(e, argv[4], argv[5], int(argv[6]), int(argv[8]), graphPerformance)   

        #Figure out the iteration stops for evaluation, and the max iterations.
        iterList = argv[10].split('.')
        for i in range(len(iterList)):
            iterList[i] = int(iterList[i])
        lastIter = iterList[len(iterList)-1]

        #Set some XCS parameters.
        if argv[9] == 'Default':
            xcs.setTrackingIterations(sampleSize)
        else:
            xcs.setTrackingIterations(int(argv[9]))
        xcs.setNumberOfTrials(lastIter, iterList)
        xcs.setPopulationSize(int(argv[11]))
        xcs.setSubsumption(int(argv[12]))
        xcs.setSelection(int(argv[13]))  
        
        #Run the XCS Algorithm   
        xcs.runXCS()        
        
    else:
        print "There is no environment handeling code for the specified environment"
else:
    print (helpstr)
    sys.exit()

"""
    Additions/Modifications made to the original python XCS script
    1.) Added an environment module designed to handle data mining environments (SNP data input specific codings)
    2.) Added an option to use tournament selection for the GA
    3.) Added the ability to manipulate from the command line the following parameters - (number of iterations, epoch size, performance report size, the use of subsumption
        max population size, number of experiments (arbitrary to new script setup).
    4.) Added the ability to learn in epochs (runs of entire datasets) - more of an alternative learning and tracking perspective
    5.) Added the ability to perform cross validation partitioning and assessment of the dataset within this script. (perhaps this could later be better parallelized outside of this script in a cluster script.
    6.) Prints out a second output file that shows the current ruleset, along with summary info on the population performance.
"""
