# coding=gbk
#! /usr/bin/python

# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__ = "4rthur"
__date__ = "$2010-4-27 16:49:30$"

from FXCS_Helper_Generator import *
import sys
import random

def Decimal2Binary(dec_num):
    """ Return the binary representation of dec_num """
    if dec_num == 0: return ''
    head, tail = divmod(dec_num, 2)
    return Decimal2Binary(head) + str(tail)

def Decimal2BinaryUsingLength(dec_num, length):
    binaryStr = Decimal2Binary(dec_num)
    if len(binaryStr) < length:
        return '0'*(length-len(binaryStr))+binaryStr
    return binaryStr

if __name__ == "__main__":
    try:
        headList = ['cond1','cond2','cond3','cond4','action']
        typeList = ['discrete','discrete','continuous','continuous','0 1 2 3 4']
        classList = ['\t','\t','class']
        condNum = 5
        actionNum = 5
        condLengthList = ['5','5']
        # generate random conditions
        dsList = []
            
        l = 0
        ruleSet = []
        ruleSet.append([['00010','11111'],'11111111'])
        ruleSet.append([['11111','00010'],'22222222'])
        ruleSet.append([['11000','10000'],'33333333'])
        ruleSet.append([['00100','00111'],'44332211'])
        ruleSet.append([['11100','00111'],'00443322'])
        
        for i in range(4):
                for j in range(4):
                        l = 0
                        while l < 1:
                            m = 0
                            while m < 1:
                                if i <= 1 and j == 0:
                                    memAction = []
                                    ruleLen = len(ruleSet)
                                    maxVal = 0
                                    computedOutput = 0
                                    for l2 in range(ruleLen):
                                        tmpVal = fxcsHelper.getMatchDegree(ruleSet[l2][0], [l,m])
                                        if maxVal < tmpVal:
                                            maxVal = tmpVal
                                            computedOutput = ruleSet[l2][1][0]
                                    cond = []
                                    cond.append(Decimal2BinaryUsingLength(i, 2))
                                    cond.append(Decimal2BinaryUsingLength(j, 2))
                                    cond.append(Decimal2BinaryUsingLength(int(l/0.0625), 4))
                                    cond.append(Decimal2BinaryUsingLength(int(m/0.0625), 4))
                                    '''
                                    
                                    cond.append(Decimal2BinaryUsingLength(int(l/0.03125), 5))
                                    cond.append(Decimal2BinaryUsingLength(int(m/0.03125), 5))
                                    '''
                                    if i == 0:
                                        cond.append('0')
                                    else:
                                        cond.append(str(computedOutput))
                                    #cond.append('|')
                                    #for i in range(len(memAction)):
                                    #    cond.append(str(memAction[i][1]))
                                    dsList.append(cond)
                                    print str(l)+" "+str(m)
                                elif i <= 1 and j == 1:
                                    memAction = []
                                    ruleLen = len(ruleSet)
                                    maxVal = 0
                                    computedOutput = 0
                                    for l2 in range(ruleLen):
                                        tmpVal = fxcsHelper.getMatchDegree(ruleSet[l2][0], [l,m])
                                        if maxVal < tmpVal:
                                            maxVal = tmpVal
                                            computedOutput = ruleSet[l2][1][1]
                                    cond = []
                                    cond.append(Decimal2BinaryUsingLength(i, 2))
                                    cond.append(Decimal2BinaryUsingLength(j, 2))
                                    cond.append(Decimal2BinaryUsingLength(int(l/0.0625), 4))
                                    cond.append(Decimal2BinaryUsingLength(int(m/0.0625), 4))
                                    '''
                                    
                                    cond.append(Decimal2BinaryUsingLength(int(l/0.03125), 5))
                                    cond.append(Decimal2BinaryUsingLength(int(m/0.03125), 5))
                                    '''
                                    if i == 0:
                                        cond.append('0')
                                    else:
                                        cond.append(str(computedOutput))
                                    #cond.append('|')
                                    #for i in range(len(memAction)):
                                    #    cond.append(str(memAction[i][1]))
                                    dsList.append(cond)
                                    print str(l)+" "+str(m)
                                elif i <= 1 and j == 2:
                                    memAction = []
                                    ruleLen = len(ruleSet)
                                    maxVal = 0
                                    computedOutput = 0
                                    for l2 in range(ruleLen):
                                        tmpVal = fxcsHelper.getMatchDegree(ruleSet[l2][0], [l,m])
                                        if maxVal < tmpVal:
                                            maxVal = tmpVal
                                            computedOutput = ruleSet[l2][1][2]
                                    cond = []
                                    cond.append(Decimal2BinaryUsingLength(i, 2))
                                    cond.append(Decimal2BinaryUsingLength(j, 2))
                                    cond.append(Decimal2BinaryUsingLength(int(l/0.0625), 4))
                                    cond.append(Decimal2BinaryUsingLength(int(m/0.0625), 4))
                                    '''
                                    
                                    cond.append(Decimal2BinaryUsingLength(int(l/0.03125), 5))
                                    cond.append(Decimal2BinaryUsingLength(int(m/0.03125), 5))
                                    '''
                                    cond.append(str(computedOutput))
                                    #cond.append('|')
                                    #for i in range(len(memAction)):
                                    #    cond.append(str(memAction[i][1]))
                                    dsList.append(cond)
                                    print str(l)+" "+str(m)
                                elif i <= 1 and j == 3:
                                    memAction = []
                                    ruleLen = len(ruleSet)
                                    maxVal = 0
                                    computedOutput = 0
                                    for l2 in range(ruleLen):
                                        tmpVal = fxcsHelper.getMatchDegree(ruleSet[l2][0], [l,m])
                                        if maxVal < tmpVal:
                                            maxVal = tmpVal
                                            computedOutput = ruleSet[l2][1][3]
                                    cond = []
                                    cond.append(Decimal2BinaryUsingLength(i, 2))
                                    cond.append(Decimal2BinaryUsingLength(j, 2))
                                    cond.append(Decimal2BinaryUsingLength(int(l/0.0625), 4))
                                    cond.append(Decimal2BinaryUsingLength(int(m/0.0625), 4))
                                    '''
                                    
                                    cond.append(Decimal2BinaryUsingLength(int(l/0.03125), 5))
                                    cond.append(Decimal2BinaryUsingLength(int(m/0.03125), 5))
                                    '''
                                    if i == 0:
                                        cond.append('0')
                                    else:
                                        cond.append(str(computedOutput))
                                    #cond.append('|')
                                    #for i in range(len(memAction)):
                                    #    cond.append(str(memAction[i][1]))
                                    dsList.append(cond)
                                    print str(l)+" "+str(m)
                                elif i > 1 and j == 0:
                                    memAction = []
                                    ruleLen = len(ruleSet)
                                    maxVal = 0
                                    computedOutput = 0
                                    for l2 in range(ruleLen):
                                        tmpVal = fxcsHelper.getMatchDegree(ruleSet[l2][0], [l,m])
                                        if maxVal < tmpVal:
                                            maxVal = tmpVal
                                            computedOutput = ruleSet[l2][1][4]
                                    cond = []
                                    cond.append(Decimal2BinaryUsingLength(i, 2))
                                    cond.append(Decimal2BinaryUsingLength(j, 2))
                                    cond.append(Decimal2BinaryUsingLength(int(l/0.0625), 4))
                                    cond.append(Decimal2BinaryUsingLength(int(m/0.0625), 4))
                                    '''
                                    
                                    cond.append(Decimal2BinaryUsingLength(int(l/0.03125), 5))
                                    cond.append(Decimal2BinaryUsingLength(int(m/0.03125), 5))
                                    '''
                                    cond.append(str(computedOutput))
                                    #cond.append('|')
                                    #for i in range(len(memAction)):
                                    #    cond.append(str(memAction[i][1]))
                                    dsList.append(cond)
                                    print str(l)+" "+str(m)
                                elif i > 1 and j == 1:
                                    memAction = []
                                    ruleLen = len(ruleSet)
                                    maxVal = 0
                                    computedOutput = 0
                                    for l2 in range(ruleLen):
                                        tmpVal = fxcsHelper.getMatchDegree(ruleSet[l2][0], [l,m])
                                        if maxVal < tmpVal:
                                            maxVal = tmpVal
                                            computedOutput = ruleSet[l2][1][5]
                                    cond = []
                                    cond.append(Decimal2BinaryUsingLength(i, 2))
                                    cond.append(Decimal2BinaryUsingLength(j, 2))
                                    cond.append(Decimal2BinaryUsingLength(int(l/0.0625), 4))
                                    cond.append(Decimal2BinaryUsingLength(int(m/0.0625), 4))
                                    '''
                                    
                                    cond.append(Decimal2BinaryUsingLength(int(l/0.03125), 5))
                                    cond.append(Decimal2BinaryUsingLength(int(m/0.03125), 5))
                                    '''
                                    cond.append(str(computedOutput))
                                    #cond.append('|')
                                    #for i in range(len(memAction)):
                                    #    cond.append(str(memAction[i][1]))
                                    dsList.append(cond)
                                    print str(l)+" "+str(m)
                                elif i > 1 and j == 2:
                                    memAction = []
                                    ruleLen = len(ruleSet)
                                    maxVal = 0
                                    computedOutput = 0
                                    for l2 in range(ruleLen):
                                        tmpVal = fxcsHelper.getMatchDegree(ruleSet[l2][0], [l,m])
                                        if maxVal < tmpVal:
                                            maxVal = tmpVal
                                            computedOutput = ruleSet[l2][1][6]
                                    cond = []
                                    cond.append(Decimal2BinaryUsingLength(i, 2))
                                    cond.append(Decimal2BinaryUsingLength(j, 2))
                                    cond.append(Decimal2BinaryUsingLength(int(l/0.0625), 4))
                                    cond.append(Decimal2BinaryUsingLength(int(m/0.0625), 4))
                                    '''
                                    
                                    cond.append(Decimal2BinaryUsingLength(int(l/0.03125), 5))
                                    cond.append(Decimal2BinaryUsingLength(int(m/0.03125), 5))
                                    '''
                                    cond.append(str(computedOutput))
                                    #cond.append('|')
                                    #for i in range(len(memAction)):
                                    #    cond.append(str(memAction[i][1]))
                                    dsList.append(cond)
                                    print str(l)+" "+str(m)
                                elif i > 1 and j == 3:
                                    memAction = []
                                    ruleLen = len(ruleSet)
                                    maxVal = 0
                                    computedOutput = 0
                                    for l2 in range(ruleLen):
                                        tmpVal = fxcsHelper.getMatchDegree(ruleSet[l2][0], [l,m])
                                        if maxVal < tmpVal:
                                            maxVal = tmpVal
                                            computedOutput = ruleSet[l2][1][7]
                                    cond = []
                                    cond.append(Decimal2BinaryUsingLength(i, 2))
                                    cond.append(Decimal2BinaryUsingLength(j, 2))
                                    cond.append(Decimal2BinaryUsingLength(int(l/0.0625), 4))
                                    cond.append(Decimal2BinaryUsingLength(int(m/0.0625), 4))
                                    '''
                                    
                                    cond.append(Decimal2BinaryUsingLength(int(l/0.03125), 5))
                                    cond.append(Decimal2BinaryUsingLength(int(m/0.03125), 5))
                                    '''
                                    cond.append(str(computedOutput))
                                    #cond.append('|')
                                    #for i in range(len(memAction)):
                                    #    cond.append(str(memAction[i][1]))
                                    dsList.append(cond)
                                    print str(l)+" "+str(m)

                                m = m+0.0625
                            l = l+0.0625
                    
                
        
        
        shuffle(dsList) 
        print 'generate data complete\n'
        
        trainFile = open('dataset_train_final_u4.txt', 'w')
        trainFile.write('\t'.join(headList)+'\n')
        trainFile.write('\t'.join(typeList)+'\n')
        trainFile.write('\t'.join(classList)+'\n')
        for i in range(3687):
            trainFile.write('\t'.join(dsList[i]) + '\n')
        trainFile.close()
        testFile = open('dataset_test_final_u4.txt', 'w')
        testFile.write('\t'.join(condLengthList)+'\n')
        testFile.write('\t'.join(headList)+'\n')
        for i in range(3687,4096):
            testFile.write('\t'.join(dsList[i]) + '\n')
        testFile.close()
    except IOError, (errno, strerror):
        print ("Could not Read File!")
        print ("I/O error(%s): %s" % (errno, strerror))
        raise
    except ValueError:
        print ("Could not convert data to an integer.")
        raise
    except:
        print ("Unexpected error:", sys.exc_info()[0])
        raise
