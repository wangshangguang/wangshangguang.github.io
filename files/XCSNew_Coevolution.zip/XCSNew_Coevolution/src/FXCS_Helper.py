# coding=gbk
#!/usr/bin/env python

from random import *
from XCS_Constants import *
import membership

def Decimal2Binary(dec_num):
    """ Return the binary representation of dec_num """
    if dec_num == 0: return ''
    head, tail = divmod(dec_num, 2)
    return Decimal2Binary(head) + str(tail)

def Decimal2BinaryUsingLength(dec_num, length):
    binaryStr = Decimal2Binary(dec_num)
    if len(binaryStr) < length:
        return '0'*(length-len(binaryStr))+binaryStr
    return binaryStr

class FXCSHelper:
    def __init__(self):
        '''��ɢ���������Ƴ���'''
        self.dcList = [2,2]
        '''ģ��������'''
        self.lingList = [5,5,5]
        self.mfList = [[-0.25,0,0.25],[0,0.25,0.5],[0.25,0.5,0.75],[0.5,0.75,1],[0.75,1,1.25]]
        self.fuzzySets = []
        self.fuzzySets.append(membership.CreateSet('triangular', 'VS', self.mfList[0]))
        self.fuzzySets.append(membership.CreateSet('triangular', 'S', self.mfList[1]))
        self.fuzzySets.append(membership.CreateSet('triangular', 'M', self.mfList[2]))
        self.fuzzySets.append(membership.CreateSet('triangular', 'L', self.mfList[3]))
        self.fuzzySets.append(membership.CreateSet('triangular', 'VL', self.mfList[4]))
    
    def getMatchDegree(self, condition, state):
        condLen = len(condition)
        matchDegree = 1.0
        #print 'condition is',condition,'state is',state
        for i in range(condLen):
            if i < int(condLen/2.0):
                varDegree = self.getDCondVarMatchDegree(condition[i], state[i], self.dcList[i])
                if varDegree == 0:
                    return 0
                elif varDegree == 1.0:
                    continue
                else:
                    matchDegree *= varDegree
#                print 'D',self.getDCondVarMatchDegree(condition[i], state[i], self.dcList[i])
            else:
                varDegree = self.getCondVarMatchDegree(condition[i], float(state[i]))
                if varDegree == 0:
                    return 0
                elif varDegree == 1.0:
                    continue
                else:
                    matchDegree *= varDegree
#                print 'C',self.getCondVarMatchDegree(condition[i], float(state[i]))
        return matchDegree
    
    def getDCondVarMatchDegree(self, condStr, stateVal, length):
        
        for i in range(len(condStr)):
            if condStr[i] != cons.dontCare and condStr[i] != stateVal[i]:
                return 0
        return 1
        
        
    def getCondVarMatchDegree(self, condStr, stateVal):
        binLen = len(condStr)
        matchDegree = 0
        if not '0' in condStr:
            return 1.0
        for i in range(binLen):
            if condStr[i] == '1':
                matchDegree += self.getMemberVal(i, stateVal)
        return min(1.0, matchDegree)
    
    def getMemberVal(self, index, val):
        if val <= self.mfList[index][1]:
            if val < self.mfList[index][0]:
                return 0.0
            else:
                return 1.0-(self.mfList[index][1]-val)/float(self.mfList[index][1]-self.mfList[index][0])
        else:
            if val > self.mfList[index][2]:
                return 0.0
            else:
                return 1.0-(val-self.mfList[index][1])/float(self.mfList[index][2]-self.mfList[index][1])
       
    '''����Discrete Condition'''
    def getRandDCEncoding(self, index):
        condLength = len(self.dcList[index])
        condArray = []
        for i in range(condLength):
            if random() < cons.P_dontcare:
                condArray.append(cons.dontCare)
            else:
                condArray.append(choice(['0','1']))
        return ''.join(condArray)
    
    def getRandCCEncoding(self, index):
        condLen = self.lingList[index]
        condList = []
        condList.append('1')
        for i in range(condLen-1):
            condList.append('0')
            
        from random import shuffle
        shuffle(condList)
        return ''.join(condList)
    
    def isInclude(self, listS, listT):
        listLen = len(listS)
        for i in range(listLen):
            if listS[i] == '0' and listT[i] == '1':
                return False
        return True
    
    def getMatchEncoding(self, condVal):
        if condVal == self.mfList[0][1]:
            return '10000'
        elif condVal == self.mfList[1][1]:
            return '01000'
        elif condVal == self.mfList[2][1]:
            return '00100'
        elif condVal == self.mfList[3][1]:
            return '00010'
        elif condVal == self.mfList[4][1]:
            return '00001'
        elif condVal>self.mfList[0][1] and condVal<self.mfList[1][1]:
            return '11000'
        elif condVal>self.mfList[1][1] and condVal<self.mfList[2][1]:
            return '01100'
        elif condVal>self.mfList[2][1] and condVal<self.mfList[3][1]:
            return '00110'
        elif condVal>self.mfList[3][1] and condVal<self.mfList[4][1]:
            return '00011'
        elif condVal < self.mfList[0][1]:
            return '10000'
        else:
            return '00001'
    def getCreateEncoding(self, condVal):
        if condVal == self.mfList[0][1]:
            return '10000'
        elif condVal == self.mfList[1][1]:
            return '01000'
        elif condVal == self.mfList[2][1]:
            return '00100'
        elif condVal == self.mfList[3][1]:
            return '00010'
        elif condVal == self.mfList[4][1]:
            return '00001'
        elif condVal>self.mfList[0][1] and condVal<self.mfList[1][1]:
            return '11000'
        elif condVal>self.mfList[1][1] and condVal<self.mfList[2][1]:
            return '01100'
        elif condVal>self.mfList[2][1] and condVal<self.mfList[3][1]:
            return '00110'
        elif condVal>self.mfList[3][1] and condVal<self.mfList[4][1]:
            return '00011'
        elif condVal < self.mfList[0][1]:
            return '10000'
        else:
            return '00001'
    def getCreateEncoding2(self, condVal):
        
        if condVal>=0 and condVal<=self.mfList[0][1]:
            '''VS'''
            return '10000'
        elif condVal>=self.mfList[0][1] and condVal<=self.mfList[1][1]:
            '''VS or S'''
            if condVal > (self.mfList[0][1]+self.mfList[1][1])/2.0:
                return '01000'
            elif condVal < (self.mfList[0][1]+self.mfList[1][1])/2.0:
                return '10000'
            else:
                return '11000'
        elif condVal>=self.mfList[1][1] and condVal<=self.mfList[2][1]:
            '''S or M'''
            if condVal > (self.mfList[1][1]+self.mfList[2][1])/2.0:
                return '00100'
            elif condVal < (self.mfList[1][1]+self.mfList[2][1])/2.0:
                return '01000'
            else:
                return '01100'
        elif condVal>=self.mfList[2][1] and condVal<=self.mfList[3][1]:
            '''M or L'''
            if condVal > (self.mfList[2][1]+self.mfList[3][1])/2.0:
                return '00010'
            elif condVal < (self.mfList[2][1]+self.mfList[3][1])/2.0:
                return '00100'
            else:
                return '00110'
        elif condVal>=self.mfList[3][1] and condVal<=self.mfList[4][1]:
            '''M or L'''
            if condVal > (self.mfList[3][1]+self.mfList[4][1])/2.0:
                return '00001'
            elif condVal < (self.mfList[3][1]+self.mfList[4][1])/2.0:
                return '00010'
            else:
                return '00011'
        else:
            '''VL'''
            return '00001'
        
    def getDCEncodingLength(self, index):
        return self.dcList[index]
    
    
fxcsHelper = FXCSHelper()
'''����'''
#fxcsHelper.getMatchDegree(['##', '#0#', '00111', '00110', '11100'], ['00', '101', '0.8125', '0.625', '0.1875'])
