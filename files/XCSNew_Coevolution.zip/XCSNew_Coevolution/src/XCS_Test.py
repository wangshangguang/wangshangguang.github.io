# coding=gbk
#-------------------------------------------------------------------------------
# Name:            XCS_Test.py
# Purpose:         Translation of the XCS system to Python
# Original Author: Martin V. Butz (in Java 1.0) - translated to python by Jose Antonio Martin H. <jamartin@dia.fi.upm.es>
# Copyright:       (c) Jose Antonio Martin H. 2007
# Created:         01/16/2007
# Licence:         <GPL>
# Modified by:     Ryan Urbanowicz 01/18/2009 (ryanurbanowicz@gmail.com) 
# Updated:         08/10/2009
# Status:          FUNCTIONAL * FINAL * v.1.0
# Description:     A testing replacement for XCS_Main.py to run XCS from Eclipse.
#-------------------------------------------------------------------------------
#!/usr/bin/env python

#Import modules
from XCS import *
from XCS_PbmEnvironment import *

def main():
    #RUN PARAMETERS
    graphPerformance = False
    '''�趨ѵ�����ݼ�&�������ݼ�'''
    trainData = "F:\\Works\\Program\\Python\\XCSNew\\src\\dataset_train.txt"
    testData = "F:\\Works\\Program\\Python\\XCSNew\\src\\dataset_test.txt"
    outProg = "GH_XCS_ProgressTrack"
    outPop = "GH_XCS_PopulationOut"
    '''������'''
    nrActions = 5
    '''�ر�'''
    reward = 1000
    CVpartitions = 10
    '''ѭ������'''
    iterInput = '2000'
    #trackCycles = 'Default' # set tracking cycles to number of data samples - trackCycles = 100
    '''ÿ���ٴμ���һ�¾�ȷ��''' 
    trackCycles = 100
    '''��Ⱥ��С'''
    pop = 2000
    sub = 0
    select = 0
    
    #Figure out the iteration stops for evaluation, and the max iterations.
    iterList = iterInput.split('.')
    for i in range(len(iterList)):
        iterList[i] = int(iterList[i])
    lastIter = iterList[len(iterList)-1]
    
    #Sets up up algorithm to be run.
    '''�������⻷�����Լ�XCS����'''
    e = PbmEnvironment(trainData,testData,nrActions,reward)
    sampleSize = e.getNrSamples()
    xcs = XCS(e, outProg, outPop, CVpartitions, graphPerformance)
    
    #Set some XCS parameters.
    if trackCycles == 'Default':
        xcs.setTrackingIterations(sampleSize)
    else:
        xcs.setTrackingIterations(trackCycles)
    xcs.setNumberOfTrials(lastIter,iterList)
    xcs.setPopulationSize(pop)
    xcs.setSubsumption(sub)
    xcs.setSelection(select)     

    #Run the XCS Algorithm  
    '''ִ�в���'''
    xcs.runXCS()
if __name__ == '__main__':
    main()
