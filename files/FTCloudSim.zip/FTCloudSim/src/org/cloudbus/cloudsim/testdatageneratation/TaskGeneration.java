package org.cloudbus.cloudsim.testdatageneratation;

import org.cloudbus.cloudsim.checkpoint.RecordToLogger;
import org.cloudbus.cloudsim.distributions.UniformDistr;

public class TaskGeneration {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		long appSize = 0;
		long length = 0;
		long fileSize = 300;
		long outputSize = 300;
		long memory = 512;
		int pesNumber = 1;
		String utilizationModelCPU = "full";
		String utilizationModelRAM = "full";
		String utilizationModelBW = "full";
		UniformDistr uniformDistrTaskSize = new UniformDistr(36000, 72000, System.currentTimeMillis());
		UniformDistr uniformDistrAppSize = new UniformDistr(20,80, System.currentTimeMillis());
		
		
		String index = " ";
		int appNum = 0;
		int i = 0;
		RecordToLogger.logger.info("%%");
		while(i < 3000){			
			appSize = (long)uniformDistrAppSize.sample();
			appNum++;
			for(int j = 0; j < appSize && i < 3000; j++){
				i++;
				length = (long)uniformDistrTaskSize.sample();
				RecordToLogger.logger.info(length+index+pesNumber+index+fileSize+index+outputSize+index+
						memory+index+utilizationModelCPU+index+utilizationModelRAM+index+utilizationModelBW);
			}
			RecordToLogger.logger.info("%%");			
		}
	}

}
