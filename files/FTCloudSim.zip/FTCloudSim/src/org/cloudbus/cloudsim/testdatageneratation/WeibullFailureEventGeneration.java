package org.cloudbus.cloudsim.testdatageneratation;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.VmSchedulerTimeShared;
import org.cloudbus.cloudsim.CKP.datacenter.Config;
import org.cloudbus.cloudsim.CKP.datacenter.DCNetwork;
import org.cloudbus.cloudsim.CKP.datacenter.DataCenterLink;
import org.cloudbus.cloudsim.CKP.datacenter.EdgeSwitch;
import org.cloudbus.cloudsim.CKP.datacenter.NetDatacenterBroker;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkConstants;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkDatacenter;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkDatacenterCharacteristics;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkHost;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkVmAllocationPolicy;
import org.cloudbus.cloudsim.checkpoint.CentralCheckpointStorageIndex;
import org.cloudbus.cloudsim.checkpoint.CloudletRecoveryScheduler;
import org.cloudbus.cloudsim.checkpoint.DatacenterDestroyer;
import org.cloudbus.cloudsim.checkpoint.RecordToLogger;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.distributions.UniformDistr;
import org.cloudbus.cloudsim.distributions.WeibullDistr;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;

public class WeibullFailureEventGeneration {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
			try {
					int num_user = 1; // number of cloud users
					Calendar calendar = Calendar.getInstance();
					boolean trace_flag = false; // mean trace events

					// Initialize the CloudSim library
					CloudSim.init(num_user, calendar, trace_flag);

					// Second step: Create Datacenters
					// Datacenters are the resource providers in CloudSim. We need at
					// list one of them to run a CloudSim simulation
					NetworkDatacenter datacenter0 = createDatacenter("Datacenter_0");
				} catch (Exception e) {
					e.printStackTrace();
					RecordToLogger.logger.info("Unwanted errors happen");
				}
	}
	

	/**
	 * Creates the datacenter.
	 * 
	 * @param name
	 *            the name
	 * 
	 * @return the datacenter
	 * @throws IOException 
	 */
	private static NetworkDatacenter createDatacenter(String name) throws IOException {
		int portNum = Config.portNum;		
		int hostNum = (portNum*portNum*portNum)/4;	
		
		List<NetworkHost> hostList = new ArrayList<NetworkHost>();
		int mips = 1000;
		int ram = 2048; // host memory (MB)
		long storage = 1000000; // host storage
		int bw = 10000;
		int x = 3;
		int hostNumPerPad = (portNum*portNum)/4;
		for (int y = 0; y < hostNum; y++) {
			List<Pe> peList = new ArrayList<Pe>();
			peList.add(new Pe(0, new PeProvisionerSimple(mips))); // need to
			NetworkHost host = new NetworkHost(
					"host_"+x+"_"+y,
					new RamProvisionerSimple(ram),
					new BwProvisionerSimple(bw),
					storage,
					peList,
					new VmSchedulerTimeShared(peList),
					x,y,
					y/hostNumPerPad);
			hostList.add(host); // This is our machine
		}

		
		String arch = "x86"; // system architecture
		String os = "Linux"; // operating system
		String vmm = "Xen";
		double time_zone = 10.0; // time zone this resource located
		double cost = 3.0; // the cost of using processing in this resource
		double costPerMem = 0.05; // the cost of using memory in this resource
		double costPerStorage = 0.001; // the cost of using storage in this resource
		double costPerBw = 0.0; // the cost of using bw in this resource
		LinkedList<Storage> storageList = new LinkedList<Storage>(); // we are

		NetworkDatacenterCharacteristics characteristics = new NetworkDatacenterCharacteristics(
				arch,
				os,
				vmm,
				hostList,
				time_zone,
				cost,
				costPerMem,
				costPerStorage,
				costPerBw);

		NetworkDatacenter datacenter = null;
		try {
			datacenter = new NetworkDatacenter(
					name,
					characteristics,
					new NetworkVmAllocationPolicy(hostList),
					storageList,
					0,
					new CloudletRecoveryScheduler("CloudletRecoveryScheduler"),
					new CentralCheckpointStorageIndex("CheckpointStorageIndex"),
					new DatacenterDestroyer("DatacenterDestroyer"));

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		DCNetwork dcn = datacenter.getCharacteristics().getDatacenternetwork();
		
		//����ʱ��ǵû�����
		Random r = new Random(System.currentTimeMillis());
		UniformDistr udr7 = new UniformDistr(0, 7, System.currentTimeMillis());
		UniformDistr udr15 = new UniformDistr(0, 15, System.currentTimeMillis());
		UniformDistr uniformDistrA = new UniformDistr(0.7, 0.8, System.currentTimeMillis());
		UniformDistr uniformDistrB = new UniformDistr(15, 20, System.currentTimeMillis());
		UniformDistr uniformDistrHappenTime = new UniformDistr(0.2, 10, System.currentTimeMillis());
		UniformDistr uniformDistrHappenFrequency= new UniformDistr(1, 3, System.currentTimeMillis());
		String index = " ";
		DecimalFormat df = new DecimalFormat("0.00");
		List <NetworkHost> selectedhosts = new ArrayList<NetworkHost>();
		for(int i = 0; i < dcn.getEdgeSwitchList().size(); i++){
			EdgeSwitch eswitch = dcn.getEdgeSwitchList().get(i);
			
			List <NetworkHost> nhosts = new ArrayList<NetworkHost>();
			Iterator iter = eswitch.hostlist.entrySet().iterator();
			while (iter.hasNext()) {
				Map.Entry entry = (Map.Entry) iter.next();
				NetworkHost val = (NetworkHost)entry.getValue();
				nhosts.add(val);
			}
			selectedhosts.clear();
			if(portNum == 16){
				for(int j = 0; j < 1; j++){
					String s = "";
					NetworkHost failureHost = nhosts.get((int)udr7.sample());
					while(selectedhosts.contains(failureHost)){
						failureHost = nhosts.get((int)udr7.sample());
					}
					selectedhosts.add(failureHost);
					double a = Double.parseDouble(df.format(uniformDistrA.sample()));
					long b = (long)uniformDistrB.sample();
					long happenTime = (long)(uniformDistrHappenTime.sample()*3600);
					int happenFrequency = (int)(uniformDistrHappenFrequency.sample());
					WeibullDistr wd = new WeibullDistr(r,a,b);
					long interval = 0;
					while(true){
						interval = (long)(wd.sample()*3600);
						if(happenTime - interval < 0){
							long lastFailureTime = happenTime - interval;
							long repairTime = happenTime + 3*3600;
							s = s + failureHost.getId()+index+happenFrequency+index+lastFailureTime+
									index+"Weibull"+index+a+":"+b+index+"F"+index+happenTime+index+"R"+index+repairTime;
							RecordToLogger.logger.info(s);
							break;
						}
					}
				}
			}
			else if(Config.portNum == 32){
				for(int j = 0; j < 2; j++){
					String s = "";
					NetworkHost failureHost = nhosts.get((int)udr7.sample());
					while(selectedhosts.contains(failureHost)){
						failureHost = nhosts.get((int)udr7.sample());
					}
					selectedhosts.add(failureHost);
					double a = Double.parseDouble(df.format(uniformDistrA.sample()));
					long b = (long)uniformDistrB.sample();
					long happenTime = (long)(uniformDistrHappenTime.sample()*3600);
					int happenFrequency = (int)(uniformDistrHappenFrequency.sample());
					WeibullDistr wd = new WeibullDistr(r,a,b);
					long interval = 0;
					while(true){
						interval = (long)(wd.sample()*3600);
						if(happenTime - interval < 0){
							long lastFailureTime = happenTime - interval;
							long repairTime = happenTime + 3*3600;
							s = s + failureHost.getId()+index+happenFrequency+index+lastFailureTime+
									index+"Weibull"+index+a+":"+b+index+"F"+index+happenTime+index+"R"+index+repairTime;
							RecordToLogger.logger.info(s);
							break;
						}
					}
				}
			}
		}
		return datacenter;
	}



}
