package org.cloudbus.cloudsim.testdatageneratation;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.VmSchedulerTimeShared;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkHost;
import org.cloudbus.cloudsim.checkpoint.RecordToLogger;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.distributions.UniformDistr;
import org.cloudbus.cloudsim.distributions.WeibullDistr;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;

/*
 * ��checkpoint
 */
public class FailureEventGeneration {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
				try {
					int num_user = 1; // number of cloud users
					Calendar calendar = Calendar.getInstance();
					boolean trace_flag = false; // mean trace events

					// Initialize the CloudSim library
					CloudSim.init(num_user, calendar, trace_flag);

					int portNum = 16;		
					int hostNum = (portNum*portNum*portNum)/4;	

					
					List<NetworkHost> hostList = new ArrayList<NetworkHost>();
					int mips = 1000;
					int ram = 2048; // host memory (MB)
					long storage = 1000000; // host storage
					int bw = 10000;
					int x = 3;
					int hostNumPerPad = (portNum*portNum)/4;
					for (int y = 0; y < hostNum; y++) {
						List<Pe> peList = new ArrayList<Pe>();
						peList.add(new Pe(0, new PeProvisionerSimple(mips))); // need to
						NetworkHost host = new NetworkHost(
								"host_"+x+"_"+y,
								new RamProvisionerSimple(ram),
								new BwProvisionerSimple(bw),
								storage,
								peList,
								new VmSchedulerTimeShared(peList),
								x,y,
								y/hostNumPerPad);
						hostList.add(host); // This is our machine
					}
					
					//����ʱ��ǵû�����
					Random r = new Random(System.currentTimeMillis());
					UniformDistr udr7 = new UniformDistr(0, hostNum-1, System.currentTimeMillis());
					
					double a = 0.75;
					long b = 20;
					UniformDistr uniformDistrHappenTime = new UniformDistr(0.2, 10, System.currentTimeMillis());
					UniformDistr uniformDistrHappenFrequency= new UniformDistr(1, 4, System.currentTimeMillis());
					String index = " ";
					DecimalFormat df = new DecimalFormat("0.00");
					List <NetworkHost> selectedhosts = new ArrayList<NetworkHost>();
					for(int i = 0; i < 30; i++){
						String s = "";
						NetworkHost failureHost = hostList.get((int)udr7.sample());
						while(selectedhosts.contains(failureHost)){
							failureHost = hostList.get((int)udr7.sample());
						}
						selectedhosts.add(failureHost);
						
						long happenTime = (long)(uniformDistrHappenTime.sample()*3600);
						int happenFrequency = (int)(uniformDistrHappenFrequency.sample());
						WeibullDistr wd = new WeibullDistr(r,a,b);
						long interval = 0;
						while(true){
							interval = (long)(wd.sample()*3600);
							if(happenTime - interval < 0){
								long lastFailureTime = happenTime - interval;
								long repairTime = happenTime + 3*3600;
								s = s + failureHost.getId()+index+happenFrequency+index+lastFailureTime+
										index+"Weibull"+index+a+":"+b+index+"F"+index+happenTime+index+"R"+index+repairTime;
								RecordToLogger.logger.info(s);
								break;
							}
						}
					}

				} catch (Exception e) {
					e.printStackTrace();
					RecordToLogger.logger.info("Unwanted errors happen");
				}


	}
}
