package org.cloudbus.cloudsim.checkpoint.centralexample;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.VmSchedulerTimeShared;
import org.cloudbus.cloudsim.CKP.datacenter.AggregateSwitch;
import org.cloudbus.cloudsim.CKP.datacenter.Config;
import org.cloudbus.cloudsim.CKP.datacenter.DCNetwork;
import org.cloudbus.cloudsim.CKP.datacenter.DataCenterLink;
import org.cloudbus.cloudsim.CKP.datacenter.EdgeSwitch;
import org.cloudbus.cloudsim.CKP.datacenter.NetDatacenterBroker;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkConstants;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkDatacenter;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkDatacenterCharacteristics;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkHost;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkPacket;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkResCloudlet;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkStorageHost;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkVm;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkVmAllocationPolicy;
import org.cloudbus.cloudsim.CKP.datacenter.RootSwitch;
import org.cloudbus.cloudsim.CKP.datacenter.service.AppNetCloudlet;
import org.cloudbus.cloudsim.checkpoint.CentralCheckpointStorageIndex;
import org.cloudbus.cloudsim.checkpoint.CloudletCheckpoint;
import org.cloudbus.cloudsim.checkpoint.CloudletRecoveryScheduler;
import org.cloudbus.cloudsim.checkpoint.DatacenterDestroyer;
import org.cloudbus.cloudsim.checkpoint.PrintResult;
import org.cloudbus.cloudsim.checkpoint.RandomDistriCheckpointStorageIndex;
import org.cloudbus.cloudsim.checkpoint.FailureEventReader;
import org.cloudbus.cloudsim.checkpoint.RecordToLogger;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;

/*
 * �洢�ڵ����ѡ�� 
 * �ֲ�ʽ
 * ����ʽcheckpoint
 */
public class RamdomDistriDeltaCheckpoint {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RecordToLogger.logger.info("Starting CloudSim RamdomDistriDeltaCheckpoint Example...");
		
		Config.CheckpointStyle = 2;

		try {
			int num_user = 1; // number of cloud users
			Calendar calendar = Calendar.getInstance();
			boolean trace_flag = false; // mean trace events

			// Initialize the CloudSim library
			CloudSim.init(num_user, calendar, trace_flag);

			// Second step: Create Datacenters
			// Datacenters are the resource providers in CloudSim. We need at
			// list one of them to run a CloudSim simulation
			NetworkDatacenter datacenter0 = createDatacenter("Datacenter_0");

			// Third step: Create Broker
			NetDatacenterBroker broker = createBroker();
			broker.setLinkDC(datacenter0);
			// broker.setLinkDC(datacenter0);
			// Fifth step: Create one Cloudlet

			List<NetworkVm> vmlist = new ArrayList<NetworkVm>();

			// submit vm list to the broker

			broker.submitVmList(vmlist);
			
			List<AppNetCloudlet> apps = WorkloadReader.readWorkLoadFile("workload.brite", 0);
			broker.getAppCloudletList().addAll(apps);
			
//			long length = 400;
//			long fileSize = 300;
//			long outputSize = 300;
//			long memory = 256;
//			int pesNumber = 4;
//			UtilizationModel utilizationModel = new UtilizationModelFull();
//			for (int i = 0; i < 1; i++) {
//				AppNetCloudlet app = new AppNetCloudlet(NetworkConstants.currentAppId, 0);
//				for (int j = 0; j < 5; j++){
//					NetworkCloudlet  cloudlet = new NetworkCloudlet(NetworkConstants.currentCloudletId,
//							length,
//							pesNumber,
//							fileSize,
//							outputSize,
//							memory,
//							utilizationModel,
//							utilizationModel,
//							utilizationModel);
//					app.addCloudlet(cloudlet);
//					cloudlet.setUserId(app.userID);
//					NetworkConstants.currentCloudletId++;
//				}
//				broker.getAppCloudletList().add(app);
//				NetworkConstants.currentAppId++;
//
//			}

			// Sixth step: Starts the simulation
			CloudSim.startSimulation();

			CloudSim.stopSimulation();

			// Final step: Print results when simulation is over			
			PrintResult.printResult(datacenter0, broker);
			

			RecordToLogger.logger.info("CloudSim FatTreeDatacenter Example finished!");
		} catch (Exception e) {
			e.printStackTrace();
			RecordToLogger.logger.error("Unwanted errors happen");
		}

	}
	
	/**
	 * Creates the datacenter.
	 * 
	 * @param name
	 *            the name
	 * 
	 * @return the datacenter
	 * @throws IOException 
	 */
	private static NetworkDatacenter createDatacenter(String name) throws IOException {
		int portNum = Config.portNum;
		int hostNum = (portNum*portNum*portNum)/4;
		
		List<NetworkHost> hostList = new ArrayList<NetworkHost>();
		int mips = 1000;
		int ram = 4096; // host memory (MB)
		long storage = 1000000; // host storage
		int bw = 10000;
		int x = 3;
		int hostNumPerPad = (portNum*portNum)/4;
		for (int y = 0; y < hostNum; y++) {
			List<Pe> peList = new ArrayList<Pe>();
			peList.add(new Pe(0, new PeProvisionerSimple(mips))); // need to
			NetworkHost host = new NetworkHost(
					"host_"+x+"_"+y,
					new RamProvisionerSimple(ram),
					new BwProvisionerSimple(bw),
					storage,
					peList,
					new VmSchedulerTimeShared(peList),
					x,y,
					y/hostNumPerPad);
			hostList.add(host); // This is our machine
		}

		
		String arch = "x86"; // system architecture
		String os = "Linux"; // operating system
		String vmm = "Xen";
		double time_zone = 10.0; // time zone this resource located
		double cost = 3.0; // the cost of using processing in this resource
		double costPerMem = 0.05; // the cost of using memory in this resource
		double costPerStorage = 0.001; // the cost of using storage in this resource
		double costPerBw = 0.0; // the cost of using bw in this resource
		LinkedList<Storage> storageList = new LinkedList<Storage>(); // we are

		NetworkDatacenterCharacteristics characteristics = new NetworkDatacenterCharacteristics(
				arch,
				os,
				vmm,
				hostList,
				time_zone,
				cost,
				costPerMem,
				costPerStorage,
				costPerBw);

		NetworkDatacenter datacenter = null;
		try {
			datacenter = new NetworkDatacenter(
					name,
					characteristics,
					new NetworkVmAllocationPolicy(hostList),
					storageList,
					0,
					new CloudletRecoveryScheduler("CloudletRecoveryScheduler"),
					new RandomDistriCheckpointStorageIndex("CheckpointImageStorageIndex"),
					new DatacenterDestroyer("DatacenterDestroyer"));

		} catch (Exception e) {
			e.printStackTrace();
		}

		
		FailureEventReader.readFailureEventFile(System.getProperty("user.dir")+"\\FailureEvent.brite", datacenter.getDatacenterDestroyer());

		return datacenter;
	}

	// We strongly encourage users to develop their own broker policies, to
	// submit vms and cloudlets according
	// to the specific rules of the simulated scenario
	/**
	 * Creates the broker.
	 * 
	 * @return the datacenter broker
	 */
	private static NetDatacenterBroker createBroker() {
		NetDatacenterBroker broker = null;
		try {
			broker = new NetDatacenterBroker("Broker");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return broker;
	}

}
