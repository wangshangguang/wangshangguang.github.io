/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package org.cloudbus.cloudsim.checkpoint.centralexample;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.StringTokenizer;

import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelFull;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkConstants;
import org.cloudbus.cloudsim.CKP.datacenter.service.AppNetCloudlet;
import org.cloudbus.cloudsim.CKP.datacenter.service.NetworkCloudlet;
import org.cloudbus.cloudsim.distributions.UniformDistr;

/**
 * This class is just an file-reader for the special brite-format! the brite-file is structured as
 * followed: Node-section: NodeID, xpos, ypos, indegree, outdegree, ASid, type(router/AS)
 * Edge-section: EdgeID, fromNode, toNode, euclideanLength, linkDelay, linkBandwith, AS_from, AS_to,
 * type
 * 
 * @author Thomas Hohnstein
 * @since CloudSim Toolkit 1.0
 */
public class WorkloadReader {

	/**
	 * this method just reads the file and creates an TopologicalGraph object
	 * 
	 * @param filename name of the file to read
	 * @return created TopologicalGraph
	 * @throws IOException
	 */
	public static List<AppNetCloudlet> readWorkLoadFile(String filename, int userId) throws IOException {

		// lets read the file
		FileReader fr = new FileReader(filename);
		BufferedReader br = new BufferedReader(fr);

		String nextLine = null;
		
		long length = 0;
		long fileSize = 0;
		long outputSize = 0;
		long memory = 0;
		int pesNumber = 0;
		UtilizationModel utilizationModelCPU = null;
		UtilizationModel utilizationModelRAM = null;
		UtilizationModel utilizationModelBW = null;
		double totalLength = 0;
		
		ArrayList<AppNetCloudlet> apps = new ArrayList<AppNetCloudlet>();
		UniformDistr uniformDistrDiskSize = new UniformDistr(500, 502, System.currentTimeMillis());

		while ((nextLine = br.readLine()) != null) {
			if(nextLine.startsWith("//") || nextLine.startsWith("%%") || nextLine.trim().equals(""))
				continue;			
			
			AppNetCloudlet app = new AppNetCloudlet(NetworkConstants.currentAppId, 0, 769+5.3+1.6+512,uniformDistrDiskSize.sample());
			while( nextLine != null  && !nextLine.startsWith("%%") ){
				StringTokenizer tokenizer = new StringTokenizer(nextLine);
				
				for (int actualParam = 0; tokenizer.hasMoreElements() && actualParam < 8; actualParam++) {
					String token = tokenizer.nextToken();
					switch (actualParam) {
						case 0:	
							length = Long.valueOf(token);
							break;	
						case 1:	
							pesNumber = Integer.valueOf(token);
							break;	
						case 2:	
							fileSize = Long.valueOf(token);
							break;
						case 3:	
							outputSize = Long.valueOf(token);
							break;
						case 4:	
							memory = Long.valueOf(token);
							break;
						case 5:	
							utilizationModelCPU = generateUtilizationModel(token);
							break;
						case 6:	
							utilizationModelRAM =  generateUtilizationModel(token);
							break;
						case 7:
							utilizationModelBW =  generateUtilizationModel(token);
							break;
					}
				}
				
				NetworkCloudlet  cloudlet = new NetworkCloudlet(NetworkConstants.currentCloudletId,
						length,
						pesNumber,
						fileSize,
						outputSize,
						memory,
						utilizationModelCPU,
						utilizationModelRAM,
						utilizationModelBW,
						app);
				app.addCloudlet(cloudlet);
				cloudlet.setUserId(app.userID);
				NetworkConstants.currentCloudletId++;
				
				totalLength = totalLength + length;
				
				nextLine = br.readLine();
				
			}
			apps.add(app);
			NetworkConstants.currentAppId++;
		}
		
		br.close();
		System.out.println("total length: "+totalLength);
		return apps;
	}
	
	public static UtilizationModel generateUtilizationModel(String token){
		if(token.equals("full"))
			return  new UtilizationModelFull();
		return new UtilizationModelFull();
	}

}
