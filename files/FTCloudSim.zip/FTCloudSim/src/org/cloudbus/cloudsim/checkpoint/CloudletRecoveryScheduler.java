package org.cloudbus.cloudsim.checkpoint;

import java.util.ArrayList;
import java.util.List;

import org.cloudbus.cloudsim.ResCloudlet;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.CKP.datacenter.AggregateSwitch;
import org.cloudbus.cloudsim.CKP.datacenter.Config;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkCloudletSpaceSharedScheduler;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkDatacenter;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkDatacenterCharacteristics;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkHost;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkResCloudlet;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkVm;
import org.cloudbus.cloudsim.CKP.datacenter.RootSwitch;
import org.cloudbus.cloudsim.CKP.datacenter.service.NetworkCloudlet;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEntity;
import org.cloudbus.cloudsim.core.SimEvent;

public class CloudletRecoveryScheduler  extends SimEntity{
	private NetworkDatacenter datacenter;
	
	public CloudletRecoveryScheduler(String name){
		super(name);
	}
	
	public NetworkDatacenter getDatacenter() {
		return datacenter;
	}

	public void setDatacenter(NetworkDatacenter datacenter) {
		this.datacenter = datacenter;
	}
	
	@Override
	public void startEntity() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void processEvent(SimEvent ev) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void shutdownEntity() {
		// TODO Auto-generated method stub
		
	}

	public void recovery(NetworkHost host){
		RecordToLogger.logger.debug(this.getName() + "| host " + host.getId()+" fail");
		
		host.updateVmsProcessingBeforeFailure(CloudSim.clock());
		
		host.allocatedCKPStorage = 0;
		
		List<Vm> vms = host.getVmList();
		for(int i = 0 ; i < vms.size(); i++){
			NetworkVm  nvm = (NetworkVm)vms.get(i);
			NetworkCloudletSpaceSharedScheduler scheduler = (NetworkCloudletSpaceSharedScheduler)nvm.getCloudletScheduler();
			for (ResCloudlet rcl : scheduler.getCloudletExecList()) {
				NetworkResCloudlet nrcl = (NetworkResCloudlet)rcl;
				NetworkCloudlet cl = (NetworkCloudlet)nrcl.getCloudlet();
				
				List<Integer> hasTaken = new ArrayList<Integer> ();
				
				if(Config.CheckpointStyle == 3)
					hasTaken.addAll(datacenter.getCheckpointimageindex().getAPPCheckpointImageStorageNode(cl.belongToApp.appId));
				
				List<NetworkCloudlet> cls = cl.belongToApp.getCloudletList();
				for(int j = 0; j < cls.size(); j++){
					NetworkCloudlet ncl = cls.get(j);
					NetworkDatacenterCharacteristics chara = (NetworkDatacenterCharacteristics)datacenter.getCharacteristics();
					
					hasTaken.add(chara.VmtoHostlist.get(ncl.getVmId()));
					hasTaken.addAll(datacenter.getCheckpointimageindex().getCloudletCheckpointImageStorageNode(ncl.getCloudletId()));
				}
				
				cl.lastSuspendTime = CloudSim.clock();

				RecordToLogger.logger.debug(this.getName() + "|" + cl.getCloudletId()+" should restart!");
					
				NetworkHost targetHost = null;
				NetworkVm targetVm = null;
				
				List< NetworkHost> hosts = nrcl.getVm().getHost().sw.getHostFromTheSameSubnet(host);				
				for (int j = 0; j < hosts.size(); j++) {
					targetHost = hosts.get(j);
					targetVm = null;
					if(targetHost.isFailed() || hasTaken.contains(targetHost.getId()))
						continue;
					List<Vm> vmList = targetHost.getVmList();
					for(int k = 0 ; k < vmList.size(); k++){
						NetworkVm vm = (NetworkVm)vmList.get(k);
						NetworkCloudletSpaceSharedScheduler ncs = (NetworkCloudletSpaceSharedScheduler)vm.getCloudletScheduler();
						if(ncs.getCloudletExecList().size() == 0){
							targetVm = vm;
							nrcl.getCloudletState().restart();
							nrcl.setVm(targetVm);
							ncs.getCloudletExecList().add(nrcl);
							break;
						}
					}
					if(targetVm != null)
						break;
				}
				
				if(targetVm == null){
					System.err.println(hasTaken.toString());
					AggregateSwitch as = (AggregateSwitch)host.sw.uplinkswitches.get(0);
					hosts = as.getHostFromOtherSubnet(host);
					for (int j = 0; j < hosts.size(); j++) {
						targetHost = hosts.get(j);
						targetVm = null;
						if(targetHost.isFailed() || hasTaken.contains(new Integer(targetHost.getId())))
							continue;
						List<Vm> vmList = targetHost.getVmList();
						for(int k = 0 ; k < vmList.size(); k++){
							NetworkVm vm = (NetworkVm)vmList.get(k);
							NetworkCloudletSpaceSharedScheduler ncs = (NetworkCloudletSpaceSharedScheduler)vm.getCloudletScheduler();
							if(ncs.getCloudletExecList().size() == 0){
								targetVm = vm;
								nrcl.getCloudletState().restart();
								nrcl.setVm(targetVm);
								ncs.getCloudletExecList().add(nrcl);
								break;
							}
						}
						if(targetVm != null)
							break;
					}
				}
				
				if(targetVm == null){
					AggregateSwitch as = (AggregateSwitch)host.sw.uplinkswitches.get(0);
					RootSwitch rs = (RootSwitch)as.uplinkswitches.get(0);
					hosts = rs.getHostFromOtherPad(host);
					for (int j = 0; j < hosts.size(); j++) {
						targetHost = hosts.get(j);
						targetVm = null;
						if(targetHost.isFailed() || hasTaken.contains(new Integer(targetHost.getId())))
							continue;
						List<Vm> vmList = targetHost.getVmList();
						for(int k = 0 ; k < vmList.size(); k++){
							NetworkVm vm = (NetworkVm)vmList.get(k);
							NetworkCloudletSpaceSharedScheduler ncs = (NetworkCloudletSpaceSharedScheduler)vm.getCloudletScheduler();
							if(ncs.getCloudletExecList().size() == 0){
								targetVm = vm;
								nrcl.getCloudletState().restart();
								nrcl.setVm(targetVm);
								ncs.getCloudletExecList().add(nrcl);
								break;
							}
						}
						if(targetVm != null)
							break;
					}
				}	
				
				RecordToLogger.logger.debug(this.getName() + "|" +cl.getCloudletId()+" move to!"+ nrcl.getVm().getHost().getId());
				
				getDatacenter().getCheckpointimageindex().recoveryInvoke(nrcl, targetHost);
			}
			scheduler.getCloudletExecList().clear();
		}

		getDatacenter().getCheckpointimageindex().storageNodeReSearch(host);
	}

}
