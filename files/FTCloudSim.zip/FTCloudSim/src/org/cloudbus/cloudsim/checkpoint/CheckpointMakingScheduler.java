package org.cloudbus.cloudsim.checkpoint;

import java.util.ArrayList;
import java.util.List;

import org.cloudbus.cloudsim.CKP.datacenter.NetworkConstants;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkDatacenter;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkHost;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkResCloudlet;
import org.cloudbus.cloudsim.CKP.datacenter.service.NetworkCloudlet;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEntity;
import org.cloudbus.cloudsim.core.SimEvent;

public class CheckpointMakingScheduler extends SimEntity {
	
	private List<Integer> cloudIds;

	public CheckpointMakingScheduler(String name) {
		super(name);
		cloudIds = new ArrayList<Integer>();
	}

	@Override
	public void startEntity() {
		// TODO Auto-generated method stub

	}

	@Override
	public void processEvent(SimEvent ev) {
		switch (ev.getTag()) {
		// Resource characteristics request
			case CloudSimTags.INVOKE_CHECKPOINT:
				invokeCheckpoint(ev);
				break;
			// Resource characteristics answer
			case CloudSimTags.SCHEDULE_APP_CHECKPOINT:
				scheduleAPPCheckpoint(ev);
				break;
				
			case CloudSimTags.SCHEDULE_SYSTEM_CHECKPOINT:
				scheduleSystemCheckpoint(ev);
				break;
				
//			case CloudSimTags.SCHEDULE_DELTA_CHECKPOINT:
//				scheduleDeltaCheckpoint(ev);
//				break;

			// other unknown tags are processed by this method
			default:
				break;
		}

	}

	@Override
	public void shutdownEntity() {
		// TODO Auto-generated method stub

	}
	
	private void invokeCheckpoint(SimEvent ev){
		NetworkResCloudlet rescloudlet = (NetworkResCloudlet)ev.getData();
		
		if(cloudIds.contains(rescloudlet.getCloudlet().getCloudletId()))
			return;
		
//		NetworkDatacenter datacenter = (NetworkDatacenter)rescloudlet.getVm().getHost().getDatacenter();
//		datacenter.getCheckpointimageindex().storageNodeSearch(rescloudlet);
		
//		System.out.println(rescloudlet.getCloudlet().getCloudletId()+"*********");
		cloudIds.add(rescloudlet.getCloudlet().getCloudletId());
		NetworkCloudlet cloudlet = (NetworkCloudlet)rescloudlet.getCloudlet();
		if(cloudlet.startCkpTime > 0)
			schedule(getId(), CloudSim.clock()+cloudlet.startCkpTime, CloudSimTags.SCHEDULE_SYSTEM_CHECKPOINT,rescloudlet);
		else
			schedule(getId(), NetworkConstants.CHECKPOINT_INTERVAL, CloudSimTags.SCHEDULE_SYSTEM_CHECKPOINT,rescloudlet);
	}
	
	private void scheduleAPPCheckpoint(SimEvent ev){
		
	}
	
	private void scheduleSystemCheckpoint(SimEvent ev){
		NetworkResCloudlet rescloudlet = (NetworkResCloudlet)ev.getData();
		NetworkHost host =  (NetworkHost)rescloudlet.getVm().getHost();
		
		if(rescloudlet.getCloudlet().isFinished())
			return;
		
		if(host.isFailed() == false){
			sendNow(host.getId(), CloudSimTags.MAKE_CHECKPOINT, rescloudlet);
//			System.out.println(rescloudlet.getCloudlet().getCloudletId()+"system*********"+CloudSim.clock());
		}	
		
		schedule(getId(), NetworkConstants.CHECKPOINT_INTERVAL, CloudSimTags.SCHEDULE_SYSTEM_CHECKPOINT,rescloudlet);
		
//		if(Config.CheckpointStyle == 1)
//			schedule(getId(), NetworkConstants.CHECKPOINT_INTERVAL, CloudSimTags.SCHEDULE_SYSTEM_CHECKPOINT,rescloudlet);
//		else if(Config.CheckpointStyle == 2 || Config.CheckpointStyle == 3)
//			schedule(getId(), NetworkConstants.CHECKPOINT_INTERVAL, CloudSimTags.SCHEDULE_DELTA_CHECKPOINT,rescloudlet);
		
	}
	
//	private void scheduleDeltaCheckpoint(SimEvent ev){
//		NetworkResCloudlet rescloudlet = (NetworkResCloudlet)ev.getData();
//		NetworkHost host =  (NetworkHost)rescloudlet.getVm().getHost();
//		
//		if(rescloudlet.getCloudlet().isFinished())
//			return;
//		
//		if(host.isFailed() == false){
//			sendNow(host.getId(), CloudSimTags.MAKE_DELTA_CHECKPOINT, rescloudlet);
////			System.out.println(rescloudlet.getCloudlet().getCloudletId()+"delta*********"+CloudSim.clock());
//		}
//		
//		schedule(getId(), NetworkConstants.CHECKPOINT_INTERVAL, CloudSimTags.SCHEDULE_DELTA_CHECKPOINT,rescloudlet);
//		
//	}

}
