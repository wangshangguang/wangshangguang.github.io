package org.cloudbus.cloudsim.checkpoint;

import java.util.List;

import org.cloudbus.cloudsim.CKP.datacenter.NetworkDatacenter;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkHost;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkResCloudlet;
import org.cloudbus.cloudsim.CKP.datacenter.service.AppNetCloudlet;
import org.cloudbus.cloudsim.CKP.datacenter.service.NetworkCloudlet;
import org.cloudbus.cloudsim.core.SimEntity;
import org.cloudbus.cloudsim.core.SimEvent;

public abstract class CheckpointStorageIndex  extends SimEntity{
	protected NetworkDatacenter datacenter;

	public abstract List<Integer> getCloudletCheckpointImageStorageNode(int cloudletId);
	
	public abstract List<Integer> getAPPCheckpointImageStorageNode(int appId);
	
	public abstract void storageNodeSearch(NetworkResCloudlet rcl);
	
	public abstract void storageNodeSearch(AppNetCloudlet rcl);
	
	public abstract void storageNodeReSearch( NetworkHost host);
	
	public abstract void recoveryInvoke(NetworkResCloudlet nrcl, NetworkHost targetHost);
	
	public CheckpointStorageIndex(String name){
		super(name);
	}
	
	public NetworkDatacenter getDatacenter() {
		return datacenter;
	}

	public void setDatacenter(NetworkDatacenter datacenter) {
		this.datacenter = datacenter;
	}
	
	@Override
	public void startEntity() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void processEvent(SimEvent ev) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void shutdownEntity() {
		// TODO Auto-generated method stub
		
	}

}
