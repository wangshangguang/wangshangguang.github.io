package org.cloudbus.cloudsim.checkpoint;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.CKP.datacenter.AggregateSwitch;
import org.cloudbus.cloudsim.CKP.datacenter.Config;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkConstants;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkDatacenterCharacteristics;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkHost;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkResCloudlet;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkStorageHost;
import org.cloudbus.cloudsim.CKP.datacenter.service.AppNetCloudlet;
import org.cloudbus.cloudsim.CKP.datacenter.service.NetworkCloudlet;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;

public class RandomDistriCheckpointStorageIndex extends
		CheckpointStorageIndex {
	private Map<Integer, List<Integer>> cloudletCheckpointStorageNode;
	
	private Map<Integer, List<Integer>> appCheckpointStorageNode;

	public RandomDistriCheckpointStorageIndex(String name) {
		super(name);
		cloudletCheckpointStorageNode = new HashMap<Integer, List<Integer>> ();
		appCheckpointStorageNode = new HashMap<Integer, List<Integer>> ();
	}

	@Override
	public List<Integer> getCloudletCheckpointImageStorageNode(int cloudletId) {
		return cloudletCheckpointStorageNode.get(cloudletId);
	}

	@Override
	public List<Integer> getAPPCheckpointImageStorageNode(int appId) {
		return appCheckpointStorageNode.get(appId);
	}

	@Override
	public void storageNodeSearch(NetworkResCloudlet rcl) {
		NetworkCloudlet ncl = (NetworkCloudlet)rcl.getCloudlet();
		
		List<Integer> hasTaken = new ArrayList<Integer> ();
		
		List<Integer> appStorageNodes = datacenter.getCheckpointimageindex().getAPPCheckpointImageStorageNode(ncl.belongToApp.appId);
		if(appStorageNodes != null)
			hasTaken.addAll(appStorageNodes);
		
		List<NetworkCloudlet> cls = ncl.belongToApp.getCloudletList();
		for(int i = 0; i < cls.size(); i++){
			NetworkCloudlet cl = cls.get(i);
			NetworkDatacenterCharacteristics chara = (NetworkDatacenterCharacteristics)datacenter.getCharacteristics();
			
			hasTaken.add(chara.VmtoHostlist.get(cl.getVmId()));
			List<Integer> storageNodes = datacenter.getCheckpointimageindex().getCloudletCheckpointImageStorageNode(cl.getCloudletId());
			if(storageNodes != null)
				hasTaken.addAll(storageNodes);
		}

		
		List<Host> hosts = RandomSort.getRandomList(datacenter.getHostList());
		for(int i = 0; i < hosts.size(); i++){
			NetworkHost host = (NetworkHost)hosts.get(i);
			
			if(host.isFailed() || hasTaken.contains(host.getId()))
				continue;
			
			List<Integer> storageHosts = new ArrayList<Integer>();
			storageHosts.add(host.getId());
			cloudletCheckpointStorageNode.put(rcl.getCloudletId(), storageHosts);
			host.allocatedCKPStorage = host.allocatedCKPStorage +  143*(Math.log(NetworkConstants.CHECKPOINT_INTERVAL)/Math.log(10))-254;
			break;
		}
	}

	@Override
	public void storageNodeSearch(AppNetCloudlet acl) {
		List<NetworkCloudlet> cloudlets = acl.getCloudletList();
		List<Integer> exehosts = new ArrayList<Integer>();
		for(int i = 0; i < cloudlets.size(); i++){
			NetworkDatacenterCharacteristics chara = (NetworkDatacenterCharacteristics)datacenter.getCharacteristics();
			exehosts.add(chara.VmtoHostlist.get(cloudlets.get(i).getVmId()));
			List<Integer> storageNodes = datacenter.getCheckpointimageindex().getCloudletCheckpointImageStorageNode(cloudlets.get(i).getCloudletId());
			if(storageNodes != null)
				exehosts.addAll(storageNodes);
			
		}
		
		List<Integer> storageHosts = new ArrayList<Integer>();
		List<Integer> belongToPads = new ArrayList<Integer>();
		for(int i = 0; i < cloudlets.size(); i++){
			NetworkDatacenterCharacteristics chara = (NetworkDatacenterCharacteristics)datacenter.getCharacteristics();
			NetworkHost host = (NetworkHost)CloudSim.getEntity(chara.VmtoHostlist.get(cloudlets.get(i).getVmId())) ;
			
			if( belongToPads.contains(host.belongToPad))
				continue;
			
			NetworkHost targetHost = null;
			AggregateSwitch sw =(AggregateSwitch) host.sw.uplinkswitches.get(0);
			List<Host> hosts = RandomSort.getRandomList( sw.getHostFromOtherSubnet(host));
			for(int j = 0; j < hosts.size(); j++){
				NetworkHost nh = (NetworkHost)hosts.get(j);				
				if(nh.getStorage() - nh.allocatedCKPStorage < 2048)
					continue;				
				if(nh.isFailed() || exehosts.contains(nh.getId()))
					continue;				
				targetHost = nh;
				break;
				
			}			
			storageHosts.add(targetHost.getId());			
			belongToPads.add(targetHost.belongToPad);			
			targetHost.allocatedCKPStorage = targetHost.allocatedCKPStorage + acl.baseSystemSize;			
		}
		appCheckpointStorageNode.put(acl.appId, storageHosts);
	}

	@Override
	public void storageNodeReSearch(NetworkHost host) {
		
		Map<AppNetCloudlet, AppCheckpoint> appcenter = host.getAppCheckpointCenter();
		Iterator iter = appcenter.entrySet().iterator();
		while (iter.hasNext()) {
			Map.Entry entry = (Map.Entry) iter.next();
			AppNetCloudlet key = (AppNetCloudlet)entry.getKey();
			AppCheckpoint val = (AppCheckpoint)entry.getValue();
			
			
			List<Integer> hasTaken = new ArrayList<Integer> ();
			
			if(Config.CheckpointStyle == 3)
				hasTaken.addAll(datacenter.getCheckpointimageindex().getAPPCheckpointImageStorageNode(key.appId));
			
			List<NetworkCloudlet> cls = key.getCloudletList();
			for(int j = 0; j < cls.size(); j++){
				NetworkCloudlet ncl = cls.get(j);
				NetworkDatacenterCharacteristics chara = (NetworkDatacenterCharacteristics)datacenter.getCharacteristics();
				
				hasTaken.add(chara.VmtoHostlist.get(ncl.getVmId()));
				List<Integer> storageNodes = datacenter.getCheckpointimageindex().getCloudletCheckpointImageStorageNode(ncl.getCloudletId());
				if(storageNodes != null)
					hasTaken.addAll(storageNodes);
			}
			
			List<Host> hosts = RandomSort.getRandomList(datacenter.getHostList());
			NetworkHost destHost = null;
			for(int i = 0; i < hosts.size(); i++){
				destHost = (NetworkHost)hosts.get(i);
				if(hasTaken.contains(destHost.getId()))
					continue;
				if(!destHost.isFailed())
					break;				
			}
			
			List<Integer> nodes = this.getAPPCheckpointImageStorageNode(key.appId);
			for(int i = 0; i < nodes.size(); i++){
				Integer integer = nodes.get(i);
				if(integer.intValue() == host.getId()){
					nodes.remove(integer);
					break;
				}
			}
			
			nodes.add(destHost.getId());
			
			if(nodes.size() > 0){
				NetworkHost fetchSrc = null;
				for(int i = 0; i < nodes.size(); i++){
					NetworkHost src = (NetworkHost)CloudSim.getEntity(nodes.get(i));
					if(src.appCheckpointCenter.containsKey(key)){
						fetchSrc = src;
						break;
					}
				}
				if(fetchSrc != null){
					CloudSim.send(destHost.getId(), fetchSrc.getId(), 0, CloudSimTags.FETCH_APP_CHECKPOINT, key);
				}
				else{

					NetworkDatacenterCharacteristics chara = (NetworkDatacenterCharacteristics)datacenter.getCharacteristics();
					NetworkStorageHost storageCenter = chara.getDatacenternetwork().getStorageCenter();
					
					CloudSim.send(destHost.getId(),storageCenter.getId(), 0, CloudSimTags.FETCH_APP_CHECKPOINT, key);
				}
				
			}
			else{
				NetworkDatacenterCharacteristics chara = (NetworkDatacenterCharacteristics)datacenter.getCharacteristics();
				NetworkStorageHost storageCenter = chara.getDatacenternetwork().getStorageCenter();
				CloudSim.send(destHost.getId(),storageCenter.getId(), 0, CloudSimTags.FETCH_APP_CHECKPOINT, key);
			}
			
		}
		
		 Map<NetworkResCloudlet, CloudletCheckpoint> cloudletcenter = host.getCloudletCheckpointCenter();
		 iter = cloudletcenter.entrySet().iterator();
		while (iter.hasNext()) {
			Map.Entry entry = (Map.Entry) iter.next();
			NetworkResCloudlet key = (NetworkResCloudlet)entry.getKey();
			CloudletCheckpoint val = (CloudletCheckpoint)entry.getValue();
			
			NetworkCloudlet cl = (NetworkCloudlet)key.getCloudlet();
			
			List<Integer> hasTaken = new ArrayList<Integer> ();
			
			if(Config.CheckpointStyle == 3)
				hasTaken.addAll(datacenter.getCheckpointimageindex().getAPPCheckpointImageStorageNode(cl.belongToApp.appId));
			
			List<NetworkCloudlet> cls = cl.belongToApp.getCloudletList();
			for(int j = 0; j < cls.size(); j++){
				NetworkCloudlet ncl = cls.get(j);
				NetworkDatacenterCharacteristics chara = (NetworkDatacenterCharacteristics)datacenter.getCharacteristics();
				
				hasTaken.add(chara.VmtoHostlist.get(ncl.getVmId()));
				List<Integer> storageNodes = datacenter.getCheckpointimageindex().getCloudletCheckpointImageStorageNode(ncl.getCloudletId());
				if(storageNodes != null)
					hasTaken.addAll(storageNodes);
			}
			
			List<Host> hosts = RandomSort.getRandomList(datacenter.getHostList());
			NetworkHost destHost = null;
			for(int i = 0; i < hosts.size(); i++){
				destHost = (NetworkHost)hosts.get(i);	
				if(hasTaken.contains(destHost.getId()))
					continue;
				if(!destHost.isFailed())
					break;				
			}
			
			List<Integer> nodes = this.getCloudletCheckpointImageStorageNode(key.getCloudletId());
			for(int i = 0; i < nodes.size(); i++){
				Integer integer = nodes.get(i);
				if(integer.intValue() == host.getId()){
					nodes.remove(integer);
					break;
				}
			}
			nodes.add(destHost.getId());
			if(nodes.size() > 0){
				NetworkHost fetchSrc = null;
				for(int i = 0; i < nodes.size(); i++){
					NetworkHost src = (NetworkHost)CloudSim.getEntity(nodes.get(i));
					if(src.cloudletCheckpointCenter.containsKey(key)){
						fetchSrc = src;
						break;
					}
				}
				if(fetchSrc != null){
					CloudSim.send(destHost.getId(), fetchSrc.getId(), 0, CloudSimTags.FETCH_CLOUDLET_CHECKPOINT, key);
				}
				else{
					NetworkCloudlet cloudlet = (NetworkCloudlet)key.getCloudlet();
					cloudlet.lastFinishedSoFar = 0;
					cloudlet.hasCloudletSystemImage = false;
				}
				
			}
			
		}		
		appcenter.clear();
		cloudletcenter.clear();
	}

	@Override
	public void recoveryInvoke(NetworkResCloudlet nrcl, NetworkHost targetHost) {
		NetworkCloudlet cloudlet = (NetworkCloudlet)nrcl.getCloudlet();
		List<Integer> appnodes = this.getAPPCheckpointImageStorageNode(cloudlet.belongToApp.appId);
		List<Integer> cloudletnodes = this.getCloudletCheckpointImageStorageNode(nrcl.getCloudletId());
		
		NetworkHost appsrchost = null;
		NetworkHost cloudletsrchost = null;
		
		if(Config.CheckpointStyle == 3){
			for(int i = 0; i < appnodes.size(); i++){
				NetworkHost host = (NetworkHost)CloudSim.getEntity(appnodes.get(i));				
				if(host.isFailed())
					continue;
				if(host.belongToPad == nrcl.getVm().getHost().belongToPad && host.appCheckpointCenter.containsKey(cloudlet.belongToApp)){
					appsrchost = host;
					break;
				}
			}
		}
		
		for(int i = 0; i < cloudletnodes.size(); i++){
			NetworkHost host  = (NetworkHost)CloudSim.getEntity(cloudletnodes.get(i));				
			if(host.isFailed())
				continue;
			if(host.cloudletCheckpointCenter.containsKey(nrcl)){
				cloudletsrchost = host;
				break;
			}
		}
		
		NetworkDatacenterCharacteristics chara = (NetworkDatacenterCharacteristics)datacenter.getCharacteristics();
		NetworkStorageHost storageCenter = chara.getDatacenternetwork().getStorageCenter();
		
		if(Config.CheckpointStyle == 0){
			cloudlet.hasCloudletSystemImage = false;
			cloudlet.lastFinishedSoFar = 0;
			nrcl.setCloudletFinishedSoFar(0);
			send(storageCenter.getId(), 0, CloudSimTags.RESTART_CLOULET, nrcl);	
		}
		else if(Config.CheckpointStyle == 1 || Config.CheckpointStyle == 2){
			if(cloudletsrchost != null){
				nrcl.setCloudletFinishedSoFar(cloudletsrchost.cloudletCheckpointCenter.get(nrcl).getFinishedSoFar());
				send(cloudletsrchost.getId(), 0, CloudSimTags.RECOVERY_CLOUDLET_POINT_SEDN, nrcl);	
			}
			else{
				cloudlet.hasCloudletSystemImage = false;
				cloudlet.lastFinishedSoFar = 0;
				nrcl.setCloudletFinishedSoFar(0);
				send(storageCenter.getId(), 0, CloudSimTags.RESTART_CLOULET, nrcl);	
			}
		}
		else if(Config.CheckpointStyle == 3){
			if(appsrchost != null){
				if(cloudletsrchost != null){
					nrcl.setCloudletFinishedSoFar(cloudletsrchost.cloudletCheckpointCenter.get(nrcl).getFinishedSoFar());
					send(cloudletsrchost.getId(), 0, CloudSimTags.RECOVERY_CLOUDLET_POINT_SEDN, nrcl);	
					send(appsrchost.getId(), 0.9, CloudSimTags.RECOVERY_APP_POINT_SEDN, nrcl);	
				}
				else{
					cloudlet.hasCloudletSystemImage = false;
					cloudlet.lastFinishedSoFar = 0;
					nrcl.setCloudletFinishedSoFar(0);
					send(appsrchost.getId(), 0, CloudSimTags.RECOVERY_APP_POINT_SEDN, nrcl);	
				}
				
			}
			else{
				cloudlet.hasCloudletSystemImage = false;
				cloudlet.lastFinishedSoFar = 0;
				nrcl.setCloudletFinishedSoFar(0);
				send(storageCenter.getId(), 0, CloudSimTags.RESTART_CLOULET, nrcl);
			}
		}
		
	}

}
