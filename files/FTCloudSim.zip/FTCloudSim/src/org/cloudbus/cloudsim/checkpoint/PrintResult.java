package org.cloudbus.cloudsim.checkpoint;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.List;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CKP.datacenter.NetDatacenterBroker;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkConstants;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkDatacenter;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkDatacenterCharacteristics;

public class PrintResult {
	/**
	 * Prints the Cloudlet objects.
	 * 
	 * @param list
	 *            list of Cloudlets
	 * @throws IOException
	 */
	public static void printCloudletList(List<Cloudlet> list) throws IOException {
		int size = list.size();
		Cloudlet cloudlet;
		String indent = "    ";
//		indent = ",";
		RecordToLogger.logger.info("");
		RecordToLogger.logger.info("========== OUTPUT ==========");
		RecordToLogger.logger.info("Cloudlet ID" + indent + "STATUS" + indent + "Data center ID" + indent + "VM ID"
				+ indent + "Time" + indent + "Start Time" + indent + "Finish Time");

		DecimalFormat dft = new DecimalFormat("###.##");
		double totalExeTime = 0;
		
		for (int i = 0; i < size; i++) {
			String s = "";
			cloudlet = list.get(i);
			s = s + indent + cloudlet.getCloudletId() + indent + indent;

			if (cloudlet.getCloudletStatus() == Cloudlet.SUCCESS) {
				s = s + "SUCCESS";
				RecordToLogger.logger.info(s + indent + indent + cloudlet.getResourceId() + indent + indent + indent
						+ cloudlet.getVmId() + indent + indent + dft.format(cloudlet.getActualCPUTime())
						+ indent + indent + dft.format(cloudlet.getExecStartTime()) + indent + indent
						+ dft.format(cloudlet.getFinishTime()));
				totalExeTime = totalExeTime + cloudlet.getFinishTime()-cloudlet.getExecStartTime();
			}
		}
		
	
		
		RecordToLogger.logger.info("Total execution time: " + totalExeTime);
	}
	
	public static void printResult(NetworkDatacenter datacenter, NetDatacenterBroker broker) throws IOException {
		List<Cloudlet> newList = broker.getCloudletReceivedList();
		printCloudletList(newList);
		int size=newList.size();
		double totalcloudletlength=0;
		double totalExeTime = 0;
		for(int i=0;i<size;i++){
			
			Cloudlet cloudlet=newList.get(i);
			double tmplength=cloudlet.getCloudletLength();
			totalcloudletlength+=tmplength;
			if (cloudlet.getCloudletStatus() == Cloudlet.SUCCESS) {
				totalExeTime = totalExeTime + cloudlet.getFinishTime()-cloudlet.getExecStartTime();
			}
			
		}
		
		
		
		
		RecordToLogger.logger.info("numberofcloudlet " + newList.size() + " Cached "
				+ NetDatacenterBroker.cachedcloudlet + " Data transfered "
				+ NetworkConstants.totaldatatransfer);
		// Print the debt of each user to each datacenter
		datacenter.printDebts();
		
		NetworkDatacenterCharacteristics characteristics = (NetworkDatacenterCharacteristics)datacenter.getCharacteristics();
		characteristics.getDatacenternetwork().printResult(size,totalcloudletlength,totalExeTime);
	}

}
