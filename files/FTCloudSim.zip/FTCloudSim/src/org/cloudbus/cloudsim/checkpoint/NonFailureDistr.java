package org.cloudbus.cloudsim.checkpoint;

public class NonFailureDistr implements FailureDistr{

	@Override
	public double reliabilityCalculation(double lastFailureTime, double currentTime) {
		return 1;
	}

}
