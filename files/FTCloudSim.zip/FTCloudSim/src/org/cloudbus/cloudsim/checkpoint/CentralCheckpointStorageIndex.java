package org.cloudbus.cloudsim.checkpoint;

import java.util.ArrayList;
import java.util.List;

import org.cloudbus.cloudsim.CKP.datacenter.Config;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkDatacenterCharacteristics;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkHost;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkResCloudlet;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkStorageHost;
import org.cloudbus.cloudsim.CKP.datacenter.service.AppNetCloudlet;
import org.cloudbus.cloudsim.CKP.datacenter.service.NetworkCloudlet;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;

public class CentralCheckpointStorageIndex extends CheckpointStorageIndex {
	
	public CentralCheckpointStorageIndex(String name){
		super(name);
	}

	@Override
	public List<Integer> getCloudletCheckpointImageStorageNode(int cloudletId) {
		List<Integer> storageNodes = new ArrayList<Integer>();
		int storageCenter = datacenter.getCharacteristics().getDatacenternetwork().getStorageCenter().getId();
		storageNodes.add(storageCenter);
		return storageNodes;
	}

	@Override
	public List<Integer> getAPPCheckpointImageStorageNode(int appId) {
		List<Integer> storageNodes = new ArrayList<Integer>();
		int storageCenter = datacenter.getCharacteristics().getDatacenternetwork().getStorageCenter().getId();
		storageNodes.add(storageCenter);
		return storageNodes;
	}

	@Override
	public void storageNodeSearch(NetworkResCloudlet rcl) {
		
	}

	@Override
	public void storageNodeSearch(AppNetCloudlet acl) {
		List<NetworkCloudlet> cloudlets = acl.getCloudletList();
		
		if(cloudlets.size() > 0){
			List<Integer> storageNodes = getAPPCheckpointImageStorageNode(acl.appId);
			NetworkStorageHost storageCenter = (NetworkStorageHost) CloudSim.getEntity(storageNodes.get(0));
			
			NetworkDatacenterCharacteristics chara = (NetworkDatacenterCharacteristics)datacenter.getCharacteristics();
			NetworkHost host = (NetworkHost)CloudSim.getEntity(chara.VmtoHostlist.get(cloudlets.get(0).getVmId())) ;
			
			CloudSim.send(storageCenter.getId(), host.getId(), 0, CloudSimTags.MAKE_APP_CHECKPOINT, cloudlets.get(0));
		}
		
	}

	@Override
	public void storageNodeReSearch(NetworkHost host) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void recoveryInvoke(NetworkResCloudlet nrcl, NetworkHost targetHost) {
		List<Integer> storageNodes = getCloudletCheckpointImageStorageNode(nrcl.getCloudletId());
		NetworkStorageHost storageCenter = (NetworkStorageHost) CloudSim.getEntity(storageNodes.get(0));
		NetworkCloudlet cloudlet  = (NetworkCloudlet)nrcl.getCloudlet();
		
		if(Config.CheckpointStyle == 0){
			cloudlet.hasCloudletSystemImage = false;
			cloudlet.lastFinishedSoFar = 0;
			nrcl.setCloudletFinishedSoFar(0);
			send(storageNodes.get(0), 0, CloudSimTags.RESTART_CLOULET, nrcl);	
		}
		else if(Config.CheckpointStyle == 1 || Config.CheckpointStyle == 2){
			storageNodes = getAPPCheckpointImageStorageNode(nrcl.getCloudletId());
			
			if(storageCenter.cloudletCheckpointCenter.containsKey(nrcl)){
				nrcl.setCloudletFinishedSoFar(storageCenter.cloudletCheckpointCenter.get(nrcl).getFinishedSoFar());
				send(storageNodes.get(0), 0, CloudSimTags.RECOVERY_CLOUDLET_POINT_SEDN, nrcl);	
			}
			else{
				cloudlet.hasCloudletSystemImage = false;
				cloudlet.lastFinishedSoFar = 0;
				nrcl.setCloudletFinishedSoFar(0);
				send(storageNodes.get(0), 0, CloudSimTags.RESTART_CLOULET, nrcl);	
			}
		}
		else if(Config.CheckpointStyle == 3){
			storageNodes = getAPPCheckpointImageStorageNode(nrcl.getCloudletId());
			if(storageCenter.appCheckpointCenter.containsKey(cloudlet.belongToApp)){
				if(storageCenter.cloudletCheckpointCenter.containsKey(nrcl)){
					nrcl.setCloudletFinishedSoFar(storageCenter.cloudletCheckpointCenter.get(nrcl).getFinishedSoFar());
					send(storageNodes.get(0), 0, CloudSimTags.RECOVERY_CLOUDLET_POINT_SEDN, nrcl);	
					send(storageNodes.get(0), 0.9, CloudSimTags.RECOVERY_APP_POINT_SEDN, nrcl);	
				}
				else{
					cloudlet.hasCloudletSystemImage = false;
					cloudlet.lastFinishedSoFar = 0;
					nrcl.setCloudletFinishedSoFar(0);
					send(storageNodes.get(0), 0, CloudSimTags.RECOVERY_APP_POINT_SEDN, nrcl);	
				}
				
			}
			else{
				cloudlet.hasCloudletSystemImage = false;
				cloudlet.lastFinishedSoFar = 0;
				nrcl.setCloudletFinishedSoFar(0);
				send(storageNodes.get(0), 0, CloudSimTags.RESTART_CLOULET, nrcl);
			}
		}
	}

}
