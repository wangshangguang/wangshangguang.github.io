package org.cloudbus.cloudsim.checkpoint;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.cloudbus.cloudsim.CKP.datacenter.NetworkConstants;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkDatacenter;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkDatacenterCharacteristics;
import org.cloudbus.cloudsim.CKP.datacenter.NetworkHost;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEntity;
import org.cloudbus.cloudsim.core.SimEvent;

public class DatacenterDestroyer extends SimEntity {
	private NetworkDatacenter datacenter;
	
	private List<NetworkHost> weakHost = new ArrayList<NetworkHost>();
	
	private List<NetworkHost> strongHost = new ArrayList<NetworkHost>();
	
	private List<NetworkHost> failedHost = new ArrayList<NetworkHost>();
	
	private List<NetworkHost> runningHost = new ArrayList<NetworkHost>();
	
	private Map<Integer, Double> hostDownEvents = new  HashMap<Integer, Double>();
	
	private Map<Integer, Double> hostUpEvents = new  HashMap<Integer, Double>();

	public DatacenterDestroyer(String name) {
		super(name);
		
	}
	
	public void init(){
		NetworkDatacenterCharacteristics characteristics = (NetworkDatacenterCharacteristics)datacenter.getCharacteristics();
		List<NetworkHost> hosts = characteristics.getHostList();
		Random rd = new Random(System.currentTimeMillis());
		
		for(int i = 0; i < hosts.size(); i++){
			if(rd.nextInt(100) < NetworkConstants.WEAK_HOST_RATIO){
				weakHost.add(hosts.get(i));
			}
			else {
				strongHost.add(hosts.get(i));
			}
		}
		
		runningHost.addAll(hosts);
	}

	@Override
	public void startEntity() {
		Iterator iter = hostDownEvents.entrySet().iterator();
		while (iter.hasNext()){
			Map.Entry entry = (Map.Entry) iter.next();
			int hostid = (Integer)entry.getKey();
			double time = (Double)entry.getValue();
			send(getId(), time, CloudSimTags.HOST_DOWN, hostid);
//			System.out.println(hostid +"////"+time);
		}
		iter = hostUpEvents.entrySet().iterator();
		while (iter.hasNext()){
			Map.Entry entry = (Map.Entry) iter.next();
			int hostid = (Integer)entry.getKey();
			double time = (Double)entry.getValue();
			send(getId(), time, CloudSimTags.HOST_REAPIR, hostid);
		}

	}

	@Override
	public void processEvent(SimEvent ev) {
		switch (ev.getTag()) {
		// Resource characteristics request
			case CloudSimTags.HOST_DOWN:
				hostDown(ev);
				break;
			// Resource characteristics answer
			case CloudSimTags.HOST_REAPIR:
				hostRepair(ev);
				break;

			// other unknown tags are processed by this method
			default:
				break;
		}

	}
	
	public void hostRepair(SimEvent ev){
		int hostid = (Integer)ev.getData();
		NetworkHost host = (NetworkHost)CloudSim.getEntity(hostid);
		failedHost.remove(host);
		runningHost.add(host);
		host.setFailed(false);
//		datacenter.getRecoveryScheduler().recovery(host);
	}
	
	public void hostDown(SimEvent ev){
		int hostid = (Integer)ev.getData();
		NetworkHost host = (NetworkHost)CloudSim.getEntity(hostid);
		runningHost.remove(host);
		failedHost.add(host);
		host.clear();
		host.setFailed(true);
		
		datacenter.getRecoveryScheduler().recovery(host);
	}
	
	public void addRepairEvent(int hostid, double time){
		this.hostUpEvents.put(hostid, time);
	}
	
	public void addFailureEvent(int hostid, double time){
		this.hostDownEvents.put(hostid, time);
	}

	@Override
	public void shutdownEntity() {
		// TODO Auto-generated method stub

	}
	
	public NetworkDatacenter getDatacenter() {
		return datacenter;
	}

	public void setDatacenter(NetworkDatacenter datacenter) {
		this.datacenter = datacenter;
	}

}
