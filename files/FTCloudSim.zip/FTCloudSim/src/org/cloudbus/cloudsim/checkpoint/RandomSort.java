package org.cloudbus.cloudsim.checkpoint;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.cloudbus.cloudsim.Host;

public class RandomSort {
	
	public static Random rand = new Random(System.currentTimeMillis());  
	
	public static List<Host> getRandomList(List<? extends Host> hosts){  
        int count = hosts.size();  
        List<Host> resultList = new ArrayList<Host>();   
        List<Host> temp = new ArrayList<Host>(); 
        temp.addAll(hosts);
        
        for(int i = 0; i< count; i++){  
            int num = rand.nextInt(count - i); 
            resultList.add(temp.get(num));
//            System.out.print(temp.get(num).getId()+",");
            temp.remove(num);  
        }  
        
//        System.out.println();
        return resultList;  
    }
	
	public static void main(String[] args) {
		List<Integer> ins = new ArrayList<Integer>();
		for(int i = 0; i < 10; i++){
			ins.add(i);
		}
		if(ins.contains(5))
			System.out.println("fjaie");
	}

}
