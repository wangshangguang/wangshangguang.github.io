package org.cloudbus.cloudsim.checkpoint;

import java.util.Random;


public class WeibullFailureDistr implements FailureDistr {
	/** The alpha. */
	private final double alpha;

	/** The beta. */
	private final double beta;
	
	private final Random numGen;

	public WeibullFailureDistr(double alpha, double beta) {
		this.alpha = alpha;
		this.beta = beta;
		numGen = new Random(System.currentTimeMillis());
	}

	@Override
	public double reliabilityCalculation(double lastFailureTime, double currentTime) {
		return Math.pow(Math.E, -Math.pow((currentTime - lastFailureTime)/beta, alpha));
	}
	
	public double sample() {
		return beta * Math.pow(-Math.log(numGen.nextDouble()), 1 / alpha);
	}

}
