/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package org.cloudbus.cloudsim.CKP.datacenter;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedMap;
import java.util.TreeMap;

import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.checkpoint.DCNetworkVisitor;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEntity;
import org.cloudbus.cloudsim.core.SimEvent;
import org.cloudbus.cloudsim.core.predicates.PredicateType;
import org.cloudbus.cloudsim.lists.VmList;


public class Switch extends DataCenterNode{	
	public Map<VMLink,DataCenterLink> RountingTable = new Hashtable<VMLink,DataCenterLink>();
		
	public List<DataCenterLink> uplinks = new ArrayList<DataCenterLink> ();
	
	public List<DataCenterLink> downlinks = new ArrayList<DataCenterLink> ();

	public int level;// three levels

//	public int datacenterid;

	public Map<Integer, List<NetworkPacket>> uplinkswitchpktlist;

	public Map<Integer, List<NetworkPacket>> downlinkswitchpktlist;

	public List<Switch> uplinkswitches;

	public List<Switch> downlinkswitches;

	int type;// edge switch or aggregation switch

	public double uplinkbandwidth;

	public double downlinkbandwidth;

	public double latency;

	public double numport;

	public NetworkDatacenter dc;
	
	public double hasReceviedCKPPacketSize = 0;
	
	public double hasReceviedServiceDataPacketSize = 0;

//	// something is running on these hosts
//	public SortedMap<Double, List<NetworkHost>> fintimelistHost = new TreeMap<Double, List<NetworkHost>>();
//
//	// something is running on these hosts
//	public SortedMap<Double, List<NetworkVm>> fintimelistVM = new TreeMap<Double, List<NetworkVm>>();

	public ArrayList<NetworkPacket> pktlist;

//	public List<Vm> BagofTaskVm = new ArrayList<Vm>();

//	public double switching_delay;

	public Map<Integer, NetworkVm> Vmlist;

	public Switch(String name, int level, NetworkDatacenter dc, int worldX, int worldY) {
		super(name, worldX, worldY);
		this.level = level;
		this.dc = dc;
	}

	@Override
	public void startEntity() {
//		RecordToLogger.logger.info(getName() + " is starting...");
		schedule(getId(), 0, CloudSimTags.RESOURCE_CHARACTERISTICS_REQUEST);
	}

	@Override
	public void processEvent(SimEvent ev) {
		// RecordToLogger.logger.info(CloudSim.clock()+"[Broker]: event received:"+ev.getTag());
		switch (ev.getTag()) {
		// Resource characteristics request
			case CloudSimTags.Network_Event_UP:
				// process the packet from down switch or host
				processpacket_up(ev);
				break;
			case CloudSimTags.Network_Event_DOWN:
				// process the packet from uplink
				processpacket_down(ev);
				break;
			case CloudSimTags.Network_Event_send:
				processpacketforward(ev);
				break;			
			// other unknown tags are processed by this method
			default:
				processOtherEvent(ev);
				break;
		}
	}

	protected void processhostpacket(SimEvent ev) {
	}

	protected void processpacket_down(SimEvent ev) {
	}

	protected void processpacket_up(SimEvent ev) {
	}


	protected void processpacket(SimEvent ev) {
		// send packet to itself with switching delay (discarding other)
		CloudSim.cancelAll(getId(), new PredicateType(CloudSimTags.Network_Event_UP));
		schedule(getId(), latency, CloudSimTags.Network_Event_UP);
		pktlist.add((NetworkPacket) ev.getData());


	}

	private void processOtherEvent(SimEvent ev) {

	}

	protected void processpacketforward(SimEvent ev) {
	}

	@Override
	public void shutdownEntity() {
//		RecordToLogger.logger.info(getName() + " is shutting down...");
	}
	
	public List<DataCenterLink> getUplinks() {
		return uplinks;
	}


	public void setUplinks(List<DataCenterLink> uplinks) {
		this.uplinks = uplinks;
	}


	public List<DataCenterLink> getDownlinks() {
		return downlinks;
	}


	public void setOutlinks(List<DataCenterLink> downlinks) {
		this.downlinks = downlinks;
	}

	public void addUplinks(DataCenterLink uplink) {
		this.uplinks.add(uplink);
	}

	public void addDownlinks(DataCenterLink downlink) {
		this.downlinks.add(downlink);
	}

	@Override
	public void accept(DCNetworkVisitor visitor, Object data) {
		visitor.visit(this, data);
		
	}


}
