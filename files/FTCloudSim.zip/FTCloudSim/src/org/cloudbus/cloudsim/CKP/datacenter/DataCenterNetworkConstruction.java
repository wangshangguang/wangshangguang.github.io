package org.cloudbus.cloudsim.CKP.datacenter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.VmSchedulerTimeShared;
import org.cloudbus.cloudsim.checkpoint.CentralCheckpointStorageIndex;
import org.cloudbus.cloudsim.checkpoint.CheckpointStorageIndex;
import org.cloudbus.cloudsim.checkpoint.CloudletRecoveryScheduler;
import org.cloudbus.cloudsim.checkpoint.DatacenterDestroyer;
import org.cloudbus.cloudsim.checkpoint.FailureEventReader;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;

public class DataCenterNetworkConstruction {
/*	
	private static DCNetwork createDatacenter(String name, int portNum, NetworkDatacenter datacenter,CloudletRecoveryScheduler recoveryScheduler,
			CheckpointStorageIndex checkpointimageindex,
			DatacenterDestroyer datacenterDestroyer ) throws IOException {
		DCNetwork dcn = new DCNetwork();	
		
		int rootSwitchNum = (portNum/2)*(portNum/2);
		
		int aggregateSwitchNum = portNum*(portNum/2);
		
		int edgeSwitchNum = portNum*(portNum/2);
		
		int hostNum = (portNum*portNum*portNum)/4;
		
		List<NetworkHost> hostList = new ArrayList<NetworkHost>();
		int mips = 1000;
		int ram = 4096; // host memory (MB)
		long storage = 1000000; // host storage
		int bw = 10000;
		int x = 3;
		int hostNumPerPad = (portNum*portNum)/4;
		for (int y = 0; y < hostNum; y++) {
			List<Pe> peList = new ArrayList<Pe>();
			peList.add(new Pe(0, new PeProvisionerSimple(mips))); // need to
			NetworkHost host = new NetworkHost(
					"host_"+x+"_"+y,
					new RamProvisionerSimple(ram),
					new BwProvisionerSimple(bw),
					storage,
					peList,
					new VmSchedulerTimeShared(peList),
					x,y,
					y/hostNumPerPad);
			hostList.add(host); // This is our machine
			dcn.getHostList().add(host);
			dcn.getNodeList().add(host);
		}

		
		String arch = "x86"; // system architecture
		String os = "Linux"; // operating system
		String vmm = "Xen";
		double time_zone = 10.0; // time zone this resource located
		double cost = 3.0; // the cost of using processing in this resource
		double costPerMem = 0.05; // the cost of using memory in this resource
		double costPerStorage = 0.001; // the cost of using storage in this resource
		double costPerBw = 0.0; // the cost of using bw in this resource
		LinkedList<Storage> storageList = new LinkedList<Storage>(); // we are

		NetworkDatacenterCharacteristics characteristics = new NetworkDatacenterCharacteristics(
				arch,
				os,
				vmm,
				hostList,
				time_zone,
				cost,
				costPerMem,
				costPerStorage,
				costPerBw);

		datacenter = null;
		try {
			datacenter = new NetworkDatacenter(
					name,
					characteristics,
					new NetworkVmAllocationPolicy(hostList),
					storageList,
					0,
					new CloudletRecoveryScheduler("CentralCloudletRecoveryScheduler"),
					new CentralCheckpointStorageIndex("CheckpointImageStorageIndex"),
					new DatacenterDestroyer("DatacenterDestroyer"));

		} catch (Exception e) {
			e.printStackTrace();
		}
		

		x = 2;
		for(int y = 0; y < edgeSwitchNum; y++){
			EdgeSwitch edgeSwitch = new EdgeSwitch("edgeswitch_"+x+"_"+y,
					2,
					datacenter,
					x,y);
			dcn.getEdgeSwitchList().add(edgeSwitch);
			dcn.getNodeList().add(edgeSwitch);
//			System.out.println("edgeswitch_"+x+"_"+y);
			for(int k = 0; k< portNum/2;k++){
				NetworkHost  host = (NetworkHost)CloudSim.getEntity("host_"+3+"_"+(y*(portNum/2)+k));
				DataCenterLink link =new DataCenterLink(
						edgeSwitch.getId(),
						host.getId(),
								0,NetworkConstants.BandWidthEdgeHost);
				dcn.getLinkList().add(link);
				
				edgeSwitch.hostlist.put(host.getId(), host);
				edgeSwitch.getDownlinks().add(link);
				host.sw = edgeSwitch;
				host.inlink = link;
			}
		}

		x = 1;
		for(int y = 0; y < aggregateSwitchNum; y++){
			AggregateSwitch aggregateSwitch = new AggregateSwitch("aggregateswitch_"+x+"_"+y,
					2,
					datacenter,
					x,y
					);
			dcn.getAggregateSwitchList().add(aggregateSwitch);
			dcn.getNodeList().add(aggregateSwitch);
			for(int k = 0; k< portNum/2;k++){
				EdgeSwitch edgeSwitch = (EdgeSwitch)CloudSim.getEntity("edgeswitch_"+2+"_"+((y/(portNum/2))*(portNum/2)+k));
//				System.out.println((y/(portNum/2))*(portNum/2)+"edgeswitch_"+2+"_"+(((y)/(portNum/2))*(portNum/2)+k));
				
				DataCenterLink link = new DataCenterLink(
						aggregateSwitch.getId(),
						edgeSwitch.getId(),
								0,NetworkConstants.BandWidthEdgeAgg);
				dcn.getLinkList().add(link);
				
				aggregateSwitch.downlinkswitches.add(edgeSwitch);
				aggregateSwitch.getDownlinks().add(link);
				edgeSwitch.uplinkswitches.add(aggregateSwitch);
				edgeSwitch.getUplinks().add(link);
			}
		}
		

		String storageCenterName = "storagecenter_"+-1+"_"+0;
		NetworkStorageHost storageCenter = new NetworkStorageHost(storageCenterName,datacenter,-1,0);
		x = 0;
		for(int y = 0; y < rootSwitchNum; y++){
			RootSwitch rootSwitch = new RootSwitch("rootswitch_"+x+"_"+y,
					2,
					datacenter,
					x,y);
			dcn.getRootSwitchList().add(rootSwitch);
			dcn.getNodeList().add(rootSwitch);
			
			DataCenterLink linkToStorageCenter = new DataCenterLink(
					storageCenter.getId(),
					rootSwitch.getId(),
							0,NetworkConstants.BandWidthRootStorageCenter);
			storageCenter.downlinkswitches.add(rootSwitch);
			storageCenter.downlinks.add(linkToStorageCenter);
			rootSwitch.setStorageCenter(storageCenter);
			rootSwitch.getUplinks().add(linkToStorageCenter);
			
			for(int k = 0; k< portNum;k++){
				AggregateSwitch aggregateSwitch = (AggregateSwitch)CloudSim.getEntity("aggregateswitch_"+1+"_"+(k*(portNum/2)+(y+1)%(portNum/2)));
//				System.out.println("aggregateswitch_"+1+"_"+(k*(portNum/2)+(y)%(portNum/2)));
				DataCenterLink link = new DataCenterLink(
						rootSwitch.getId(),
						aggregateSwitch.getId(),
								0,NetworkConstants.BandWidthAggRoot);
				dcn.getLinkList().add(link);
				
				rootSwitch.downlinkswitches.add(aggregateSwitch);
				rootSwitch.getDownlinks().add(link);
				aggregateSwitch.uplinkswitches.add(rootSwitch);
				aggregateSwitch.getUplinks().add(link);
			}
		}		
		
		dcn.setStorageCenter(storageCenter);
		characteristics.setDatacenternetwork(dcn);
		
		FailureEventReader.readFailureEventFile(System.getProperty("user.dir")+"\\FailureEvent.brite", datacenter.getDatacenterDestroyer());

		return dcn;
	}
*/
}
