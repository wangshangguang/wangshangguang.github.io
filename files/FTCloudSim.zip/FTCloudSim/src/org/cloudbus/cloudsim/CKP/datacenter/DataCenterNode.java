/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package org.cloudbus.cloudsim.CKP.datacenter;

import org.cloudbus.cloudsim.checkpoint.DCNetworkVisitor;
import org.cloudbus.cloudsim.core.SimEntity;
import org.cloudbus.cloudsim.core.SimEvent;

/**
 * Just represents an topological network node retrieves its information from an
 * topological-generated file (eg. topology-generator)
 * 
 * @author Thomas Hohnstein
 * @since CloudSim Toolkit 1.0
 */
public  abstract class DataCenterNode extends SimEntity{

	/**
	 * describes the nodes-name inside the network
	 */
	private String nodeName = null;
	
	/**
	 * representing the x an y world-coordinates
	 */	
	private int worldX = 0;

	private int worldY = 0;
	
	private boolean hasVisited = false;

	
	public boolean isHasVisited() {
		return hasVisited;
	}


	public void setHasVisited(boolean hasVisited) {
		this.hasVisited = hasVisited;
	}


	public DataCenterNode(String name, int x, int y) {
		super(name);
	}


	public String getNodeName() {
		return nodeName;
	}


	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}


	public int getWorldX() {
		return worldX;
	}


	public void setWorldX(int worldX) {
		this.worldX = worldX;
	}


	public int getWorldY() {
		return worldY;
	}


	public void setWorldY(int worldY) {
		this.worldY = worldY;
	}


	@Override
	public void startEntity() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void processEvent(SimEvent ev) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void shutdownEntity() {
		// TODO Auto-generated method stub
		
	}
	
	public abstract void accept(DCNetworkVisitor visitor, Object data);

}
