
clear;
clc; close all;
% waring off;
Knn=1;
k=1;
k1=1;
k2=1;

% Dimension=100;
for qq=1:20
    
    
    % %     ***************Yale_1 dataset**********************
    load yale_1.mat;
    XX=[X_trn;X_tst];
    Y=[Y_trn;Y_tst];
    N1=0.7;
    N2=1-N1;
    [X_trn,Y_trn,X_tst,Y_tst]=sample_random(XX,Y,N1,N2);
    % %    ***************Yale_1 dataset**********************
    
    [mappedX,M] = pca1(X_trn,100);
    X_trn=X_trn*M;
    X_tst=X_tst*M;
    [X_trn,MaxX,MinX]=normlizedata(X_trn,'0-1');
    [X_tst]=normlizedata(X_tst,'0-1',MaxX,MinX);

    for dimension=1:size(X_trn,2)
        [mapping_twtest1,eigvalues] = GLSP(X_trn,Y_trn,0.1,0.5,0.5,1,1,dimension);
        X_trn_GLSPtest1=X_trn*mapping_twtest1;
        X_tst_GLSPtest1=X_tst*mapping_twtest1;
        [result_GLSPtest1]=knear(k,X_trn_GLSPtest1,Y_trn,X_tst_GLSPtest1);
        corr_GLSPtest1(qq,dimension)=mean(result_GLSPtest1==Y_tst);
    end
        
end

dim=80;
inver=6;
figure(4);
corr_GLSPtest1mean=mean(corr_GLSPtest1,1);
dimension=1:inver:dim;
plot(dimension,corr_GLSPtest1mean(1:inver:dim),'r->','MarkerFaceColor','r','LineWidth',3);
hold on
xlabel('Number of Projection Vectors');
ylabel('Accuracy');
legend('GLSP');
set(get(gca,'ylabel'),'fontangle','italic','fontweight','normal','fontsize',18)
set(get(gca,'xlabel'),'fontangle','italic','fontweight','normal','fontsize',18)
set(gca,'FontSize',16);
hold off
